<?php
/**
 * Taxonomy options
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = _MEDSTORE_TAXONOMY_KEY;
  
    //
    // Create taxonomy options
    CSF::createTaxonomyOptions( $prefix, array(
      'taxonomy'  => ['category', 'post_tag', 'product_cat', 'product_tag'],
      'data_type' => 'serialize', // The type of the database save options. `serialize` or `unserialize`
    ) );
      
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('General', 'medstore-helpers'),
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Custome title', 'medstore-helpers'),
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'medstore-helpers'),
        ),              
  
      )
    ) );
  
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Header', 'medstore-helpers'),
      'fields' => array(
        
        array(
          'id'          => 'header-style',
          'type'        => 'select',
          'title'       => esc_html__('Header Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, header style follow theme option.', 'medstore-helpers'),
          'placeholder' => esc_html__('Select a style', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Header Style #1', 'medstore-helpers'),
            '2'  => esc_html__('Header Style #2', 'medstore-helpers'),
            '3'  => esc_html__('Header Style #3', 'medstore-helpers'),
          ),
          'chosen'      => true,
        ),  
        array(
          'id'        => 'announcement_enable',
          'type'      => 'select',
          'title'     => esc_html__('Announcement bar enabled', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'dependency' => array( 'header-style', '==', '1' ),
          'chosen'      => true,
        ), 
        array(
          'id'          => 'header-style-mobile',
          'type'        => 'select',
          'title'       => esc_html__('Mobile Header Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, header style follow theme option.', 'medstore-helpers'),
          'placeholder' => esc_html__('Select a style', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Header Style #1', 'medstore-helpers'),
            '2'  => esc_html__('Header Style #2', 'medstore-helpers'),
            '3'  => esc_html__('Header Style #3', 'medstore-helpers'),
            '4'  => esc_html__('Header Style #4', 'medstore-helpers'),
            '5'  => esc_html__('Header Style #5', 'medstore-helpers'),
          ),
          'chosen'      => true,
        ),                
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Breadcrumbs', 'medstore-helpers'),
      'icon' => 'fa fa-sitemap',
      'fields' => array(
   
        array(
          'id'        => 'breadcrumb_enable',
          'type'      => 'select',
          'title'     => esc_html__('Breadcrumbs enable', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),      
        array(
          'id'        => 'breadcrumb_style',
          'type'      => 'select',
          'title'     => esc_html__('Separate Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            'slash' => esc_html__('Slash', 'medstore-helpers'),
            'dot' => esc_html__('Dot', 'medstore-helpers'),
            'arrow' => esc_html__('Arrow', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Archive', 'medstore-helpers'),
      'taxonomy' => ['product_cat', 'product_tag', 'product_brand'],
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Layout', 'medstore-helpers'),
        ),                  
        array(
          'id'        => 'shop_layout',
          'type'      => 'select',
          'title'     => esc_html__('Archive layout', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            'grid' => esc_html__('Grid layout', 'medstore-helpers'),
            'list' => esc_html__('List layout', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),            
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Footer', 'medstore-helpers'),
      'icon' => 'fa fa-ellipsis-h',
      'fields' => array(
   
        array(
          'id'        => 'newsletter_enable',
          'type'      => 'select',
          'title'     => esc_html__('Newsletter enable', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),
      )
    ) );
  
  }
  
  