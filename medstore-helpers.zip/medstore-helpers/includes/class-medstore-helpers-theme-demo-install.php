<?php

/**
 * Demo Installer
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */

class Medstore_Helpers_Theme_Demo_Install {

	public static function init()
	{
		if(!defined('FS_METHOD')){
			define('FS_METHOD', 'direct');
		}

		$template = get_option('template');
		if(is_plugin_active('one-click-demo-import/one-click-demo-import.php') && $template === 'medstore'){
			add_filter( 'ocdi/import_files', array(__CLASS__, 'import_files') );
			add_action( 'ocdi/after_import', array(__CLASS__, 'ocdi_after_import') );
			add_action( 'ocdi/before_content_import', array(__CLASS__, 'ocdi_before_content_import') );
		}
	}

	public static function ocdi_before_content_import($selected_import_files) {
		/**
		 * Deleted posts, pages unnecessary
		*/

		$shop_default = medstore_get_post_by_title('Shop', 'page');
		if(isset( $shop_default ) && $shop_default->ID) {
			wp_delete_post($shop_default->ID);
		}

		$cart_default = medstore_get_post_by_title('Cart', 'page');
		if(isset( $cart_default ) && $cart_default->ID) {
			wp_delete_post($cart_default->ID);
		}

		$checkout_default = medstore_get_post_by_title('Checkout', 'page');
		if(isset( $checkout_default ) && $checkout_default->ID) {
			wp_delete_post($checkout_default->ID);
		}

		$my_account_default = medstore_get_post_by_title('My account', 'page');
		if(isset( $my_account_default ) && $my_account_default->ID) {
			wp_delete_post($my_account_default->ID);
		}

		$wishlist_default = medstore_get_post_by_title('Wishlist', 'page');
		if(isset( $wishlist_default ) && $wishlist_default->ID) {
			wp_delete_post($wishlist_default->ID);
		}
	}

	public static function import_files() {
	    return array(
	        array(
	            'import_file_name'         => esc_html__('Demo 1', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo1/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo1/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo1/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 2', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo2/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo2/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo2/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-2/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 3', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo3/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo3/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo3/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-3/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 4', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo4/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo4/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo4/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-4/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 5', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo5/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo5/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo5/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-5/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 6', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo6/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo6/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo6/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-6/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 7', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo7/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo7/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo7/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-7/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
			array(
	            'import_file_name'         => esc_html__('Demo 8', 'medstore-helpers'),
	            'local_import_file'        => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo8/content.xml',
	            'local_import_widget_file' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/demo8/widgets.wie',
				'import_preview_image_url' => trailingslashit( MEDSTORE_HELPERS_PLUGIN_URL ) . 'demo-install/demo8/screenshot.png',
				'preview_url' 			   => 'https://medstore.nouthemes.com/home-page-8/',
	            'import_notice'            => esc_html__('The import process can take about 10 minutes. Enjoy a cup of coffee while you wait for importing.', 'medstore-helpers'),
			),
	    );
	}

    public static function ocdi_after_import($selected_import) {

		/************************************************************************
		* Import slider(s) for the current demo being imported
		*************************************************************************/

		try{
			if ( class_exists( 'RevSlider' ) ) {
				$slider_import = array(
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/hom-1-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-1-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-1-banner-4.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-1-banner-5.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-2-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-2-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-3-banner-1-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-4-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-4-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-4-banner-product-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-4-banner-product-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-1-banner-3.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-3-banner-2-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-3.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/our-achievements.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-4.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/shop-page.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-5.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-5-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-5-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-5-banner-3.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-5-banner-4.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-6.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-6-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-6-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-7.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-7-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-8.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-8-banner-1.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-8-banner-2.zip',
					trailingslashit( MEDSTORE_HELPERS_PLUGIN_DIR ) . 'demo-install/revslider/home-page-8-banner-3.zip',
				);
				foreach ($slider_import as $slider) {
					if ( file_exists( $slider ) ) {
						$revslider = new RevSlider();
						$revslider->importSliderFromPost( true, true, $slider );
					}
				}
			}
		} catch (\Throwable $th) {}

        /*Theme Options*/
		try {
			$optionsEncode = "eyJsb2dvX3R5cGUiOiJ0ZXh0IiwibG9nb190ZXh0IjoibWVkc3RvcmUiLCJsb2dvX2ltZyI6IiIsImVuYWJsZV9sYXp5IjoiMSIsImhlYWRlcl9zdGlja3lfZW5hYmxlIjoiMSIsImFubm91bmNlbWVudF9lbmFibGUiOiIxIiwiaGVhZGVyLXN0eWxlIjoiMSIsImhlYWRlci1zdHlsZS1tb2JpbGUiOiIxIiwibmV3c2xldHRlcl9lbmFibGUiOiIxIiwibmV3c2xldHRlcl90aXRsZSI6IlN1YnNjcmliZSBhbmQgZ2V0IDxzcGFuPjMwJTxcL3NwYW4+IGRpc2NvdW50LiIsIm5ld3NsZXR0ZXJfaW5wdXQiOiJZb3VyIGVtYWlsIGFkZHJlc3MiLCJuZXdzbGV0dGVyX2J1dHRvbiI6IlN1YnNjcmliZSIsImdyaWRfY29sc19mb290ZXIiOiI1IiwiYmdfY29sb3JfZm9vdGVyIjoiI0Y2RjZGNiIsInRleHRfY29sb3JfZm9vdGVyIjp7ImNvbG9yIjoiIzM0MzQzNCIsImhvdmVyIjoiIzQzNkNGRiJ9LCJzcGFjaW5nX2Zvb3RlciI6eyJ0b3AiOiIxMDUiLCJib3R0b20iOiI1NSJ9LCJ0ZXh0X2NvcHlyaWdodCI6Ilx1MDBhOSAyMDI0IE1lZHN0b3JlLiBBbGwgUmlnaHRzIFJlc2VydmVkLiIsImJnX2NvbG9yX2NvcHlyaWdodCI6IiNFQ0VDRUMiLCJ0ZXh0X2NvbG9yX2NvcHlyaWdodCI6eyJjb2xvciI6IiM3MzczNzMiLCJob3ZlciI6IiM0MzZDRkYifSwic3BhY2luZ19jb3B5cmlnaHQiOnsidG9wIjoiMTAiLCJib3R0b20iOiIxMCJ9LCJiZ19jb2xvcl9ib3R0b21fbmF2IjoiIzIyMzY4MCIsInRleHRfY29sb3JfYm90dG9tX25hdiI6IiNmZmZmZmYiLCJicmVhZGNydW1iX2VuYWJsZSI6IjEiLCJicmVhZGNydW1iX3N0eWxlIjoic2xhc2giLCJjb250YWN0X2VtYWlsIjoiaW5mb0BtZWRzdG9yZS5kZXYiLCJob3RsaW5lIjoiNC05NTYtMjMyLTA5NTUiLCJhZGRyZXNzIjoiMTIzIE1haW4gU3RyZWV0LCBDQSAxMjM0NSIsImJsb2ctbGF5b3V0IjoibGlzdCIsImJsb2ctc2luZ2xlLWhlYWRpbmciOiIyIiwibWluaV9jYXJ0X2VuYWJsZSI6IjEiLCJzaG9wX2xheW91dCI6ImdyaWQiLCJwcm9kdWN0X3Blcl9wYWdlIjoiOCIsInByb2R1Y3RfbG9vcF9hZGRfdG9fY2FydF9zdHlsZSI6ImhvdmVyIiwicHJvZHVjdF9sb29wX3N0b2NrX2VuYWJsZSI6IiIsInByb2R1Y3RfbG9vcF9wb2xpY3lfZW5hYmxlIjoiMCIsInByb2R1Y3RfbG9vcF9ib3JkZXJfZW5hYmxlIjoiMCIsImFkZGVkX2NhcnRfdGV4dCI6IlByb2R1Y3QgaGFzIGJlZW4gYWRkZWQgdG8geW91ciBjYXJ0LiIsInByb2R1Y3RfcG9saWN5IjpbeyJ0aXRsZSI6IlF1YWxpdHkgYXNzdXJhbmNlIn0seyJ0aXRsZSI6IjEgeWVhciB3YXJyYW50eSJ9LHsidGl0bGUiOiJHb29kIHBvbGljeSJ9XSwibG9naW5fYmFubmVyIjp7InVybCI6Imh0dHA6XC9cL21lZHN0b3JlLm5vdXRoZW1lcy5jb21cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjRcLzA2XC9SZWN0YW5nbGUtMzQ2Mzk5Ny5wbmciLCJpZCI6IjUwIiwid2lkdGgiOiI4MDYiLCJoZWlnaHQiOiI2MDAiLCJ0aHVtYm5haWwiOiJodHRwOlwvXC9tZWRzdG9yZS5ub3V0aGVtZXMuY29tXC93cC1jb250ZW50XC91cGxvYWRzXC8yMDI0XC8wNlwvUmVjdGFuZ2xlLTM0NjM5OTctMTUweDE1MC5wbmciLCJhbHQiOiIiLCJ0aXRsZSI6IlJlY3RhbmdsZS0zNDYzOTk3IiwiZGVzY3JpcHRpb24iOiIifSwicmVnaXN0ZXJfYmFubmVyIjp7InVybCI6Imh0dHA6XC9cL21lZHN0b3JlLm5vdXRoZW1lcy5jb21cL3dwLWNvbnRlbnRcL3VwbG9hZHNcLzIwMjRcLzA2XC9SZWN0YW5nbGUtMzQ2Mzk5Ni5wbmciLCJpZCI6IjQ5Iiwid2lkdGgiOiI4MDYiLCJoZWlnaHQiOiI2MDAiLCJ0aHVtYm5haWwiOiJodHRwOlwvXC9tZWRzdG9yZS5ub3V0aGVtZXMuY29tXC93cC1jb250ZW50XC91cGxvYWRzXC8yMDI0XC8wNlwvUmVjdGFuZ2xlLTM0NjM5OTYtMTUweDE1MC5wbmciLCJhbHQiOiIiLCJ0aXRsZSI6IlJlY3RhbmdsZS0zNDYzOTk2IiwiZGVzY3JpcHRpb24iOiIifSwic29jaWFsX2ZhY2Vib29rIjoiIyIsInNvY2lhbF90d2l0dGVyIjoiIyIsInNvY2lhbF9pbnN0YWdyYW0iOiIjIiwic29jaWFsX3ByaW50ZXN0IjoiIyIsInNvY2lhbF95b3V0dWJlIjoiIyIsInNvY2lhbF9saW5rZWRpbiI6IiMiLCJ0ZXh0X2Fubm91bmNlbWVudCI6IldlIFByb3ZpZGVzIDxzcGFuIGNsYXNzPVwidGV4dC1wcmltYXJ5LWNvbG9yXCI+TWVkaWNhbCBBY2Nlc3NvcmllczxcL3NwYW4+IiwicGFnZV9hbm5vdW5jZW1lbnQiOlt7InBhZ2VfaWQiOiIxNSJ9LHsicGFnZV9pZCI6IjE4In0seyJwYWdlX2lkIjoiOSJ9XSwic29jaWFsX2Fubm91bmNlbWVudCI6W3sic29jaWFsX2lkIjoiZmFjZWJvb2sifSx7InNvY2lhbF9pZCI6InR3aXR0ZXIifSx7InNvY2lhbF9pZCI6InlvdXR1YmUifV0sImJnX2NvbG9yX2Fubm91bmNlbWVudCI6IiNGNkY2RjYiLCJ0ZXh0X2NvbG9yX2Fubm91bmNlbWVudCI6eyJjb2xvciI6IiM2ODY4NjgiLCJob3ZlciI6IiM0MzZDRkYifSwic3BhY2luZ19hbm5vdW5jZW1lbnQiOnsidG9wIjoiNCIsImJvdHRvbSI6IjQifSwicHJpbWFyeS1jb2xvciI6IiM0MzZDRkYiLCJiYWNrZ3JvdW5kLWNvbG9yIjoiI2ZmZmZmZiIsImhlYWRpbmctY29sb3IiOiIjMTUxNTE1IiwiYm9keS1jb2xvciI6IiMxNTE1MTUiLCJtZW51LWNvbG9yIjoiIzY4Njg2OCIsIndpZGdldC1jb2xvciI6IiMzNDM0MzQiLCJib2R5X3NlY29uZF90eXBvZ3JhcGh5Ijp7ImZvbnQtZmFtaWx5IjoiSm9zZWZpbiBTYW5zIiwiZm9udC13ZWlnaHQiOiI0MDAiLCJmb250LXN0eWxlIjoiIiwidHlwZSI6Imdvb2dsZSIsInVuaXQiOiJweCJ9LCJib2R5X3R5cG9ncmFwaHkiOnsiZm9udC1mYW1pbHkiOiJNb250c2VycmF0IiwiZm9udC13ZWlnaHQiOiI0MDAiLCJmb250LXN0eWxlIjoiIiwidHlwZSI6Imdvb2dsZSIsInVuaXQiOiJweCJ9LCJoZWFkaW5nX3R5cG9ncmFwaHkiOnsiZm9udC1mYW1pbHkiOiJKb3NlZmluIFNhbnMiLCJmb250LXdlaWdodCI6IjcwMCIsImZvbnQtc3R5bGUiOiIiLCJ0eXBlIjoiZ29vZ2xlIiwidW5pdCI6InB4In0sIm1lbnVfdHlwb2dyYXBoeSI6eyJmb250LWZhbWlseSI6Ikpvc2VmaW4gU2FucyIsImZvbnQtd2VpZ2h0IjoiNDAwIiwiZm9udC1zdHlsZSI6IiIsInR5cGUiOiJnb29nbGUiLCJ1bml0IjoicHgifSwiYnV0dG9uX3R5cG9ncmFwaHkiOnsiZm9udC1mYW1pbHkiOiJKb3NlZmluIFNhbnMiLCJmb250LXdlaWdodCI6IjQwMCIsImZvbnQtc3R5bGUiOiIiLCJ0eXBlIjoiZ29vZ2xlIiwidW5pdCI6InB4In0sIjQwNF90aXRsZSI6Ik9vcHMhIFRoYXQgcGFnZSBjYW5cdTIwMTl0IGJlIGZvdW5kLiIsIjQwNF9jb250ZW50IjoiVGhlIHBhZ2UgeW91J3JlIGxvb2tpbmcgZm9yIGlzbid0IGF2YWlsYWJsZS4gVHJ5IHRvIHNlYXJjaCBhZ2FpbiBvciB1c2UgdGhlIGdvIHRvLiIsIjQwNF9pbWciOnsidXJsIjoiaHR0cDpcL1wvbWVkc3RvcmUubm91dGhlbWVzLmNvbVwvd3AtY29udGVudFwvcGx1Z2luc1wvbWVkc3RvcmUtaGVscGVyc1wvYXNzZXRzXC9pbWFnZXNcLzQwNC5wbmciLCJpZCI6IiIsIndpZHRoIjoiIiwiaGVpZ2h0IjoiIiwidGh1bWJuYWlsIjoiIiwiYWx0IjoiIiwidGl0bGUiOiIiLCJkZXNjcmlwdGlvbiI6IiJ9LCI0MDRfYmciOnsidXJsIjoiaHR0cDpcL1wvbWVkc3RvcmUubm91dGhlbWVzLmNvbVwvd3AtY29udGVudFwvcGx1Z2luc1wvbWVkc3RvcmUtaGVscGVyc1wvYXNzZXRzXC9pbWFnZXNcL2JnLTQwNC5wbmciLCJpZCI6IiIsIndpZHRoIjoiIiwiaGVpZ2h0IjoiIiwidGh1bWJuYWlsIjoiIiwiYWx0IjoiIiwidGl0bGUiOiIiLCJkZXNjcmlwdGlvbiI6IiJ9LCJjdXN0b21fY3NzIjoiLmVsZW1lbnR7IGNvbG9yOiAjZmZiYzAwOyB9In0=";
			$backup = json_decode(base64_decode($optionsEncode), true);

			if (!empty($backup) && is_array($backup)) {
				$options = [];
				foreach ($backup as $key => $value) {
					$options[$key] = $value;
				}

				update_option(_MEDSTORE_OPTION_KEY, $options);
			}
		} catch (\Throwable $th) {}

		$blog_page_id  = medstore_get_post_by_title( 'Blog', 'page' );
		if($blog_page_id){
			update_option( 'show_on_front', 'page' );
			update_option( 'page_for_posts', $blog_page_id->ID );
		}

		if ( 'Demo 1' === $selected_import['import_file_name'] ) {
				
			$front_page_id = medstore_get_post_by_title( 'Home page #1', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 2' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #2', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 3' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #3', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 4' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #4', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 5' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #5', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 6' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #6', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 7' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #7', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}
		
		if ( 'Demo 8' === $selected_import['import_file_name'] ) {
			
			$front_page_id = medstore_get_post_by_title( 'Home page #8', 'page' );
			if($front_page_id){
				update_option( 'page_on_front', $front_page_id->ID );
			}
		}

		$shop = medstore_get_post_by_title( 'Shop', 'page' );
		if(isset( $shop ) && $shop->ID) {
			update_option('woocommerce_shop_page_id', $shop->ID);
		}

		$cart = medstore_get_post_by_title( 'Cart', 'page' );
		if(isset( $cart ) && $cart->ID) {
			update_option('woocommerce_cart_page_id', $cart->ID);
			update_post_meta($cart->ID, '_wp_page_template', 'template/full.php');
		}

		$check_out = medstore_get_post_by_title( 'Checkout', 'page' );
		if(isset( $check_out ) && $check_out->ID) {
			update_option('woocommerce_checkout_page_id', $check_out->ID);
			update_post_meta($check_out->ID, '_wp_page_template', 'template/checkout.php');
		}

		$my_account = medstore_get_post_by_title( 'My account', 'page' );
		if(isset( $my_account ) && $my_account->ID) {
			update_option('woocommerce_myaccount_page_id', $my_account->ID);
			update_post_meta($my_account->ID, '_wp_page_template', 'template/my-account.php');
		}

		$wishlist_default = medstore_get_post_by_title('Wishlist', 'page');
		if(isset( $wishlist_default ) && $wishlist_default->ID) {
			update_option('yith_wcwl_wishlist_page_id', $wishlist_default->ID);
			update_post_meta($wishlist_default->ID, '_wp_page_template', 'template/wishlist.php');
		}

		/************************************************************************
		* Setting Menus
		*************************************************************************/
		$menuSettings = [];
		$header_nav = get_term_by( 'name', 'Main', 'nav_menu' );
        if($header_nav){
            $menuSettings['menu-header'] = $header_nav->term_id;
        }

        $cat_nav = get_term_by( 'name', 'All categories', 'nav_menu' );
        if($cat_nav){
			$menuSettings['menu-categories'] = $cat_nav->term_id;
        }

        $footer_nav = get_term_by( 'name', 'Copyright', 'nav_menu' );
        if($footer_nav){
			$menuSettings['footer-menu-copyright'] = $footer_nav->term_id;
        }

		if(!empty($menuSettings)){
			set_theme_mod( 'nav_menu_locations', $menuSettings );
		}

		try {
			self::update_terms_count();
		} catch (\Throwable $th) {}

		update_option('widget_recent-posts', '');
		update_option('widget_recent-comments', '');

		$post_default = medstore_get_post_by_title('Hello world!');
		if(isset( $post_default ) && $post_default->ID) {
			wp_delete_post($post_default->ID);
		}
	}

	private static function update_terms_count(){
		global $wpdb;
		$sql = "
		UPDATE ". $wpdb->prefix ."term_taxonomy SET count = (
			SELECT COUNT(*) FROM ". $wpdb->prefix ."term_relationships rel 
				LEFT JOIN ". $wpdb->prefix ."posts po ON (po.ID = rel.object_id) 
				WHERE 
					rel.term_taxonomy_id = ". $wpdb->prefix ."term_taxonomy.term_taxonomy_id 
					AND 
					". $wpdb->prefix ."term_taxonomy.taxonomy NOT IN ('link_category')
					AND 
					po.post_status IN ('publish', 'future')
		)";
		$wpdb->get_results($sql);
	}

}
