<?php
/**
 * Admin theme options
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */

if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = _MEDSTORE_OPTION_KEY;
  
    //
    // Create options
    CSF::createOptions( $prefix, array(
      'menu_title' => esc_html__('Theme options', 'medstore-helpers'),
      'menu_slug'  => 'nou_medstore_options',
      'menu_parent' => 'themes.php',
      'menu_type'  => 'submenu',
      'menu_capability' => 'manage_options',
      'framework_title' => esc_html__('Medstore Theme Options', 'medstore-helpers').' '. MEDSTORE_HELPERS_VERSION,
    ) );
  
    //
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('General', 'medstore-helpers'),
      'icon' => 'fa fa-cog',
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Logo', 'medstore-helpers'),
        ),
        array(
          'id'        => 'logo_type',
          'type'      => 'select',
          'title'     => esc_html__('Logo Style', 'medstore-helpers'),
          'options'   => array(
            'img' => esc_html__('Image', 'medstore-helpers'),
            'text' => esc_html__('Text', 'medstore-helpers'),
          ),
          'default'   => 'text',
          'chosen'      => true,
        ),
        array(
          'id'           => 'logo_text',
          'type'         => 'text',
          'title'        => esc_html__('Logo text', 'medstore-helpers'),
          'dependency' => array( 'logo_type', '==', 'text' ),
          'default'     => get_bloginfo( 'name' )
        ),
        array(
          'id'           => 'logo_img',
          'type'         => 'upload',
          'title'        => esc_html__('Logo image', 'medstore-helpers'),
          'library'      => 'image',
          'placeholder'  => 'http://',
          'button_title' => esc_html__('Add Logo', 'medstore-helpers'),
          'remove_title' => esc_html__('Remove Logo', 'medstore-helpers'),
          'dependency' => array( 'logo_type', '==', 'img' ),
        ), 
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Image', 'medstore-helpers'),
        ),
        array(
          'id'        => 'enable_lazy',
          'type'      => 'switcher',
          'title'     => esc_html__('Lazy loading', 'medstore-helpers'),
          'default'    => true
        ),        

      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Header', 'medstore-helpers'),
      'icon' => 'fa fa-header',
      'fields' => array(
          
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Sticky', 'medstore-helpers'),
        ),
        array(
          'id'        => 'header_sticky_enable',
          'type'      => 'switcher',
          'title'     => esc_html__('Enabled', 'medstore-helpers'),
          'default'    => true,
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Announcement bar', 'medstore-helpers'),
        ),
        array(
          'id'        => 'announcement_enable',
          'type'      => 'switcher',
          'title'     => esc_html__('Enabled', 'medstore-helpers'),
          'default'    => true,
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Desktop', 'medstore-helpers'),
        ),
        array(
          'id'        => 'header-style',
          'type'      => 'image_select',
          'title'     => esc_html__('Header Style', 'medstore-helpers'),
          'options'   => array(
            '1' => _MEDSTORE_IMG . '/header/1.png',
            '2' => _MEDSTORE_IMG . '/header/2.png',
            '3' => _MEDSTORE_IMG . '/header/3.png',
            '4' => _MEDSTORE_IMG . '/header/4.png',
          ),
          'default'   => '1'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Mobile', 'medstore-helpers'),
        ),
        
        array(
          'id'        => 'header-style-mobile',
          'type'      => 'image_select',
          'title'     => esc_html__('Header Style', 'medstore-helpers'),
          'options'   => array(
            '4' => _MEDSTORE_IMG . '/header/mobile-4.png',
            '5' => _MEDSTORE_IMG . '/header/mobile-5.png',
            '3' => _MEDSTORE_IMG . '/header/mobile-3.png',
            '2' => _MEDSTORE_IMG . '/header/mobile-2.png',
            '1' => _MEDSTORE_IMG . '/header/mobile-1.png',
          ),
          'default'   => '1'
        ), 
  
      )
    ) );
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Footer', 'medstore-helpers'),
      'icon' => 'fa fa-ellipsis-h',
      'fields' => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer section', 'medstore-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Newsletter', 'medstore-helpers'),
        ),
        array(
          'id'        => 'newsletter_enable',
          'type'      => 'switcher',
          'title'     => esc_html__('Enabled', 'medstore-helpers'),
          'default'    => true,
        ),
        array(
          'id'           => 'newsletter_title',
          'type'         => 'textarea',
          'default'      => esc_html__('Subscribe and get 30% discount.', 'medstore-helpers'),
          'title'        => esc_html__('Title', 'medstore-helpers'),
        ), 
        array(
          'id'           => 'newsletter_input',
          'type'         => 'text',
          'default'      => esc_html__('Your email address', 'medstore-helpers'),
          'title'        => esc_html__('Input text', 'medstore-helpers'),
        ),  
        array(
          'id'           => 'newsletter_button',
          'type'         => 'text',
          'default'      => esc_html__('Subscribe', 'medstore-helpers'),
          'title'        => esc_html__('Button text', 'medstore-helpers'),
        ), 
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Grid layout', 'medstore-helpers'),
        ),
        array(
          'id'    => 'grid_cols_footer',
          'type'  => 'number',
          'default' => 5,
          'attributes' => array(
            'min'  => 1,
            'max'  => 12,
          ),
          'title' => esc_html__('Number of columns', 'medstore-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Style', 'medstore-helpers'),
        ),
        array(
          'id'    => 'bg_color_footer',
          'type'  => 'color',
          'default' => '#F6F6F6',
          'title' => esc_html__('Background color', 'medstore-helpers'),
        ),
        array(
          'id'      => 'text_color_footer',
          'type'    => 'link_color',
          'title'   => esc_html__('Text color', 'medstore-helpers'),
          'default' => array(
            'color' => '#343434',
            'hover' => '#436CFF',
          ),
        ),
        array(
          'id'    => 'spacing_footer',
          'type'  => 'spacing',
          'title' => esc_html__('Spacing', 'medstore-helpers'),
          'left'  => false,
          'right' => false,
          'default'  => array(
            'top'    => '105',
            'bottom' => '55',
            'unit'   => 'px',
          ),
          'units' => array( 'px' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Copyright section', 'medstore-helpers'),
        ),
        array(
          'id'      => 'text_copyright',
          'type'    => 'textarea',
          'title'   => esc_html__('Copyright text', 'medstore-helpers'),
          'default' => esc_html__('&copy; 2024 Medstore. All Rights Reserved.', 'medstore-helpers'),
        ),
        array(
          'id'    => 'bg_color_copyright',
          'type'  => 'color',
          'default' => '#ECECEC',
          'title' => esc_html__('Background color', 'medstore-helpers'),
        ),
        array(
          'id'      => 'text_color_copyright',
          'type'    => 'link_color',
          'title'   => esc_html__('Text color', 'medstore-helpers'),
          'default' => array(
            'color' => '#737373',
            'hover' => '#436CFF',
          ),
        ),
        array(
          'id'    => 'spacing_copyright',
          'type'  => 'spacing',
          'title' => esc_html__('Spacing', 'medstore-helpers'),
          'left'  => false,
          'right' => false,
          'default'  => array(
            'top'    => '10',
            'bottom' => '10',
            'unit'   => 'px',
          ),
          'units' => array( 'px' ),
        ), 

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Style of Mobile Navigation', 'medstore-helpers'),
        ),
        
        array(
          'id'    => 'bg_color_bottom_nav',
          'type'  => 'color',
          'default' => '#223680',
          'title' => esc_html__('Background color', 'medstore-helpers'),
        ),
        array(
          'id'      => 'text_color_bottom_nav',
          'type'    => 'color',
          'title'   => esc_html__('Text color', 'medstore-helpers'),
          'default' => '#ffffff',
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Breadcrumbs', 'medstore-helpers'),
      'icon' => 'fa fa-sitemap',
      'fields' => array(
   
        array(
          'id'        => 'breadcrumb_enable',
          'type'      => 'switcher',
          'title'     => esc_html__('Breadcrumbs enable', 'medstore-helpers'),
          'default'    => true
        ),        
        array(
          'id'        => 'breadcrumb_style',
          'type'      => 'select',
          'title'     => esc_html__('Separate Style', 'medstore-helpers'),
          'options'   => array(
            'slash' => esc_html__('Slash', 'medstore-helpers'),
            'dot' => esc_html__('Dot', 'medstore-helpers'),
            'arrow' => esc_html__('Arrow', 'medstore-helpers'),
          ),
          'default'   => 'slash',
          'chosen'      => true,
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Contact', 'medstore-helpers'),
      'icon' => 'fa fa-phone',
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Contact', 'medstore-helpers'),
        ),
        array(
          'id'           => 'contact_email',
          'type'         => 'text',
          'title'        => esc_html__('Contact email', 'medstore-helpers'),
          'validate'     => 'medstore_validate_email',
        ),
        array(
          'id'           => 'hotline',
          'type'         => 'text',
          'title'        => esc_html__('Hotline number', 'medstore-helpers'),
        ),  
        array(
          'id'           => 'address',
          'type'         => 'text',
          'default'      => esc_html__('123 Main Street, CA 12345', 'medstore-helpers'),
          'title'        => esc_html__('Address', 'medstore-helpers'),
        ),      

      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Blog', 'medstore-helpers'),
      'icon' => 'fa fa-newspaper',
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Blog view layout', 'medstore-helpers'),
        ),
        array(
          'id'        => 'blog-layout',
          'type'      => 'select',
          'title'     => esc_html__('Layout', 'medstore-helpers'),
          'options'   => array(
            'grid' => esc_html__('Grid view', 'medstore-helpers'),
            'list' => esc_html__('List view', 'medstore-helpers'),
          ),
          'default'   => 'list',
          'chosen'      => true,
        ),   
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Single', 'medstore-helpers'),
        ),                  
        array(
          'id'        => 'blog-single-heading',
          'type'      => 'image_select',
          'title'     => esc_html__('Heading Style', 'medstore-helpers'),
          'options'   => array(
            '2' => _MEDSTORE_IMG . '/single/heading-2.png',
            '1' => _MEDSTORE_IMG . '/single/heading-1.png',
          ),
          'default'   => '2'
        ),

        array(
          'id'      => 'blog-single-heading-color',
          'type'    => 'color',
          'title'   => esc_html__('Heading Color', 'medstore-helpers'),
          'default' => '#103178'
        ),
  
      )
    ) );

    if (is_plugin_active('woocommerce/woocommerce.php')) {
      CSF::createSection( $prefix, array(
        'title'  => esc_html__('Woocommerce', 'medstore-helpers'),
        'icon' => 'fa fa-shopping-cart',
        'fields' => array(
    
          array(
            'id'        => 'mini_cart_enable',
            'type'      => 'switcher',
            'title'     => esc_html__('Mini cart enable', 'medstore-helpers'),
            'default'    => true
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Shop', 'medstore-helpers'),
          ),  
                            
          array(
            'id'        => 'shop_layout',
            'type'      => 'select',
            'title'     => esc_html__('Shop layout', 'medstore-helpers'),
            'options'   => array(
              'grid' => esc_html__('Grid layout', 'medstore-helpers'),
              'list' => esc_html__('List layout', 'medstore-helpers'),
            ),
            'default'   => 'grid',
            'chosen'      => true,
          ),
          array(
            'id'           => 'product_per_page',
            'type'         => 'number',
            'default'      => get_option('posts_per_page'),
            'title'        => esc_html__('Products per page', 'medstore-helpers'),
          ), 

          array(
            'id'        => 'product_loop_add_to_cart_style',
            'type'      => 'select',
            'title'     => esc_html__('Add to cart button', 'medstore-helpers'),
            'subtitle'      => esc_html__('Select style for add to cart button', 'medstore-helpers'),
            'options'   => array(
              'default' => esc_html__('Alway show on bottom', 'medstore-helpers'),
              'hover' => esc_html__('Display button on hover', 'medstore-helpers'),
            ),
            'default'   => 'hover',
            'chosen'      => true,
          ), 
          array(
            'id'        => 'product_loop_stock_enable',
            'type'      => 'switcher',
            'title'     => esc_html__('Show Stock', 'medstore-helpers'),
            'default'    => false
          ),
          array(
            'id'        => 'product_loop_policy_enable',
            'type'      => 'switcher',
            'title'     => esc_html__('Show product policy', 'medstore-helpers'),
            'default'    => false
          ),
          array(
            'id'        => 'product_loop_border_enable',
            'type'      => 'switcher',
            'title'     => esc_html__('Show border', 'medstore-helpers'),
            'default'    => false
          ),
          array(
            'id'        => 'added_cart_text',
            'type'      => 'text',
            'title'     => esc_html__('Added cart text', 'medstore-helpers'),
            'default'    => esc_html__('Product has been added to your cart.', 'medstore-helpers')
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Single Product', 'medstore-helpers'),
          ),
          array(
            'id'     => 'product_policy',
            'type'   => 'repeater',
            'title'  => esc_html__('Product policy', 'medstore-helpers'),
            'fields' => array(
              
              array(
                'id'          => 'title',
                'type'        => 'text',
                'title'       => esc_html__('Policy title', 'medstore-helpers'),
              ),
          
            ),
            'default' => array(
              array(
                'title' => esc_html__('Quality assurance', 'medstore-helpers'),
              ),
              array(
                'title' => esc_html__('1 year warranty', 'medstore-helpers'),
              ),
              array(
                'title' => esc_html__('Good policy', 'medstore-helpers'),
              ),
            ),
          ),

          array(
            'type'    => 'subheading',
            'content' => esc_html__('My Account', 'medstore-helpers'),
          ), 
          array(
            'id'      => 'login_banner',
            'type'    => 'media',
            'preview' => true,
            'title'   => esc_html__('Login banner', 'medstore-helpers'),
            'library' => 'image',
          ),
          array(
            'id'      => 'register_banner',
            'type'    => 'media',
            'preview' => true,
            'title'   => esc_html__('Register banner', 'medstore-helpers'),
            'library' => 'image',
          ),

          array(
            'type'    => 'subheading',
            'content' => esc_html__('Track order form', 'medstore-helpers'),
          ), 
          array(
            'id'      => 'track_order_banner',
            'type'    => 'media',
            'preview' => true,
            'title'   => esc_html__('Banner', 'medstore-helpers'),
            'library' => 'image',
          ),
        )
      ) );
    }
    
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Social', 'medstore-helpers'),
      'icon' => 'fa fa-share-alt',
      'fields' => array(
  
        array(
          'id'           => 'social_facebook',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Facebook url', 'medstore-helpers'),
        ),
        array(
          'id'           => 'social_twitter',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Twitter url', 'medstore-helpers'),
        ),
        array(
          'id'           => 'social_instagram',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Instagram url', 'medstore-helpers'),
        ),
        array(
          'id'           => 'social_printest',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Pinterest url', 'medstore-helpers'),
        ),
        array(
          'id'           => 'social_youtube',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Youtube url', 'medstore-helpers'),
        ),
        array(
          'id'           => 'social_linkedin',
          'type'         => 'text',
          'default'      => '#',
          'title'        => esc_html__('Linkedin url', 'medstore-helpers'),
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Announcement Bar', 'medstore-helpers'),
      'icon' => 'fa fa-bell',
      'fields' => array(
        
        array(
          'id'      => 'text_announcement',
          'type'    => 'textarea',
          'title'   => esc_html__('Announcement text', 'medstore-helpers'),
          'default' => ''
        ),
        array(
          'id'     => 'page_announcement',
          'type'   => 'repeater',
          'title'  => esc_html__('Announcement pages', 'medstore-helpers'),
          'fields' => array(
        
            array(
              'id'          => 'page_id',
              'type'        => 'select',
              'chosen'      => true,
              'title'       => esc_html__('Select a page', 'medstore-helpers'),
              'placeholder' => esc_html__('Select a page', 'medstore-helpers'),
              'options'     => 'pages',
              'query_args'  => array(
                'posts_per_page' => -1 // for get all pages (also it's same for posts).
              )
            ),
        
          ),
        ),
        
        array(
          'id'     => 'social_announcement',
          'type'   => 'repeater',
          'title'  => esc_html__('Social links', 'medstore-helpers'),
          'fields' => array(
        
            array(
              'id'          => 'social_id',
              'type'        => 'select',
              'chosen'      => true,
              'title'       => esc_html__('Select a channel', 'medstore-helpers'),
              'options'     => array(
                'facebook'  => esc_html__('Facebook', 'medstore-helpers'),
                'twitter'  => esc_html__('Twitter', 'medstore-helpers'),
                'instagram'  => esc_html__('Instagram', 'medstore-helpers'),
                'printest'  => esc_html__('Printest', 'medstore-helpers'),
                'youtube'  => esc_html__('Youtube', 'medstore-helpers')
              ),
            ),
        
          ),
        ), 
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Style', 'medstore-helpers'),
        ),
        array(
          'id'    => 'bg_color_announcement',
          'type'  => 'color',
          'default' => '#F6F6F6',
          'title' => esc_html__('Background color', 'medstore-helpers'),
        ),
        array(
          'id'      => 'text_color_announcement',
          'type'    => 'link_color',
          'title'   => esc_html__('Text color', 'medstore-helpers'),
          'default' => array(
            'color' => '#686868',
            'hover' => '#436CFF',
          ),
        ),
        array(
          'id'    => 'spacing_announcement',
          'type'  => 'spacing',
          'title' => esc_html__('Spacing', 'medstore-helpers'),
          'left'  => false,
          'right' => false,
          'default'  => array(
            'top'    => '5',
            'bottom' => '5',
            'unit'   => 'px',
          ),
          'units' => array( 'px' ),
        ),             
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Color', 'medstore-helpers'),
      'icon' => 'fa fa-palette',
      'fields' => array(
  
        array(
          'id'      => 'primary-color',
          'type'    => 'color',
          'title'   => esc_html__('Primary Color', 'medstore-helpers'),
          'default' => '#436CFF'
        ),
        array(
          'id'      => 'background-color',
          'type'    => 'color',
          'title'   => esc_html__('Background Color', 'medstore-helpers'),
          'default' => '#ffffff'
        ),
        array(
          'id'      => 'heading-color',
          'type'    => 'color',
          'title'   => esc_html__('Heading Color', 'medstore-helpers'),
          'default' => '#151515'
        ),
        array(
          'id'      => 'body-color',
          'type'    => 'color',
          'title'   => esc_html__('Body Color', 'medstore-helpers'),
          'default' => '#151515'
        ), 
        array(
          'id'      => 'menu-color',
          'type'    => 'color',
          'title'   => esc_html__('Menu Color', 'medstore-helpers'),
          'default' => '#686868'
        ), 
        array(
          'id'      => 'widget-color',
          'type'    => 'color',
          'title'   => esc_html__('Widget title Color', 'medstore-helpers'),
          'default' => '#343434'
        ),                      
  
      )
    ) );
    
    // Create a section
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Typography', 'medstore-helpers'),
      'icon' => 'fa fa-font',
      'fields' => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Body', 'medstore-helpers'),
        ),
        array(
          'id'    => 'body_second_typography',
          'type'  => 'typography',
          'title' => esc_html__('Primary Font', 'medstore-helpers'),
          'default' => array(
            'font-family' => 'Josefin Sans',
            'type'        => 'google',
            'font-weight' => '400'
          ),
          'font_weight' => false,
          'font_style' => true,
          'font_size' => false,
          'line_height' => false,
          'letter_spacing' => false,
          'text_align' => false,
          'text_transform' => false,
          'color' => false,
          'preview' => true,
          'subset' => false
        ),
        array(
          'id'    => 'body_typography',
          'type'  => 'typography',
          'title' => esc_html__('Logo Font', 'medstore-helpers'),
          'default' => array(
            'font-family' => 'Montserrat',
            'type'        => 'google',
            'font-weight' => '400'
          ),
          'font_weight' => false,
          'font_style' => true,
          'font_size' => false,
          'line_height' => false,
          'letter_spacing' => false,
          'text_align' => false,
          'text_transform' => false,
          'color' => false,
          'preview' => true,
          'subset' => false
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Heading', 'medstore-helpers'),
        ),
        array(
          'id'    => 'heading_typography',
          'type'  => 'typography',
          'title' => esc_html__('Font', 'medstore-helpers'),
          'default' => array(
            'font-family' => 'Josefin Sans',
            'type'        => 'google',
            'font-weight' => '700'
          ),
          'font_weight' => false,
          'font_style' => true,
          'font_size' => false,
          'line_height' => false,
          'letter_spacing' => false,
          'text_align' => false,
          'text_transform' => false,
          'color' => false,
          'preview' => true,
          'subset' => false
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Menu', 'medstore-helpers'),
        ),
        array(
          'id'    => 'menu_typography',
          'type'  => 'typography',
          'title' => esc_html__('Font', 'medstore-helpers'),
          'default' => array(
            'font-family' => 'Josefin Sans',
            'type'        => 'google',
            'font-weight' => '400'
          ),
          'font_weight' => false,
          'font_style' => true,
          'font_size' => false,
          'line_height' => false,
          'letter_spacing' => false,
          'text_align' => false,
          'text_transform' => false,
          'color' => false,
          'preview' => true,
          'subset' => false
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Button', 'medstore-helpers'),
        ),
        array(
          'id'    => 'button_typography',
          'type'  => 'typography',
          'title' => esc_html__('Font', 'medstore-helpers'),
          'default' => array(
            'font-family' => 'Josefin Sans',
            'type'        => 'google',
            'font-weight' => '400'
          ),
          'font_weight' => false,
          'font_style' => true,
          'font_size' => false,
          'line_height' => false,
          'letter_spacing' => false,
          'text_align' => false,
          'text_transform' => false,
          'color' => false,
          'preview' => true,
          'subset' => false
        ),
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('404 Page', 'medstore-helpers'),
      'icon' => 'fa fa-exclamation-triangle',
      'fields' => array(
  
        array(
          'id'           => '404_title',
          'type'         => 'text',
          'title'        => esc_html__('404 Title', 'medstore-helpers'),
          'default'      => esc_html__('Oops! That page can&rsquo;t be found.', 'medstore-helpers'),
        ),
        array(
          'id'      => '404_content',
          'type'    => 'textarea',
          'title'   => esc_html__('404 Content', 'medstore-helpers'),
          'default' => esc_html__('The page you\'re looking for isn\'t available. Try to search again or use the go to.', 'medstore-helpers')
        ),        
        array(
          'id'      => '404_img',
          'type'    => 'media',
          'title'   => esc_html__('404 Image', 'medstore-helpers'),
          'library' => 'image',
          'default' => array(
            'url' => _MEDSTORE_IMG . '/404.png'
          )
        ),       
        array(
          'id'      => '404_bg',
          'type'    => 'media',
          'title'   => esc_html__('404 Background Image', 'medstore-helpers'),
          'library' => 'image',
          'default' => array(
            'url' => _MEDSTORE_IMG . '/bg-404.png'
          )
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Custom CSS', 'medstore-helpers'),
      'icon' => 'fa fa-css3',
      'fields' => array(
  
        //
        // A text field
        array(
          'id'       => 'custom_css',
          'type'     => 'code_editor',
          'title'    => esc_html__('Custom CSS', 'medstore-helpers'),
          'settings' => array(
            'theme'  => 'mbo',
            'mode'   => 'css',
          ),
          'default'  => '.element{ color: #ffbc00; }',
        ),
        
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Backup', 'medstore-helpers'),
      'icon' => 'fa fa-shield-alt',
      'fields' => array(
  
        array(
          'type' => 'backup',
        ),               
  
      )
    ) );
  
  }
  