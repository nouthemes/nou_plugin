<?php

/**
 * Layout Compiler
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */
class Medstore_Helpers_Layout_Compiler {

	public static $inline_styles = '';
}
