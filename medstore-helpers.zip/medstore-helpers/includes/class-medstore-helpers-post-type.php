<?php

/**
 * Custom post type for Medstore Helpers
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */
class Medstore_Helpers_Post_Type {

	public function __construct() {
        add_action( 'init', [$this, 'create_product_brand'], 0 );
	}

    public function create_product_brand(){
        $labels = array(
            'name'              => _x( 'Brands', 'taxonomy general name', 'medstore-helpers' ),
            'singular_name'     => _x( 'Brand', 'taxonomy singular name', 'medstore-helpers' ),
            'search_items'      => __( 'Search Brands', 'medstore-helpers' ),
            'all_items'         => __( 'All Brands', 'medstore-helpers' ),
            'parent_item'       => __( 'Parent Brand', 'medstore-helpers' ),
            'parent_item_colon' => __( 'Parent Brand:', 'medstore-helpers' ),
            'edit_item'         => __( 'Edit Brand', 'medstore-helpers' ),
            'update_item'       => __( 'Update Brand', 'medstore-helpers' ),
            'add_new_item'      => __( 'Add New Brand', 'medstore-helpers' ),
            'new_item_name'     => __( 'New Brand Name', 'medstore-helpers' ),
            'menu_name'         => __( 'Brand', 'medstore-helpers' ),
            'choose_from_most_used'      => __( 'Choose from the most used brand', 'medstore-helpers' ),
        );
    
        $args = array(
            'hierarchical'      => true,
            'labels'            => $labels,
            'show_ui'           => true,
            'show_admin_column' => true,
            'query_var'         => true,
            'rewrite'           => array( 'slug' => 'product-brand' ),
        );
        register_taxonomy( 'product_brand', 'product', $args );
    }
}
