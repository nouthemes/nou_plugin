<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Shop Info
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Medstore_Helpers_Widget_Shop_Info {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->form();
		$this->widget();
	}

	/**
	 * Creating widget front-end
	*/
	public function widget() {

		if( ! function_exists( 'medstore_helpers_widget_shop_info' ) ) {
			function medstore_helpers_widget_shop_info( $args, $instance ) {
				
                $logo_type = medstore_get_option('logo_type');
        		$logo_text = medstore_get_option('logo_text', get_bloginfo( 'name' ));
                $address = medstore_get_option('address');
                $hotline = medstore_get_option('hotline');
                $email = medstore_get_option('contact_email');

                echo medstore_esc($args['before_widget']);
                    ?>
                    <div class="flex flex-col gap-6">
                        <a href="<?php echo esc_url( home_url( '/' ) );?>">
                            <?php 
                            if($logo_type === 'img'):
                                $logo_img = medstore_get_option('logo_img');
                                if(!empty($logo_img)):
                                ?>
                                <img src="<?php echo esc_url($logo_img);?>" alt="<?php bloginfo( 'name' ); ?>">
                                <?php
                                else:
                                    echo '<span class="text-logo">';
                                        echo esc_html($logo_text);
                                    echo '</span>';
                                endif;
                            else:
                                echo '<span class="text-logo">';
                                    echo esc_html($logo_text);
                                echo '</span>';
                            endif;
                            ?>
                        </a>
                        <?php
                        echo '<ul class="flex flex-col gap-4">';
                            if(!empty($address)):
                                echo '<li class="flex items-center gap-5"><i class="fas fa-solid fa-location-dot"></i><span>'.esc_html($address).'</span></li>';
                            endif;
                            if(!empty($email)):
                                echo '<li class="flex items-center gap-5"><i class="fas fa-regular fa-envelope"></i><span>'.esc_html($email).'</span></li>';
                            endif;
                            if(!empty($hotline)):
                                echo '<li class="flex items-center gap-5"><i class="fas fa-solid fa-phone"></i><span>'.esc_html($hotline).'</span></li>';
                            endif;
                        echo '</ul>';
                    echo '</div>';
                echo medstore_esc($args['after_widget']);
		
			}
		}

	}
		
	// Widget Backend 
	public function form() {

		if( class_exists( 'CSF' ) ) {
			CSF::createWidget( 
				'medstore_helpers_widget_shop_info', 
				array(
					'title'       => esc_html__('* Medstore - Shop Info', 'medstore-helpers'),
					'classname'   => 'widget-shop-info',
					'description' => esc_html__( 'Contact info for store.', 'medstore-helpers' ),
					'fields'      => array(
				
						array(
							'id'      => 'title',
							'type'    => 'text',
							'title'   => esc_html__('Title', 'medstore-helpers'),
						),
				
					)
				) 
			);	
		}
	}

}

?>