<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Follow us
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Medstore_Helpers_Widget_Social {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->form();
		$this->widget();
	}

	/**
	 * Creating widget front-end
	*/
	public function widget() {

		if( ! function_exists( 'medstore_helpers_widget_follow_us' ) ) {
			function medstore_helpers_widget_follow_us( $args, $instance ) {
				
                $facebook = medstore_get_option('social_facebook');
                $twitter = medstore_get_option('social_twitter');
                $instagram = medstore_get_option('social_instagram');
                $pinterest = medstore_get_option('social_printest');
                $youtube = medstore_get_option('social_youtube');
                $linkedin = medstore_get_option('social_linkedin');


                echo medstore_esc($args['before_widget']);
        
                    if ( ! empty( $instance['title'] ) ) {
                        echo medstore_esc($args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title']);
                    }

                    echo '<ul class="flex items-center gap-6">';
                
                        if(!empty($facebook)){?>
                            <li><a href="<?php echo esc_url($facebook);?>" target="_blank"><i class="fa-brands fa-square-facebook text-xl !text-[#0866FF]"></i></a></li>
                        <?php }

                        if(!empty($twitter)){?>
                            <li><a href="<?php echo esc_url($twitter);?>" target="_blank"><i class="fa-brands fa-square-x-twitter text-xl !text-[#343434]"></i></a></li>
                        <?php }

                        if(!empty($instagram)){?>
                            <li><a href="<?php echo esc_url($instagram);?>" target="_blank"><i class="fa-brands fa-square-instagram text-xl !text-[#bd081c]"></i></a></li>
                        <?php }

                        if(!empty($pinterest)){?>
                            <li><a href="<?php echo esc_url($pinterest);?>" target="_blank"><i class="fa-brands fa-square-pinterest text-xl !text-[#bd081c]"></i></a></li>
                        <?php }

                        if(!empty($youtube)){?>
                            <li><a href="<?php echo esc_url($youtube);?>" target="_blank"><i class="fa-brands fa-square-youtube text-xl"></i></a></li>
                        <?php }

                        if(!empty($linkedin)){?>
                            <li><a href="<?php echo esc_url($linkedin);?>" target="_blank"><i class="fa-brands fa-linkedin text-xl !text-[#0A66C2]"></i></a></li>
                        <?php }

                    echo '</ul>';
        
                    
                echo medstore_esc($args['after_widget']);
		
			}
		}

	}
		
	// Widget Backend 
	public function form() {

		if( class_exists( 'CSF' ) ) {
			CSF::createWidget( 
				'medstore_helpers_widget_follow_us', 
				array(
					'title'       => esc_html__('* Medstore - Follow us', 'medstore-helpers'),
					'classname'   => 'widget-follow-us',
					'description' => esc_html__( 'Social account for store.', 'medstore-helpers' ),
					'fields'      => array(
				
						array(
							'id'      => 'title',
							'type'    => 'text',
							'title'   => esc_html__('Title', 'medstore-helpers'),
						),
				
					)
				) 
			);	
		}
	}

}

?>