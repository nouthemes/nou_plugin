<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Payment Accepted
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Medstore_Helpers_Widget_Payment_Img {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->form();
		$this->widget();
	}

	/**
	 * Creating widget front-end
	*/
	public function widget() {

		if( ! function_exists( 'medstore_helpers_widget_payment_img' ) ) {
			function medstore_helpers_widget_payment_img( $args, $instance ) {
				
				$photos = $instance['payment_photos'];
				if(!empty($photos)){
					echo medstore_esc($args['before_widget']);
			
						if ( ! empty( $instance['title'] ) ) {
							echo medstore_esc($args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title']);
						}

						echo '<ul class="flex items-center gap-2">';
					
							foreach ( $photos as $photo ) {
								if(!empty($photo['img']) && !empty($photo['img']['url'])):
									echo '<li><img src="'.esc_attr( $photo['img']['url'] ).'" alt="" /></li>';
								endif;

							}

						echo '</ul>';
			
						
					echo medstore_esc($args['after_widget']);
				}
		
			}
		}

	}
		
	// Widget Backend 
	public function form() {

		if( class_exists( 'CSF' ) ) {
			CSF::createWidget( 
				'medstore_helpers_widget_payment_img', 
				array(
					'title'       => esc_html__('* Medstore - Payments Accepted', 'medstore-helpers'),
					'classname'   => 'widget-payment-accepted',
					'description' => esc_html__( 'Upload a payments gateway image.', 'medstore-helpers' ),
					'fields'      => array(
				
						array(
							'id'      => 'title',
							'type'    => 'text',
							'title'   => esc_html__('Title', 'medstore-helpers'),
						),
				
						array(
							'id'     => 'payment_photos',
							'type'   => 'repeater',
							'title'  => esc_html__('Payment gateway images', 'medstore-helpers'),
							'fields' => array(
							
								array(
									'id'    => 'img',
									'type'  => 'media',
									'library' => 'image',
									'title' => esc_html__('Image', 'medstore-helpers')
								),
							
							),
						),
				
					)
				) 
			);	
		}
	}

}

?>