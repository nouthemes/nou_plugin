<?php
/**
 * The file that defines the Widget class
 * 
 * @since      1.0.0
 * @package    medstore-helpers
 * @subpackage medstore-helpers/includes/widgets
 * @author     nouthemes <nouthemes@gmail.com>
*/

class Medstore_Helpers_Widget_Main {

	public function __construct() {
		$this->register_widgets();
	}

	public function register_widgets() {
		new Medstore_Helpers_Widget_Payment_Img();
		new Medstore_Helpers_Widget_Social();
		new Medstore_Helpers_Widget_Shop_Info();
		new Medstore_Helpers_Widget_Posts();
		new Medstore_Helpers_Widget_Terms();
	}
}
?>