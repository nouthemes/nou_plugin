<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Follow us
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Medstore_Helpers_Widget_Terms {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->form();
		$this->widget();
	}

	/**
	 * Creating widget front-end
	*/
	public function widget() {

		if( ! function_exists( 'medstore_helpers_widget_terms' ) ) {
			function medstore_helpers_widget_terms( $args, $instance ) {
				
                if(!empty($instance['taxonomy'])){
                    $terms = medstore_link_taxonomy_terms($instance['taxonomy']);
                    if(!empty($terms)){
                        $currentTermId = '';

                        if(is_tax()){
                            $currentTermId = get_queried_object_id();
                        }

                        echo medstore_esc($args['before_widget']);
                
                            if ( ! empty( $instance['title'] ) ) {
                                echo medstore_esc($args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title']);
                            }

                            ?>
                            <ul class="flex flex-col gap-3">
                                <?php
                                foreach($terms as $term){ 
                                    ?>
                                    <li>
                                        <a href="<?php echo esc_url($term['url']); ?>" class="flex items-center justify-between">
                                            <div class="ps-checkbox flex items-center" @click="(event) => redirectTo('<?php echo esc_url($term['url']); ?>', event)">
                                                <input <?php checked($term['id'], $currentTermId, true);?> id="term-<?php echo esc_attr($term['id']);?>" type="checkbox" value="<?php echo esc_attr($term['id']);?>" class="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 focus:ring-2">
                                                <label for="term-<?php echo esc_attr($term['id']);?>" class="ms-3"><?php echo esc_html($term['name']);?></label>
                                            </div>
                                            <span><?php echo esc_html($term['count']);?></span>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>  
                            </ul>
                            <?php
                        echo medstore_esc($args['after_widget']);
                    }
                }
			}
		}

	}
		
	// Widget Backend 
	public function form() {

		if( class_exists( 'CSF' ) ) {
            
			CSF::createWidget( 
				'medstore_helpers_widget_terms', 
				array(
					'title'       => esc_html__('* Medstore - Taxonomy', 'medstore-helpers'),
					'classname'   => 'widget-terms',
					'description' => esc_html__( 'List term of taxonomy.', 'medstore-helpers' ),
					'fields'      => array(
				
						array(
							'id'      => 'title',
							'type'    => 'text',
							'title'   => esc_html__('Title', 'medstore-helpers'),
						),
                        array(
                            'id'          => 'taxonomy',
                            'type'        => 'select',
                            'title'       => esc_html__('Taxonomy', 'medstore-helpers'),
                            'placeholder' => esc_html__('Select a taxonomy', 'medstore-helpers'),
                            'options'     => [
                                'category' => esc_html__('Category', 'medstore-helpers'),
                                'post_tag' => esc_html__('Tag', 'medstore-helpers'),
                                'product_cat' => esc_html__('Product Category', 'medstore-helpers'),
                                'product_tag' => esc_html__('Product Tag', 'medstore-helpers'),
                                'product_brand' => esc_html__('Product Brand', 'medstore-helpers'),
                            ],
                            'chosen'      => true,
                        ),
				
					)
				) 
			);	
		}
	}

}

?>