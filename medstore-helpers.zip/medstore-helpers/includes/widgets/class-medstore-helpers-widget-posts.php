<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Posts
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Medstore_Helpers_Widget_Posts {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$this->form();
		$this->widget();
	}

	/**
	 * Creating widget front-end
	*/
	public function widget() {

		if( ! function_exists( 'medstore_helpers_widget_posts' ) ) {
			function medstore_helpers_widget_posts( $args, $instance ) {
				
                $cat = $instance['cat'];
                $number = !empty($instance['number']) ? $instance['number'] : 4;

                $posts_args = [
                    'post_type' => 'post', 
                    'posts_per_page' => intval($number), 
                    'ignore_sticky_posts' => true, 
                    'post_status' => 'publish'
                ];

                if(!empty($cat) && $cat > 0){
                    $posts_args['cat'] = $cat;
                }

                $query = new WP_Query($posts_args);
                if($query->have_posts()):
                    echo medstore_esc($args['before_widget']);
            
                        if ( ! empty( $instance['title'] ) ) {
                            echo medstore_esc($args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title']);
                        }

                        echo '<ul class="flex flex-col gap-3">';
                            while($query->have_posts()){ 
                                $query->the_post();

                                $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
                                if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
                                    $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
                                }

                                $time_string = sprintf(
                                    $time_string,
                                    esc_attr( get_the_date( DATE_W3C ) ),
                                    esc_html( get_the_date() ),
                                    esc_attr( get_the_modified_date( DATE_W3C ) ),
                                    esc_html( get_the_modified_date() )
                                );
                                ?>
                                <li class="flex gap-3">
                                    <div class="content flex flex-col justify-between gap-3">
                                        <?php 
                                            $categories_list = get_the_category_list(' ');
                                            if ( $categories_list ) {
                                                echo '<div class="ps-post__categories !gap-3">' . wp_kses_post( $categories_list ) . '</div>';
                                            }
                                        ?>
                                        <a href="<?php the_permalink();?>" class="title"><?php the_title();?></a>
                                        <div class="post-meta flex items-center gap-3">
                                            <div class="post-date"><?php echo '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';?></div>
                                            <div class="currency-divider"></div>
                                            <div class="post-author"><?php echo '<a class="url fn n" href="' . esc_url( get_author_posts_url( $query->post->post_author ) ) . '">' . esc_html( get_the_author_meta('display_name', $query->post->post_author) ) . '</a>';?></div>
                                        </div>
                                    </div>
                                    <?php if( has_post_thumbnail( get_the_ID() ) ){?>
                                        <div class="thumbnail">
                                            <a href="<?php the_permalink();?>">
                                                <?php the_post_thumbnail('medstore_102');?>
                                            </a>
                                        </div>
                                    <?php }?>
                                </li>
                                <?php
                            }
                        echo '</ul>';
            
                        
                    echo medstore_esc($args['after_widget']);
                endif;
                wp_reset_postdata();
			}
		}

	}
		
	// Widget Backend 
	public function form() {

		if( class_exists( 'CSF' ) ) {
			CSF::createWidget( 
				'medstore_helpers_widget_posts', 
				array(
					'title'       => esc_html__('* Medstore - Posts', 'medstore-helpers'),
					'classname'   => 'widget-custom-posts',
					'description' => esc_html__( 'Get posts with parameter.', 'medstore-helpers' ),
					'fields'      => array(
				
						array(
							'id'      => 'title',
							'type'    => 'text',
							'title'   => esc_html__('Title', 'medstore-helpers'),
						),
                        array(
                            'id'          => 'cat',
                            'type'        => 'select',
                            'title'       => esc_html__('Category', 'medstore-helpers'),
                            'placeholder' => esc_html__('Select a category', 'medstore-helpers'),
                            'options'     => 'categories',
                            'chosen'      => true,
                        ),
                        array(
                            'id'    => 'number',
                            'type'  => 'number',
                            'default' => 4,
                            'title' => esc_html__('Number of posts show', 'medstore-helpers'),
                        ),
				
					)
				) 
			);	
		}
	}

}

?>