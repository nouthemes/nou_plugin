<?php
/**
 * Meta box options
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */
// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

    //
    // Set a unique slug-like ID
    $prefix = _MEDSTORE_META_KEY;
    global $post;
  
    //
    // Create a metabox
    CSF::createMetabox( $prefix, array(
      'title'     => esc_html__('Layout Settings', 'medstore-helpers'),
      'post_type' => ['post', 'page', 'product'],
    ) );
      
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('General', 'medstore-helpers'),
      'post_type' => ['post', 'page'],
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Title', 'medstore-helpers'),
        ),
        array(
          'id'      => 'post_title_enable',
          'type'      => 'switcher',
          'title'   => esc_html__('Enable Title', 'medstore-helpers'),
          'default' => true,
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Custom title', 'medstore-helpers'),
          'dependency' => array( 'post_title_enable', '==', true ),
        ), 
           
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Single', 'medstore-helpers'),
        ),                  
        array(
          'id'        => 'single-heading',
          'type'      => 'select',
          'title'     => esc_html__('Heading section Style', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Heading Style #1', 'medstore-helpers'),
            '2'  => esc_html__('Heading Style #2', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),             
  
      )
    ) );
    
    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Header', 'medstore-helpers'),
      'fields' => array(
        
        array(
          'id'          => 'header-style',
          'type'        => 'select',
          'title'       => esc_html__('Header Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, header style follow theme option.', 'medstore-helpers'),
          'placeholder' => esc_html__('Select a style', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Header Style #1', 'medstore-helpers'),
            '2'  => esc_html__('Header Style #2', 'medstore-helpers'),
            '3'  => esc_html__('Header Style #3', 'medstore-helpers'),
            '4'  => esc_html__('Header Style #4', 'medstore-helpers'),
          ),
          'chosen'      => true,
        ),  
        array(
          'id'        => 'announcement_enable',
          'type'      => 'select',
          'title'     => esc_html__('Announcement bar enabled', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'dependency' => array( 'header-style', '==', '1' ),
          'chosen'      => true,
        ), 
         
        array(
          'id'          => 'header-style-mobile',
          'type'        => 'select',
          'title'       => esc_html__('Mobile Header Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, header style follow theme option.', 'medstore-helpers'),
          'placeholder' => esc_html__('Select a style', 'medstore-helpers'),
          'options'     => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Header Style #1', 'medstore-helpers'),
            '2'  => esc_html__('Header Style #2', 'medstore-helpers'),
            '3'  => esc_html__('Header Style #3', 'medstore-helpers'),
            '4'  => esc_html__('Header Style #4', 'medstore-helpers'),
            '5'  => esc_html__('Header Style #5', 'medstore-helpers'),
          ),
          'chosen'      => true,
        ),               
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Breadcrumbs', 'medstore-helpers'),
      'icon' => 'fa fa-sitemap',
      'fields' => array(
   
        array(
          'id'        => 'breadcrumb_enable',
          'type'      => 'select',
          'title'     => esc_html__('Breadcrumbs enable', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),      
        array(
          'id'        => 'breadcrumb_style',
          'type'      => 'select',
          'title'     => esc_html__('Separate Style', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            'slash' => esc_html__('Slash', 'medstore-helpers'),
            'dot' => esc_html__('Dot', 'medstore-helpers'),
            'arrow' => esc_html__('Arrow', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Single', 'medstore-helpers'),
      'post_type' => ['product'],
      'fields' => array(
        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Product Policy', 'medstore-helpers'),
        ),                  
        array(
          'id'        => 'single_product_policy',
          'type'      => 'select',
          'title'     => esc_html__('Custom Policy', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Custom', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),   
        array(
          'id'     => 'product_policy',
          'type'   => 'repeater',
          'title'  => esc_html__('Product policy', 'medstore-helpers'),
          'fields' => array(
            
            array(
              'id'          => 'title',
              'type'        => 'text',
              'title'       => esc_html__('Policy title', 'medstore-helpers'),
            ),
        
          ),
          'default' => array(
            array(
              'title' => esc_html__('Quality assurance', 'medstore-helpers'),
            ),
            array(
              'title' => esc_html__('1 year warranty', 'medstore-helpers'),
            ),
            array(
              'title' => esc_html__('Good policy', 'medstore-helpers'),
            ),
          ),
          'dependency' => array( 'single_product_policy', '==', '1' ),
        ),          
  
      )
    ) );

    CSF::createSection( $prefix, array(
      'title'  => esc_html__('Footer', 'medstore-helpers'),
      'icon' => 'fa fa-ellipsis-h',
      'fields' => array(
   
        array(
          'id'        => 'newsletter_enable',
          'type'      => 'select',
          'title'     => esc_html__('Newsletter enable', 'medstore-helpers'),
          'subtitle'   => esc_html__('If empty, style follow theme option.', 'medstore-helpers'),
          'options'   => array(
            ''  => esc_html__('Default', 'medstore-helpers'),
            '1'  => esc_html__('Enable', 'medstore-helpers'),
            '2'  => esc_html__('Disable', 'medstore-helpers'),
          ),
          'default'   => '',
          'chosen'      => true,
        ),
      )
    ) );
  
  }
  