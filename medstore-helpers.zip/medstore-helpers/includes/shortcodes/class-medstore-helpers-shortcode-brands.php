<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Brands
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
		), $atts, 'medstore_brands' );

		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-section flex flex-col gap-7 ps-section__brands">
				<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>
					<div class="ps-section__header flex flex-col gap-3">
						<?php if(!empty($atts['title'])):?>
							<h3 class="ps-section__heading no-more-class">
								<?php echo wp_kses_post($atts['title']);?>
							</h3>
						<?php endif;?>
						<?php if(!empty($atts['desc'])):?>
							<div class="ps-section__description flex justify-center items-center">
								<div class="max-w-xl"><?php echo wp_kses_post($atts['desc']);?></div>
							</div>
						<?php endif;?>
					</div>
				<?php endif;?>
				
				<div class="ps-section__content">
                    <div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="10000" data-owl-gap="40" data-owl-nav="false" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="6" data-owl-item-xs="3" data-owl-item-sm="4" data-owl-item-md="5" data-owl-item-lg="6">
			          <?php echo do_shortcode($content);?>
			        </div>
				</div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Brands Carousel", "medstore-helpers" ),
	      	"base" => "medstore_brands",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"params" => array(
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Title", "medstore-helpers" ),
                    "param_name" => "title",
                ),
                array(
                    "type" => "textarea",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Description", "medstore-helpers" ),
                    "param_name" => "desc",
                ),
                
              ),
	      	"as_parent" => array('only' => 'medstore_brand_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>