<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Title
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'title' => '',
			'sub' => '',
            'class' => '',
            'text_color' => ''
		), $atts, 'medstore_title' );
		
		$color = !empty($atts['text_color']) ? sanitize_hex_color($atts['text_color']) : '#151515';

		ob_start();
			if(!empty($atts['title']) || !empty($atts['sub'])):
			?>
			<div class="shortcode-title flex flex-col gap-3 <?php echo esc_attr(!empty($atts['class']) ? esc_attr($atts['class'] ): '');?>">
	            <?php if(!empty($atts['title'])):?>
                    <h2 class="no-more-class shortcode-title__top font-bold" data-text-color="<?php echo esc_attr($color);?>"><?php echo esc_html($atts['title']);?></h2>
                <?php endif;?>
	            <?php if(!empty($atts['sub'])):?><p class="shortcode-title_bottom"><?php echo esc_html($atts['sub']);?></p><?php endif;?>
	        </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Title", "medstore-helpers" ),
	      	"base" => "medstore_title",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "medstore-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Subtitle", "medstore-helpers" ),
		            "param_name" => "sub",
		        ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Heading color", "medstore-helpers" ),
		            "param_name" => "text_color",
                    "value" => '#151515',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class", "medstore-helpers" ),
		            "param_name" => "class",
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
	      	)
	    ) );
		endif;
	}
}
?>