<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Products
{
	
	/**
	 * Products
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'style' => 'grid',
			'item_style' => 'normal',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'col' => 5,
			'flash_sale' => '',
			'btn_position' => 'top'
		), $atts, 'medstore_products' );

		$date_on_sale_to = !empty($atts['flash_sale']) ? $atts['flash_sale'] : ''; // YYYY-MM-DDTHH:MM:SS
		$showSale = false;
		$sale_price_dates_to = '';
		$item_style = isset($atts['item_style']) ? $atts['item_style'] : 'normal';

		if(!empty($date_on_sale_to)){
			$sale_price_dates_to = date_i18n( 'Y-m-d\TH:i:s', date_timestamp_get(date_create($date_on_sale_to)) );
			if($date_on_sale_to > current_time('timestamp')){
				$showSale = true;
			}
		}
		
		$style = !empty($atts['style']) ? $atts['style'] : 'grid';
		$col = (!empty($atts['col']) && intval($atts['col'])) ? intval($atts['col']) : 5;
		$btn_position = !empty($atts['btn_position']) ? $atts['btn_position'] : 'top';

		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
				?>
				<div class="woocommerce ps-section flex flex-col gap-12 ps-section__products <?php if($showSale){ echo 'show-loop-sale-process';}?>">
					<?php if(!empty($atts['title'])):?>

						<?php if($btn_position === 'top'):?>
							<div class="ps-section__header flex justify-between items-center">
						<?php else:?>
							<div class="ps-section__header flex justify-center items-center">
						<?php endif;?>

							<h3 class="ps-section__heading no-more-class flex items-center gap-6">
								<span><?php echo wp_kses_post($atts['title']);?></span>

								<?php if($showSale):?>
									<medstore-count-down date="<?php echo esc_attr($sale_price_dates_to);?>"></medstore-count-down>
								<?php endif;?>
							</h3>

							<?php if($btn_position === 'top'):?>
								<a href="<?php echo esc_url(get_permalink(get_option('woocommerce_shop_page_id')));?>" class="view-all no-more-class"><?php esc_html_e('See all products', 'medstore-helpers');?></a>
							<?php endif;?>
						</div>
					<?php endif;?>
					
					<div class="ps-section__content products ps-section__content-products-<?php echo esc_attr($item_style);?>">
						<?php 
						if($style == 'grid'){
							?>
							<div class="w-full section-products">
								<div class="w-full grid-layout">
									<ul class="view-grid grid grid-cols-1 md:grid-cols-3 lg:grid-cols-<?php echo esc_attr($col);?> gap-1">
										<?php while($products->have_posts()): $products->the_post();?>
											<?php 
												if($item_style == 'buy_now'){
													wc_get_template_part('content', 'product-buy-now');
												}elseif($item_style == 'simple'){
													wc_get_template_part('content', 'product-simple');
												}else{
													wc_get_template_part('content', 'product');
												}
											?>
										<?php endwhile;?>
									</ul>
								</div>
							</div>
							<?php
						}else{
							?>
							<div class="view-grid owl-slider owl-slider--best-seller" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="30" data-owl-nav="true" data-owl-dots="true" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="<?php echo esc_attr($col);?>" data-owl-item-xs="1" data-owl-item-sm="2" data-owl-item-md="3" data-owl-item-lg="<?php echo esc_attr($col);?>">
								<?php while($products->have_posts()): $products->the_post();?>
									<?php 
										if($item_style == 'buy_now'){
											wc_get_template_part('content', 'product-buy-now');
										}elseif($item_style == 'simple'){
											wc_get_template_part('content', 'product-simple');
										}else{
											wc_get_template_part('content', 'product');
										}
									?>
								<?php endwhile;?>
							</div>
							<?php
						}
						?>
					</div>

					<?php if(!empty($atts['title']) && $style == 'grid' && $btn_position === 'bottom'):?>
						<a href="<?php echo esc_url(get_permalink(get_option('woocommerce_shop_page_id')));?>" class="mx-auto max-w-44 btn btn-outline-primary no-more-class"><?php esc_html_e('See all products', 'medstore-helpers');?></a>
					<?php endif;?>
				</div>
			<?php endif;
            wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
        $termsStatusArr = [
            esc_html__( "Choose a Category", "medstore-helpers") => ''
        ];

        $termStatus = medstore_link_taxonomy_terms('product_cat', -1, true);
        foreach($termStatus as $term){
            $termsStatusArr[$term['name']] = $term['slug'];
        }

		vc_map( array(
	      	"name" => esc_html__( "Medstore - Products", "medstore-helpers" ),
	      	"base" => "medstore_products",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	'description' => esc_html__('Products display type Slider or Grid', "medstore-helpers"),
    		"params" => array(
				array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Title", "medstore-helpers" ),
                    "param_name" => "title",
                ),
				array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Flash Sale(YYYY-MM-DD)", "medstore-helpers" ),
                    "param_name" => "flash_sale",
                ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", "medstore-helpers" ),
		            "param_name" => "style",
                    "std"   => "grid",
		            "value" => array(
                        esc_html__('Grid', "medstore-helpers") => 'grid', 
                        esc_html__('Slider', "medstore-helpers") => 'slider'
                    ), 
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of item show", "medstore-helpers" ),
		            "param_name" => "item_style",
                    "std"   => "normal",
		            "value" => array(
                        esc_html__('Normal', "medstore-helpers") => 'normal', 
                        esc_html__('Buy now', "medstore-helpers") => 'buy_now',
                        esc_html__('Simple', "medstore-helpers") => 'simple',
                    ), 
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Column", "medstore-helpers" ),
		            "param_name" => "col",
                    "std"   => 5,
		            "value" => array(
                        5 => '5', 
                        4 => '4', 
                        3 => '3', 
                        2 => '2'
                    ),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Position of See All button", "medstore-helpers" ),
		            "param_name" => "btn_position",
                    "std"   => "top",
		            "value" => array(
                        esc_html__('Top', "medstore-helpers") => 'top', 
                        esc_html__('Bottom', "medstore-helpers") => 'bottom'
                    ), 
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", "medstore-helpers" ),
		            "param_name" => "type",
                    "std"   => "recent",
		            "value" => array(
                        esc_html__('--Select type--', "medstore-helpers") => '', 
                        esc_html__('Recent', "medstore-helpers") => 'recent', 
                        esc_html__('Featured', "medstore-helpers") => 'featured', 
                        esc_html__('Sale', "medstore-helpers") => 'onsale', 
                        esc_html__('Best sale', "medstore-helpers") => 'bestsale'
                    ), 
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", "medstore-helpers" ),
		            "param_name" => "ids",
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Category", "medstore-helpers" ),
                    "value" => $termsStatusArr,
                    "param_name" => "cat",
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show", "medstore-helpers" ),
		            "param_name" => "number",
                    "std"   => 10,
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : 10;
		$args = array(
			'post_type' => 'product', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
		switch ( $atts['type'] ) {
			case 'featured' :
				$args['tax_query'][] = array(
                        'taxonomy' => 'product_visibility',
                        'field'    => 'name',
                        'terms'    => 'featured',
                    );
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}

		return new WP_Query( apply_filters( 'medstore_products_shortcode_query_args', $args ) );
	}
}
?>