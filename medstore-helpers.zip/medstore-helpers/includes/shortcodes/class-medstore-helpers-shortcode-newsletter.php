<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Newsletter
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
            'title' => '',
			'input_title' => '',
			'btn_title' => '',
            'text_color' => '',
			'with_container' => '',
			'img' => '',
		), $atts, 'medstore_newsletter' );

        $color = !empty($atts['text_color']) ? sanitize_hex_color($atts['text_color']) : '#FFFFFF';
		$with_container = !empty($atts['with_container']) ? true : false;
		$title = !empty($atts['title']) ? $atts['title'] : esc_html__('Join our newsletter and get more discount', 'medstore');
		$input_title = !empty($atts['input_title']) ? $atts['input_title'] : esc_html__('Your email', 'medstore');
		$btn_title = !empty($atts['btn_title']) ? $atts['btn_title'] : esc_html__('Subscribe', 'medstore');
		$img = !empty($atts['img']) ? wp_get_attachment_image_url($atts['img'], 'full') : '';

		ob_start();
			?>
			<div class="pt-24 pb-24 ps-section ps-section--newsletter" <?php if(!empty($img)){echo 'data-background="'.esc_attr($img).'"';}?>>
				<?php if($with_container): ?>
					<div class="container mx-auto">
				<?php endif; ?>

					<div class="ps-section--newsletter__content flex flex-col items-start gap-6">
						<h3 class="ps-section--newsletter__title" data-text-color="<?php echo esc_attr($color);?>">
							<?php echo esc_html($title);?>
						</h3>
						<form method="post" action="<?php echo esc_url(home_url('/'));?>?na=s" class="ps-section--newsletter__form">
							<div class="flex flex-col md:flex-row items-center justify-center gap-4 md:gap-5">
								<input class="rounded border px-5 py-3" type="email" placeholder="<?php echo esc_html($input_title);?>" name="ne" required/>
								<button type="submit" class="transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-100 duration-300 focus:outline-none rounded btn-primary w-full px-8 py-3 text-base">
									<?php echo esc_html($btn_title);?>
								</button>
							</div>
						</form>
					</div>

				<?php if($with_container): ?>
					</div>
				<?php endif; ?>
			</div>
			<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Newsletter", "medstore-helpers" ),
	      	"base" => "medstore_newsletter",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
					"std" => esc_html__('Join our newsletter and get more discount', 'medstore'),
		            "heading" => esc_html__( "Title", "medstore-helpers" ),
		            "param_name" => "title",
		        ),array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
					"std" => esc_html__('Your email', 'medstore'),
		            "heading" => esc_html__( "Input placeholder", "medstore-helpers" ),
		            "param_name" => "input_title",
		        ),array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
					"std" => esc_html__('Subscribe', 'medstore'),
		            "heading" => esc_html__( "Button text", "medstore-helpers" ),
		            "param_name" => "btn_title",
		        ),
				array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Background", "medstore-helpers" ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Text color", "medstore-helpers" ),
		            "param_name" => "text_color",
                    "value" => '#FFFFFF',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "checkbox",
		            "class" => "",
		            'heading' => esc_html__( "Row with container", "bakery-helpers" ),
					'param_name' => 'with_container',
					'value' => '',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
	      	)
	    ) );
		endif;
	}
}
?>