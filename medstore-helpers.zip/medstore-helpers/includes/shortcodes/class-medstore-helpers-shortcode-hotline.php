<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Hotline
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'phone' => '',
            'class' => '',
            'text_color' => '',
            'text_size' => ''
		), $atts, 'medstore_hotline' );

		$id = uniqid('hotline-');
        $color = !empty($atts['text_color']) ? sanitize_hex_color($atts['text_color']) : '#F27061';
        $text_size = !empty($atts['text_size']) ? esc_attr($atts['text_size']) : '30px';

		ob_start();
			if(!empty($atts['phone'])):
			?>
			<div id="<?php echo esc_attr($id);?>" class="shortcode-hotline flex items-center gap-3 <?php echo esc_attr(!empty($atts['class']) ? esc_attr($atts['class'] ): '');?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="37" viewBox="0 0 36 37" fill="none">
                    <path d="M21 3.5C21 3.5 24.3 3.8 28.5 8C32.7 12.2 33 15.5 33 15.5" stroke="<?php echo esc_attr($color);?>" stroke-width="2" stroke-linecap="round"/>
                    <path d="M21.3125 8.80273C21.3125 8.80273 22.7974 9.227 25.0248 11.4544C27.2522 13.6818 27.6765 15.1667 27.6765 15.1667" stroke="<?php echo esc_attr($color);?>" stroke-width="2" stroke-linecap="round"/>
                    <path d="M15.0564 8.47426L16.0299 10.2187C16.9085 11.7929 16.5558 13.858 15.1721 15.2417C15.1721 15.2417 15.1721 15.2417 15.1721 15.2417C15.1719 15.2418 13.4938 16.9202 16.5368 19.9632C19.5791 23.0056 21.2575 21.3287 21.2583 21.3279C21.2583 21.3279 21.2583 21.3279 21.2583 21.3279C22.642 19.9442 24.7071 19.5915 26.2813 20.4701L28.0257 21.4436C30.4028 22.7702 30.6836 26.1039 28.5942 28.1933C27.3386 29.4488 25.8006 30.4257 24.1004 30.4902C21.2382 30.5987 16.3774 29.8743 11.5016 24.9984C6.62569 20.1226 5.90132 15.2618 6.00983 12.3996C6.07428 10.6994 7.0512 9.16135 8.30671 7.90585C10.3961 5.81642 13.7298 6.09716 15.0564 8.47426Z" stroke="<?php echo esc_attr($color);?>" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <span data-text-size="<?php echo esc_attr($text_size);?>" data-text-color="<?php echo esc_attr($color);?>" class="no-more-class font-bold">
                    <?php echo esc_html($atts['phone']);?>
                </span>
	        </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Hotline", "medstore-helpers" ),
	      	"base" => "medstore_hotline",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Phone number", "medstore-helpers" ),
		            "param_name" => "phone",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Font size(px)", "medstore-helpers" ),
		            "param_name" => "text_size",
                    "value" => '30px',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Text color", "medstore-helpers" ),
		            "param_name" => "text_color",
                    "value" => '#F27061',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class", "medstore-helpers" ),
		            "param_name" => "class",
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
	      	)
	    ) );
		endif;
	}
}
?>