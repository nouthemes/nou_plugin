<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Products_Sale
{
	
	/**
	 * Products
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'title' => '',
			'type' => '',
			'ids' => '',
			'cat' => '',
			'number' => '',
			'order_by' => '',
			'item_style' => 'normal',
			'col' => 3,
		), $atts, 'medstore_products_sale' );
		
		$style = 'grid';
		$col = (!empty($atts['col']) && intval($atts['col'])) ? intval($atts['col']) : 3;
		$btn_position = !empty($atts['btn_position']) ? $atts['btn_position'] : 'top';
		$item_style = !empty($atts['item_style']) ? $atts['item_style'] : 'normal';

		$products = self::get_products($atts);
		ob_start();
			if($products->have_posts()):
				?>
				<div class="woocommerce ps-section flex flex-col gap-12 ps-section__products show-loop-sale-process">
					<?php if(!empty($atts['title'])):?>
						<div class="ps-section__header flex justify-center items-center">
							<h3 class="ps-section__heading no-more-class flex items-center gap-6">
								<span><?php echo wp_kses_post($atts['title']);?></span>
							</h3>
						</div>
					<?php endif;?>
					
					<div class="ps-section__content products">
						<div class="w-full grid-layout">
							<ul class="view-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-<?php echo esc_attr($col);?> gap-7">
								<?php while($products->have_posts()): $products->the_post();?>
									<?php 
									if($item_style === 'buy_now'):
										wc_get_template_part('content', 'product-sale-buy-now');
									elseif($item_style === 'horizontal'):
										wc_get_template_part('content', 'product-sale-horizontal');
									else:
										wc_get_template_part('content', 'product-sale');
									endif;
									?>
								<?php endwhile;?>
							</ul>
						</div>
					</div>
				</div>
			<?php endif;
            wp_reset_postdata();
		return ob_get_clean();
		
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
        $termsStatusArr = [
            esc_html__( "Choose a Category", "medstore-helpers") => ''
        ];

        $termStatus = medstore_link_taxonomy_terms('product_cat', -1, true);
        foreach($termStatus as $term){
            $termsStatusArr[$term['name']] = $term['slug'];
        }

		vc_map( array(
	      	"name" => esc_html__( "Medstore - Products Flash sale", "medstore-helpers" ),
	      	"base" => "medstore_products_sale",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	'description' => esc_html__('Products with countdown', "medstore-helpers"),
    		"params" => array(
				array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Title", "medstore-helpers" ),
                    "param_name" => "title",
                ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of item show", "medstore-helpers" ),
		            "param_name" => "item_style",
                    "std"   => "normal",
		            "value" => array(
                        esc_html__('Normal', "medstore-helpers") => 'normal', 
                        esc_html__('Buy now', "medstore-helpers") => 'buy_now',
                        esc_html__('Horizontal', "medstore-helpers") => 'horizontal',
                    ), 
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Column", "medstore-helpers" ),
		            "param_name" => "col",
                    "std"   => 3,
		            "value" => array(
                        3 => '3', 
                        2 => '2',
                        1 => '1'
                    ),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of products show", "medstore-helpers" ),
		            "param_name" => "type",
                    "std"   => "onsale",
		            "value" => array(
                        esc_html__('--Select type--', "medstore-helpers") => '', 
                        esc_html__('Recent', "medstore-helpers") => 'recent', 
                        esc_html__('Featured', "medstore-helpers") => 'featured', 
                        esc_html__('Sale', "medstore-helpers") => 'onsale', 
                        esc_html__('Best sale', "medstore-helpers") => 'bestsale'
                    ), 
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "IDs posts, EX: 21,22,23", "medstore-helpers" ),
		            "param_name" => "ids",
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Category", "medstore-helpers" ),
                    "value" => $termsStatusArr,
                    "param_name" => "cat",
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Number of posts show", "medstore-helpers" ),
		            "param_name" => "number",
                    "std"   => 3,
                    'group' => esc_html__( 'Product Query', 'medstore-helpers' ),
		        ),
	      	)
	    ) );
	}

	private static function get_products($atts){
		
		$per_page = !empty($atts['number']) ? intval($atts['number']) : 3;
		$args = array(
			'post_type' => 'product', 
			'post_status' => 'publish',
			'posts_per_page' => $per_page
			);

		if(!empty($atts['ids'])){
			$args['post__in'] = explode(',', $atts['ids']);
		}else{
			if(!empty($atts['cat'])){
				$args['tax_query'] = array(
					array(
						'taxonomy' => 'product_cat',
						'field'    => 'slug',
						'terms'    => $atts['cat'],
					),
				);
			}
		}
		switch ( $atts['type'] ) {
			case 'featured' :
				$args['tax_query'][] = array(
                        'taxonomy' => 'product_visibility',
                        'field'    => 'name',
                        'terms'    => 'featured',
                    );
				break;
			case 'onsale' :
				$product_ids_on_sale    = wc_get_product_ids_on_sale();
				$product_ids_on_sale[]  = 0;
				$args['post__in'] = $product_ids_on_sale;
				break;	
			case 'bestsale' :
				$args['meta_key'] = 'total_sales';
				$args['orderby']  = 'meta_value_num';
		}

		return new WP_Query( apply_filters( 'medstore_products_shortcode_query_args', $args ) );
	}
}
?>