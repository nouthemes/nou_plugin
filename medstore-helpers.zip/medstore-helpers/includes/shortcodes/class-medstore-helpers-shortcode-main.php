<?php
/**
 * The file that defines the Shortcode class
 * 
 * @since      1.0.0
 * @package    medstore-helpers
 * @subpackage medstore-helpers/includes/shortcodes
 * @author     nouthemes <nouthemes@gmail.com>
*/

class Medstore_Helpers_Shortcode_Main {

	public function __construct() {
		$this->register_shortcodes();
	}

	/**
	 * Init shortcodes.
	 */
	public function register_shortcodes() {
		$shortcodes = array(
			'title'                    => 'Medstore_Helpers_Shortcode_Title',
			'contact_form' 			   => 'Medstore_Helpers_Shortcode_Contactform',
			'social' 				   => 'Medstore_Helpers_Shortcode_Social',
			'hotline' 				   => 'Medstore_Helpers_Shortcode_Hotline',
			'email_button' 			   => 'Medstore_Helpers_Shortcode_Email_Button',
			'our_team' 				   => 'Medstore_Helpers_Shortcode_Our_Team',
			'our_team_item' 		   => 'Medstore_Helpers_Shortcode_Our_Team_Item',
			'our_stats' 			   => 'Medstore_Helpers_Shortcode_Our_Stats',
			'our_stats_item' 		   => 'Medstore_Helpers_Shortcode_Our_Stats_Item',
			'our_services' 			   => 'Medstore_Helpers_Shortcode_Our_Services',
			'our_services_item' 	   => 'Medstore_Helpers_Shortcode_Our_Services_Item',
			'testimonial' 			   => 'Medstore_Helpers_Shortcode_Testimonial',
			'testimonial_item' 		   => 'Medstore_Helpers_Shortcode_Testimonial_Item',
			'brands' 				   => 'Medstore_Helpers_Shortcode_Brands',
			'brand_item' 			   => 'Medstore_Helpers_Shortcode_Brand_Item',
			'posts' 				   => 'Medstore_Helpers_Shortcode_Posts',
			'products' 				   => 'Medstore_Helpers_Shortcode_Products',
			'categories' 			   => 'Medstore_Helpers_Shortcode_Categories',
			'category_item' 		   => 'Medstore_Helpers_Shortcode_Category_Item',
			'reviews' 				   => 'Medstore_Helpers_Shortcode_Reviews',
			'review_item' 			   => 'Medstore_Helpers_Shortcode_Review_Item',
			'products_sale' 		   => 'Medstore_Helpers_Shortcode_Products_Sale',
			'newsletter' 			   => 'Medstore_Helpers_Shortcode_Newsletter',
		);

		if(!empty($shortcodes)):
			foreach ( $shortcodes as $shortcode => $function ) {
				add_shortcode( apply_filters( "medstore_{$shortcode}_shortcode_tag", 'medstore_'.$shortcode ), array($function, 'shortcode') );
				add_action( 'vc_before_init', array($function, 'map') );
			}

			add_action( 'vc_before_init', array($this, 'add_params') );
		endif;
	}

	public static function add_params(){
		$attribute_vc_row = array(
		    'type' => 'checkbox',
		    'heading' => esc_html__( "Row with container", "bakery-helpers" ),
		    'param_name' => 'with_container',
		    'value' => '',
		);
		vc_add_param( 'vc_row', $attribute_vc_row );
	}

	/**
	 * get-attributes-of-nested-shortcodes
	 *
	 * @param string $str
	 * @param array $atts
	 *
	 * @return string
	 * @link http://wordpress.stackexchange.com/questions/121562/get-attributes-of-nested-shortcodes
	 */
	public static function get_attributes_nested_shortcodes( $str, $att = null ) {
		$res = array();
		$reg = get_shortcode_regex();
		preg_match_all( '~' . $reg . '~', $str, $matches );
		$i = 0;
		foreach ( $matches[2] as $key => $name ) {
			$parsed = shortcode_parse_atts( $matches[3][ $key ] );
			$parsed = is_array( $parsed ) ? $parsed : array();

			$res[ $i ]              = array_key_exists( $att, $parsed ) ? $parsed[ $att ] : $parsed;
			$res[ $i ]['name']      = $name;
			$res[ $i ]['shortcode'] = $matches[0][ $key ];
			$i                      = $i + 1;
		}

		return $res;
	}
}
?>