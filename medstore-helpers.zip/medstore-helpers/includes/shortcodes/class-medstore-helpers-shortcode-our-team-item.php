<?php

class Medstore_Helpers_Shortcode_Our_Team_Item
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'img' => '',
            'facebook' => '#',
            'twitter' => '#',
            'pinterest' => '#',
            'linkedin' => '#',
        ), $atts, 'medstore_our_team_item' );
		
		ob_start();
        ?>
        <div class="ps-block--team-member flex items-center justify-center">
            <div class="ps-block__image relative">
                <div class="content-overlay"></div>
                <?php if(!empty($atts['img'])){
                    echo medstore_get_image_by_id($atts['img'], 'medstore_329x449');
                }?>
                <div class="info">
                    <ul class="social flex gap-6">
                        <?php if(!empty($atts['facebook'])): ?>
                            <li><a href="<?php echo esc_url($atts['facebook']);?>"><i class="fa-brands fa-square-facebook"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($atts['twitter'])): ?>
                            <li><a href="<?php echo esc_url($atts['twitter']);?>"><i class="fa-brands fa-square-x-twitter"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($atts['pinterest'])): ?>
                            <li><a href="<?php echo esc_url($atts['pinterest']);?>"><i class="fa-brands fa-square-pinterest"></i></a></li>
                        <?php endif; ?>
                        <?php if(!empty($atts['linkedin'])): ?>
                            <li><a href="<?php echo esc_url($atts['linkedin']);?>"><i class="fa-brands fa-linkedin"></i></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Medstore - Our Team Item", "medstore-helpers" ),
		      	"base" => "medstore_our_team_item",
				"class" => "",
  				"content_element" => true,
				"show_settings_on_create" => true,
		      	"as_child" => array('only' => 'medstore_our_team'),
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Name", "medstore-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", "medstore-helpers" ),
			            "param_name" => "img",
			        ),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => esc_html__( "Facebook", "medstore-helpers" ),
                        "param_name" => "facebook",
                        "value" => '#',
                        'group' => esc_html__( 'Social', 'medstore-helpers' ),
                    ),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => esc_html__( "Twitter", "medstore-helpers" ),
                        "param_name" => "twitter",
                        "value" => '#',
                        'group' => esc_html__( 'Social', 'medstore-helpers' ),
                    ),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => esc_html__( "Pinterest", "medstore-helpers" ),
                        "param_name" => "pinterest",
                        "value" => '#',
                        'group' => esc_html__( 'Social', 'medstore-helpers' ),
                    ),
                    array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => esc_html__( "LinkedIn", "medstore-helpers" ),
                        "param_name" => "linkedin",
                        "value" => '#',
                        'group' => esc_html__( 'Social', 'medstore-helpers' ),
                    ),
		      	)
		    ) );
		endif;
	}
}
?>