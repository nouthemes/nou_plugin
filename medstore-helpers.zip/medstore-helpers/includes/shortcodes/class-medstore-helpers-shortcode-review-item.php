<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Review_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'img' => '',
			'rating' => 5,
			'desc' => '',
			'date_created' => '',
			'style' => 'general'
		), $atts, 'medstore_review_item' );
		
		$style = !empty($atts['style']) ? $atts['style'] : 'general';
		ob_start();
		if($style == 'general'):
			?>
			<div class="review-item review-item--general p-5 rounded flex flex-col items-center justify-center gap-3 relative">
				<svg xmlns="http://www.w3.org/2000/svg" width="47" height="28" viewBox="0 0 47 28" fill="none">
					<path d="M6.43991 0L0 28H10.3942L21.9183 0H6.43991ZM31.4087 0L25.0817 28H35.476L47 0H31.4087Z" fill="#436CFF"/>
				</svg>
				<div class="review-item__avatar flex flex-col items-center justify-center gap-2">
					<?php if(!empty($atts['img'])){
						echo medstore_get_image_by_id($atts['img'], 'medstore_102');
					}?>
					<h6 class="no-more-class"><?php echo esc_attr($atts['name']);?></h6>
				</div>
				<div class="review-item__content text-center">
					<?php echo wp_kses_post($atts['desc']);?>
				</div>
				<div class="review-item__rating flex gap-1">
					<?php for($i = 1; $i <= 5; $i++):?>
						<?php if($i <= $atts['rating']):?>
							<i class="fas fa-star text-yellow-500"></i>
						<?php else:?>
							<i class="far fa-star text-gray-500"></i>
						<?php endif;?>
					<?php endfor;?>
				</div>
			</div>
			<?php
		elseif($style == 'boxed'):
			?>
			<div class="review-item review-item--boxed p-5 rounded flex flex-col items-center justify-start gap-3">
				<div class="review-item__header flex items-center justify-between gap-2 w-full">
					<div class="review-item__avatar flex items-center gap-2">
						<?php if(!empty($atts['img'])){
							echo medstore_get_image_by_id($atts['img'], 'medstore_102');
						}?>
						<div class="flex flex-col items-start gap-2">
							<h6 class="no-more-class"><?php echo esc_attr($atts['name']);?></h6>
							<?php if(!empty($atts['date_created'])):?>
								<span class="review-item__date"><?php echo esc_html($atts['date_created']);?></span>
							<?php endif;?>
						</div>
					</div>
					<div class="flex items-center justify-center gap-2">
						<span><?php echo esc_html($atts['rating']);?></span>
						<div class="review-item__rating flex gap-1">
							<?php for($i = 1; $i <= 5; $i++):?>
								<?php if($i <= $atts['rating']):?>
									<i class="fas fa-star text-yellow-500"></i>
								<?php else:?>
									<i class="far fa-star text-gray-500"></i>
								<?php endif;?>
							<?php endfor;?>
						</div>
					</div>
				</div>
				<div class="w-full currency-divider"></div>			
				<div class="review-item__content text-left">
					<?php echo wp_kses_post($atts['desc']);?>
				</div>
			</div>
			<?php
		endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Review Item", "medstore-helpers" ),
	      	"base" => "medstore_review_item",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"content_element" => true,
    		"as_child" => array('only' => 'medstore_reviews'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", "medstore-helpers" ),
		            "param_name" => "name",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Date", "medstore-helpers" ),
		            "param_name" => "date_created",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Avatar", "medstore-helpers" ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Content", "medstore-helpers" ),
		            "param_name" => "desc",
				),
				array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Rating", "medstore-helpers" ),
		            "param_name" => "rating",
                    "std"   => 5,
		            "value" => array(
                        5 => '5', 
                        4 => '4', 
                        3 => '3', 
                        2 => '2',
                        1 => '1'
                    ),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>