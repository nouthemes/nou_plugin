<?php
/**
 * 
* @since 1.0.0
*/
class Medstore_Helpers_Shortcode_Social
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
		), $atts, 'medstore_social' );
		
		ob_start();
		?>
		<div class="ps-section ps-section--social">
			<?php 
			$title = isset($atts['title']) && !empty($atts['title']) ? $atts['title'] : esc_html__('Follow Us', 'medstore-helpers');
            $facebook = medstore_get_option('social_facebook');
            $twitter = medstore_get_option('social_twitter');
            $instagram = medstore_get_option('social_instagram');
            $pinterest = medstore_get_option('social_printest');
            $youtube = medstore_get_option('social_youtube');
            $linkedin = medstore_get_option('social_linkedin');
			?>
	        <div class="flex flex-col gap-7">
                <h3 class="text-xl font-semibold no-more-class"><?php echo esc_html($title); ?></h3>
                <?php
                echo '<ul class="flex items-center gap-6">';
                    
                    if(!empty($facebook)){?>
                        <li><a href="<?php echo esc_url($facebook);?>" target="_blank"><i class="fa-brands fa-square-facebook text-xl !text-[#0866FF]"></i></a></li>
                    <?php }

                    if(!empty($twitter)){?>
                        <li><a href="<?php echo esc_url($twitter);?>" target="_blank"><i class="fa-brands fa-square-x-twitter text-xl !text-[#343434]"></i></a></li>
                    <?php }

                    if(!empty($instagram)){?>
                        <li><a href="<?php echo esc_url($instagram);?>" target="_blank"><i class="fa-brands fa-square-instagram text-xl !text-[#bd081c]"></i></a></li>
                    <?php }

                    if(!empty($pinterest)){?>
                        <li><a href="<?php echo esc_url($pinterest);?>" target="_blank"><i class="fa-brands fa-square-pinterest text-xl !text-[#bd081c]"></i></a></li>
                    <?php }

                    if(!empty($youtube)){?>
                        <li><a href="<?php echo esc_url($youtube);?>" target="_blank"><i class="fa-brands fa-square-youtube text-xl"></i></a></li>
                    <?php }

                    if(!empty($linkedin)){?>
                        <li><a href="<?php echo esc_url($linkedin);?>" target="_blank"><i class="fa-brands fa-linkedin text-xl !text-[#0A66C2]"></i></a></li>
                    <?php }

                echo '</ul>';
                ?>
			</div>
	    </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Social", "medstore-helpers" ),
	      	"base" => "medstore_social",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "medstore-helpers" ),
		            "param_name" => "title",
                    "value" => esc_html__('Follow Us', 'medstore-helpers')
		        ),
	      	)
	    ) );
		endif;
	}
}