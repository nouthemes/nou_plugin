<?php

class Medstore_Helpers_Shortcode_Posts
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
            'title' => '',
            'category_id' => '',
			'btn_position' => 'top'
        ), $atts, 'medstore_posts' );

        $args = ['post_type' => 'post', 'ignore_sticky_posts' => true];

        if(!empty($atts['category_id']) && $atts['category_id'] > 0){
            $args['category_name'] = $atts['category_id'];
        }

        $args['posts_per_page'] = 3;

        $wp_query = new WP_Query($args);

        if($wp_query->found_posts == 0){
            wp_reset_query();
            return;
        }

        $show_on_front = get_option('show_on_front', 'posts');
        $blog_url = home_url('/');
        if($show_on_front == 'page'){
            $blog_url = get_permalink( get_option( 'page_for_posts' ) );
        }

        $btn_position = !empty($atts['btn_position']) ? $atts['btn_position'] : 'top';

		ob_start();
        ?>
            <div class="ps-section flex flex-col gap-7 ps-section__our-team">
				<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>

                    <?php if($btn_position === 'top'):?>
					    <div class="ps-section__header flex items-center justify-between">
                    <?php else:?>
                        <div class="ps-section__header flex items-center justify-center">
                    <?php endif;?>

						<?php if(!empty($atts['title'])):?>
							<h3 class="ps-section__heading no-more-class">
								<?php echo wp_kses_post($atts['title']);?>
							</h3>

                            <?php if($btn_position === 'top'):?>
                                <a class="view-all" href="<?php echo esc_url($blog_url);?>"><?php esc_html_e( "See all posts", "medstore-helpers");?></a>
                            <?php endif;?>
						<?php endif;?>
					</div>
				<?php endif;?>
				
				<div class="ps-section__content">
					<div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-6">
                        <?php while ($wp_query->have_posts()) : $wp_query->the_post();?>
                            <div class="post-item">
                                <div class="post-item__inner flex flex-col gap-3">
                                    <?php if(has_post_thumbnail()){?>
                                        <div class="post-item__image">
                                            <a class="hover:-translate-y-2 duration-300 no-more-class" href="<?php the_permalink();?>" title="<?php the_title();?>">
                                                <?php echo medstore_get_image_by_id(get_post_thumbnail_id(), 'medstore_447x337');?>
                                            </a>
                                        </div>
                                    <?php }?>

                                    <div class="post-item__content flex flex-col gap-2">
                                        <div class="post-item__meta flex items-center gap-1">
                                            <?php 
                                                $categories_list = get_the_category_list(', ');
                                                if ( $categories_list ) {
                                                    echo '<div class="not-tag ps-post__categories">' . wp_kses_post( $categories_list ) . '</div>';
                                                }
                                            ?>
                                            <svg xmlns="http://www.w3.org/2000/svg" width="5" height="5" viewBox="0 0 5 5" fill="none">
                                                <circle cx="2.5" cy="2.90039" r="2" fill="#A3A3A3"/>
                                            </svg>
                                            <div class="post-date"><?php medstore_posted_on(true);?></div>
                                        </div>
                                        <h3 class="no-more-class post-item__title">
                                            <a class="no-more-class" href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title();?></a>
                                        </h3>
                                        <a class="no-more-class read-more" href="<?php the_permalink();?>" title="<?php the_title();?>">
                                            <?php esc_html_e( "View detail", "medstore-helpers");?>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;?>
					</div>
				</div>

                <?php if($btn_position === 'bottom'):?>
                    <a href="<?php echo esc_url($blog_url);?>" class="mx-auto max-w-44 btn btn-outline-primary no-more-class"><?php esc_html_e('See all posts', 'medstore-helpers');?></a>
                <?php endif;?>
			</div>
        <?php
        wp_reset_query();
		return ob_get_clean();
	}

	public static function map(){
        if(function_exists('vc_map')):
            
            $termsStatusArr = [
                esc_html__( "Choose a Category", "medstore-helpers") => ''
            ];

            $termStatus = medstore_link_taxonomy_terms('category', -1, true);
            foreach($termStatus as $term){
                $termsStatusArr[$term['name']] = $term['slug'];
            }

			vc_map( array(
		      	"name" => esc_html__( "Medstore - Posts", "medstore-helpers" ),
		      	"base" => "medstore_posts",
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
                        "heading" => esc_html__( "Heading", "medstore-helpers" ),
                        "value" => esc_html__( "News & Consult", "medstore-helpers" ),
			            "param_name" => "title",
                    ),
                    array(
			            "type" => "dropdown",
			            "holder" => "div",
			            "class" => "",
                        "heading" => esc_html__( "Category", "medstore-helpers" ),
                        "value" => $termsStatusArr,
			            "param_name" => "category_id",
			        ),
                    array(
                        "type" => "dropdown",
                        "class" => "",
                        "holder" => "div",
                        "heading" => esc_html__( "Position of See All button", "medstore-helpers" ),
                        "param_name" => "btn_position",
                        "std"   => "top",
                        "value" => array(
                            esc_html__('Top', "medstore-helpers") => 'top', 
                            esc_html__('Bottom', "medstore-helpers") => 'bottom'
                        ), 
                    ),
		      	)
		    ) );
		endif;
	}
}
?>