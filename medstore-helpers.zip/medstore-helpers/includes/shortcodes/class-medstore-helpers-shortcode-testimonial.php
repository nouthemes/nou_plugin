<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Testimonial
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'img' => '',
		), $atts, 'medstore_testimonial' );
		
		$bg = _MEDSTORE_IMG . '/parallax/img-bg-1.jpg';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$bg = $images[0];
			}
		}

		$id = uniqid('carousel-testimonial-');

		ob_start();
			if(!empty($content)):
			?>
			<div id="<?php echo esc_attr($id);?>" class="ps-section ps-section--carousel-testimonial bg--parallax" data-background="<?php echo esc_attr($bg);?>">
		        <div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="10000" data-owl-gap="0" data-owl-nav="true" data-owl-dots="true" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1">
					<?php echo do_shortcode($content);?>
		        </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Testimonial Carousel", "medstore-helpers" ),
	      	"base" => "medstore_testimonial",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"params" => array(

	      		array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Background image", "medstore-helpers" ),
			            "param_name" => "img",
			        ),

	      	),
	      	"as_parent" => array('only' => 'medstore_testimonial_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>