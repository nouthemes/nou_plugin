<?php

class Medstore_Helpers_Shortcode_Our_Stats_Item
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'number' => '',
        ), $atts, 'medstore_our_stats_item' );
		
		ob_start();
        ?>
        <div class="ps-block__stats_item flex flex-col items-center justify-center gap-2">
            <?php if(!empty($atts['number'])):?>
                <h3 class="no-more-class text-5xl font-normal"><?php echo wp_kses_post($atts['number']);?></h3>
            <?php endif;?>
            <?php if(!empty($atts['title'])):?>
                <p><?php echo esc_html($atts['title']);?></p>
            <?php endif;?>
        </div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Medstore - Our Team Item", "medstore-helpers" ),
		      	"base" => "medstore_our_stats_item",
				"class" => "",
  				"content_element" => true,
				"show_settings_on_create" => true,
		      	"as_child" => array('only' => 'medstore_our_stats'),
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "medstore-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
                        "type" => "textfield",
                        "class" => "",
                        "heading" => esc_html__( "Number", "medstore-helpers" ),
                        "param_name" => "number",
                    ),
		      	)
		    ) );
		endif;
	}
}
?>