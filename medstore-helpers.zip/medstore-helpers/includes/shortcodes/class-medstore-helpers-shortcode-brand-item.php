<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Brand_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'url' => '',
		), $atts, 'medstore_brand_item' );
		
        $bg = '';

		if(!empty($atts['img'])){
            $image_attributes = wp_get_attachment_image_src($atts['img'], 'full');
            if ( $image_attributes ) {
                $bg = $image_attributes[0];
            }
        }

		ob_start();
			if(!empty($bg)):
			?>
			<a class="panel-partner-item no-more-class flex items-center" href="<?php echo esc_attr($atts['url']);?>" target="_blank">
	           	<img src="<?php echo esc_attr($bg);?>" alt="" />
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Brand Item", "medstore-helpers" ),
	      	"base" => "medstore_brand_item",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"content_element" => true,
    		"as_child" => array('only' => 'medstore_brands'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "medstore-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", "medstore-helpers" ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", "medstore-helpers" ),
		            "param_name" => "url",
		        )
	      	)
	    ) );
		endif;
	}
}
?>