<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Reviews
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'style' => 'grid',
			'style_item' => 'general'
		), $atts, 'medstore_reviews' );

		$style = !empty($atts['style']) ? $atts['style'] : 'grid';

		$content = str_replace('[medstore_review_item ', '[medstore_review_item style="'. esc_html($atts['style_item']) .'" ', $content);

		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-section flex flex-col gap-7 ps-section_reviews">
				<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>
					<div class="ps-section__header flex flex-col gap-3">
						<?php if(!empty($atts['title'])):?>
							<h3 class="ps-section__heading no-more-class">
								<?php echo wp_kses_post($atts['title']);?>
							</h3>
						<?php endif;?>
						<?php if(!empty($atts['desc'])):?>
							<div class="ps-section__description flex justify-center items-center">
								<div class="max-w-xl"><?php echo wp_kses_post($atts['desc']);?></div>
							</div>
						<?php endif;?>
					</div>
				<?php endif;?>
				
				<div class="ps-section__content">
					<?php if($style === 'grid'):?>
						<div class="ps-section_reviews-grid grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
							<?php echo do_shortcode($content);?>
						</div>
					<?php else:?>
						<div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="10000" data-owl-gap="28" data-owl-nav="true" data-owl-dots="false" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="3" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="2" data-owl-item-lg="3">
							<?php echo do_shortcode($content);?>
						</div>
					<?php endif;?>
				</div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Reviews", "medstore-helpers" ),
	      	"base" => "medstore_reviews",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"params" => array(
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Title", "medstore-helpers" ),
                    "param_name" => "title",
                ),
                array(
                    "type" => "textarea",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Description", "medstore-helpers" ),
                    "param_name" => "desc",
                ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of section show", "medstore-helpers" ),
		            "param_name" => "style",
                    "std"   => "grid",
		            "value" => array(
                        esc_html__('Grid', "medstore-helpers") => 'grid', 
                        esc_html__('Slider', "medstore-helpers") => 'slider'
                    ), 
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
		        ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of items show", "medstore-helpers" ),
		            "param_name" => "style_item",
                    "std"   => "general",
		            "value" => array(
                        esc_html__('General', "medstore-helpers") => 'general', 
                        esc_html__('Boxed', "medstore-helpers") => 'boxed', 
                    ), 
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
				),
                
              ),
	      	"as_parent" => array('only' => 'medstore_review_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>