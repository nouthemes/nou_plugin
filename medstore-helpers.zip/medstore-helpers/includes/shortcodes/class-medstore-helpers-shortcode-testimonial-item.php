<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Testimonial_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'rating' => '',
			'position' => '',
			'desc' => '',
		), $atts, 'medstore_testimonial_item' );
		
		ob_start();
			if(!empty($atts['desc'])):
			?>
			<div class="ps-testimonial flex flex-col gap-6 items-center justify-center">
              	<div class="ps-testimonial__header">
				  	<div class="flex items-center">
						<svg class="<?php if(!empty($atts['rating']) && $atts['rating'] >= 1){echo 'active';}?>" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
							<path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
						</svg>
						<svg class="<?php if(!empty($atts['rating']) && $atts['rating'] >= 2){echo 'active';}?>" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
							<path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
						</svg>
						<svg class="<?php if(!empty($atts['rating']) && $atts['rating'] >= 3){echo 'active';}?>" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
							<path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
						</svg>
						<svg class="<?php if(!empty($atts['rating']) && $atts['rating'] >= 4){echo 'active';}?>" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
							<path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
						</svg>
						<svg class="<?php if(!empty($atts['rating']) && $atts['rating'] == 5){echo 'active';}?>" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 22 20">
							<path d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"/>
						</svg>
					</div>
				</div>

				<div class="ps-testimonial__content text-center max-w-xl">
					<p class="text-center text-white"><?php echo esc_html($atts['desc']);?></p>
				</div>

				<div class="ps-testimonial__footer flex flex-col gap-1">
					<h5 class="text-center text-white no-more-class"><?php echo esc_html($atts['name']);?></h5>
					<p class="text-center text-white"><?php echo esc_html($atts['position']);?></p>
				</div>

            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Testimonial Item", "medstore-helpers" ),
	      	"base" => "medstore_testimonial_item",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"content_element" => true,
    		"as_child" => array('only' => 'medstore_testimonial'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", "medstore-helpers" ),
		            "param_name" => "name",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Position", "medstore-helpers" ),
		            "param_name" => "position",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Rating", "medstore-helpers" ),
		            "param_name" => "rating",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Content", "medstore-helpers" ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
	}
}
?>