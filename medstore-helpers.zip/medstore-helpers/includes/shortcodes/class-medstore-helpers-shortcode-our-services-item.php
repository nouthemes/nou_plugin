<?php

class Medstore_Helpers_Shortcode_Our_Services_Item
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'img' => '',
			'title_color' => '#151515',
			'desc_color' => '#686868',
			'style' => 'small',
        ), $atts, 'medstore_our_services_item' );
		
		$bg = '';
		$style = isset($atts['style']) ? $atts['style'] : 'small';

		if(!empty($atts['img'])){
            $image_attributes = wp_get_attachment_image_src($atts['img'], 'finderland_150x150');
            if ( $image_attributes ) {
                $bg = $image_attributes[0];
            }
        }

		$title_color = !empty($atts['title_color']) ? $atts['title_color'] : '#151515';
		$desc_color = !empty($atts['desc_color']) ? $atts['desc_color'] : '#686868';

		ob_start();
			if($style == 'small'):
				?>
				<div class="ps-section__column flex items-center justify-center style-small">
					<div class="ps-block--service flex items-center gap-3">
						<div class="ps-block__top">
							<div class="hover:-translate-y-2 duration-300 ps-block__image">
								<?php if(!empty($bg)):?>
									<img src="<?php echo esc_attr($bg);?>" alt="<?php echo esc_attr($atts['title']);?>" />
								<?php endif;?>
							</div>
						</div>
						<div class="ps-block__content flex flex-col gap-1">
							<?php if(!empty($atts['title'])):?>
								<h4 class="no-more-class" data-text-color="<?php echo sanitize_hex_color($title_color);?>"><?php echo esc_html($atts['title']);?></h4>
							<?php endif;?>
							<?php if(!empty($atts['desc'])):?>
								<p data-text-color="<?php echo sanitize_hex_color($desc_color);?>">
									<?php echo esc_html($atts['desc']);?>
								</p>
							<?php endif;?>
						</div>
					</div>
				</div>
				<?php
			else:
				?>
				<div class="ps-section__column flex items-center justify-center style-large">
					<div class="ps-block--service flex flex-col items-center gap-3">
						<div class="ps-block__top">
							<div class="hover:-translate-y-2 duration-300 ps-block__image">
								<?php if(!empty($bg)):?>
									<img src="<?php echo esc_attr($bg);?>" alt="<?php echo esc_attr($atts['title']);?>" />
								<?php endif;?>
							</div>
						</div>
						<div class="ps-block__content flex flex-col gap-1">
							<?php if(!empty($atts['title'])):?>
								<h4 class="no-more-class" data-text-color="<?php echo sanitize_hex_color($title_color);?>"><?php echo esc_html($atts['title']);?></h4>
							<?php endif;?>
							<?php if(!empty($atts['desc'])):?>
								<p data-text-color="<?php echo sanitize_hex_color($desc_color);?>">
									<?php echo esc_html($atts['desc']);?>
								</p>
							<?php endif;?>
						</div>
					</div>
				</div>
				<?php
			endif;
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Medstore - Our Service Item", "medstore-helpers" ),
		      	"base" => "medstore_our_services_item",
				"class" => "",
  				"content_element" => true,
				"show_settings_on_create" => true,
		      	"as_child" => array('only' => 'medstore_our_services'),
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "medstore-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textarea",
			            "class" => "",
			            "heading" => esc_html__( "Description", "medstore-helpers" ),
			            "param_name" => "desc",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", "medstore-helpers" ),
			            "param_name" => "img",
			        ),
					array(
						"type" => "colorpicker",
						"class" => "",
						"heading" => esc_html__( "Title color", "medstore-helpers" ),
						"param_name" => "title_color",
						"value" => '#151515',
						'group' => esc_html__( 'Design options', 'medstore-helpers' ),
					),
					array(
						"type" => "colorpicker",
						"class" => "",
						"heading" => esc_html__( "Description color", "medstore-helpers" ),
						"param_name" => "desc_color",
						"value" => '#686868',
						'group' => esc_html__( 'Design options', 'medstore-helpers' ),
					),
		      	)
		    ) );
		endif;
	}
}
?>