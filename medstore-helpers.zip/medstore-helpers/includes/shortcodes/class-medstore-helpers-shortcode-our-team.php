<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Our_Team
{
	
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
		), $atts, 'medstore_our_team' );

		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-section flex flex-col gap-7 ps-section__our-team">
				<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>
					<div class="ps-section__header flex flex-col gap-3">
						<?php if(!empty($atts['title'])):?>
							<h3 class="ps-section__heading no-more-class">
								<?php echo wp_kses_post($atts['title']);?>
							</h3>
						<?php endif;?>
						<?php if(!empty($atts['desc'])):?>
							<div class="ps-section__description flex justify-center items-center">
								<div class="max-w-xl"><?php echo wp_kses_post($atts['desc']);?></div>
							</div>
						<?php endif;?>
					</div>
				<?php endif;?>
				
				<div class="ps-section__content">
					<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
						<?php echo do_shortcode($content);?>
					</div>
				</div>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Medstore - Our Team", "medstore-helpers" ),
		      	"base" => "medstore_our_team",
		      	"class" => "",
		      	"as_parent" => array('only' => 'medstore_our_team_item'),
		      	"content_element" => true,
			    "show_settings_on_create" => true,
			    "is_container" => true,
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "medstore-helpers" ),
			            "param_name" => "title",
			        ),
                    array(
			            "type" => "textarea",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Description", "medstore-helpers" ),
			            "param_name" => "desc",
			        ),
			        
		      	),
		      	"js_view" => 'VcColumnView'
			) );
		endif;
	}
}
?>