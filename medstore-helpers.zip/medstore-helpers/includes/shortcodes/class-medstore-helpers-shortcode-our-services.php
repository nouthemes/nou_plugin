<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Our_Services
{
	
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'with_container' => '',
			'style' => 'small',
		), $atts, 'medstore_our_services' );
		
		$style = isset($atts['style']) ? $atts['style'] : 'small';
		$content = str_replace('[medstore_our_services_item', '[medstore_our_services_item style="'. esc_html($atts['style']) .'" ', $content);
		
		ob_start();
			if(!empty($content)):
				if(!empty($atts['with_container'])){
					echo '<div class="container mx-auto">';
				}
					?>
					<div class="ps-section flex flex-col gap-7 ps-section__our-services ps-section__our-services-<?php echo esc_attr($style);?>">
						<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>
							<div class="ps-section__header flex flex-col gap-3">
								<?php if(!empty($atts['title'])):?>
									<h3 class="ps-section__heading no-more-class">
										<?php echo wp_kses_post($atts['title']);?>
									</h3>
								<?php endif;?>
								<?php if(!empty($atts['desc'])):?>
									<div class="ps-section__description flex justify-center items-center">
										<div class="max-w-xl"><?php echo wp_kses_post($atts['desc']);?></div>
									</div>
								<?php endif;?>
							</div>
						<?php endif;?>
						
						<div class="ps-section__content">
							<?php if($style === 'small'):?>
								<div class="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6">
							<?php else:?>
								<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
							<?php endif;?>
								<?php echo do_shortcode($content);?>
							</div>
						</div>
					</div>
					<?php
				if(!empty($atts['with_container'])){
					echo '</div>';
				}
			endif;
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Medstore - Our Service", "medstore-helpers" ),
		      	"base" => "medstore_our_services",
		      	"class" => "",
		      	"as_parent" => array('only' => 'medstore_our_services_item'),
		      	"content_element" => true,
			    "show_settings_on_create" => true,
			    "is_container" => true,
		      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "medstore-helpers" ),
			            "param_name" => "title",
			        ),
                    array(
			            "type" => "textarea",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Description", "medstore-helpers" ),
			            "param_name" => "desc",
			        ),
					array(
						"type" => "dropdown",
						"class" => "",
						"holder" => "div",
						"heading" => esc_html__( "Type of item show", "medstore-helpers" ),
						"param_name" => "style",
						"std"   => "small",
						"value" => array(
							esc_html__('Small', "medstore-helpers") => 'small', 
							esc_html__('Large', "medstore-helpers") => 'large'
						), 
					),
					array(
						'type' => 'checkbox',
						'heading' => esc_html__( "With container", "bakery-helpers" ),
						'param_name' => 'with_container',
						'value' => '',
					)
			        
		      	),
		      	"js_view" => 'VcColumnView'
			) );
		endif;
	}
}
?>