<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Category_Item
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'cat' => '',
			'icon' => '',
			'style' => 'small',
			'bg_color' => '',
		), $atts, 'medstore_category_item' );

		ob_start();
			if(!empty($atts['cat'])):
				switch ($atts['style']) {
					case 'small':
						echo self::style_small($atts);
						break;
					case 'medium':
						echo self::style_medium($atts);
						break;
					case 'large':
						echo self::style_large($atts);
						break;
					case 'circle':
						echo self::style_circle($atts);
						break;
					default:
						echo self::style_small($atts);
						break;
				}
			endif;
		return ob_get_clean();
	}

	private static function style_circle($atts) {

		ob_start();
			if(!empty($atts['cat'])):
				$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
				if ( ! is_wp_error( $term ) ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						$bg_color = !empty($atts['bg_color']) ? sanitize_hex_color($atts['bg_color']) : '#EDF1FF';
						?>
						<div class="category-item category-item-circle flex flex-col items-center justify-center gap-6">
							<a data-background-color="<?php echo esc_attr($bg_color);?>" class="hover:-translate-y-2 duration-300 category-item__image no-more-class flex items-center justify-center" href="<?php echo esc_url( $term_link );?>">
								
								<?php if(!empty($atts['img'])):?>
									<?php echo medstore_get_image_by_id($atts['img'], 'medstore_102');?>
								<?php else:?>
									<?php if(!empty($atts['icon'])):?>
										<span class="category-item__icon">
											<?php echo medstore_esc($atts['icon']);?>
										</span>
									<?php endif;?>
								<?php endif;?>

							</a>
							<a class="no-more-class flex flex-col items-center justify-center gap-1" href="<?php echo esc_url( $term_link );?>">
								<span class="category-item__name"><?php echo esc_html($term->name);?></span>
								<span class="category-item__count"><?php printf(esc_html__('%s items', 'medstore-helpers'), esc_html($term->count));?></span>
							</a>
						</div>	
						<?php
					}
				}
			endif;
		return ob_get_clean();
	}

	private static function style_large($atts) {
		ob_start();
			if(!empty($atts['cat'])):
				$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
				if ( ! is_wp_error( $term ) ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						$bg_color = !empty($atts['bg_color']) ? sanitize_hex_color($atts['bg_color']) : '#F6F6F6';
						?>
						<a data-background-color="<?php echo esc_attr($bg_color);?>" class="category-item category-item-large no-more-class flex items-center justify-between gap-3" href="<?php echo esc_url( $term_link );?>">
							
							<span class="category-item__name"><?php echo esc_html($term->name);?></span>

							<?php if(!empty($atts['img'])):?>
								<span class="hover:-translate-y-2 duration-300 "><?php echo medstore_get_image_by_id($atts['img'], 'medstore_145x180');?></span>
							<?php else:?>
								<?php if(!empty($atts['icon'])):?>
									<span class="category-item__icon">
										<?php echo medstore_esc($atts['icon']);?>
									</span>
								<?php endif;?>
							<?php endif;?>
						</a>	
						<?php
					}
				}
			endif;
		return ob_get_clean();
	}

	private static function style_medium($atts) {
		
		ob_start();
			if(!empty($atts['cat'])):
				$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
				if ( ! is_wp_error( $term ) ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						$bg_color = !empty($atts['bg_color']) ? sanitize_hex_color($atts['bg_color']) : '#F7F7F7';
						?>
						<a data-background-color="<?php echo esc_attr($bg_color);?>" class="category-item category-item-medium no-more-class flex flex-col items-start justify-start gap-10" href="<?php echo esc_url( $term_link );?>">
							<div class="meta flex flex-col items-center justify-start gap-3">
								<span class="category-item__name"><?php echo esc_html($term->name);?></span>
								<span class="btn btn-outline-primary"><?php esc_html_e('More', 'medstore-helpers');?></span>
							</div>

							<div class="hover:-translate-y-2 duration-300 w-full icon flex flex-col items-center justify-center">
								<?php if(!empty($atts['img'])):?>
									<?php echo medstore_get_image_by_id($atts['img'], 'medstore_210x190');?>
								<?php else:?>
									<?php if(!empty($atts['icon'])):?>
										<span class="category-item__icon">
											<?php echo medstore_esc($atts['icon']);?>
										</span>
									<?php endif;?>
								<?php endif;?>
							</div>
						</a>	
						<?php
					}
				}
			endif;
		return ob_get_clean();
	}

	private static function style_small($atts) {

		ob_start();
			if(!empty($atts['cat'])):
				$term = get_term_by( 'slug', $atts['cat'], 'product_cat' );
				if ( ! is_wp_error( $term ) ) {
					$term_link = get_term_link( $term );
					if ( ! is_wp_error( $term_link ) ) {
						?>
						<a class="hover:-translate-y-2 duration-300 category-item category-item-small no-more-class flex flex-col items-center justify-center gap-6" href="<?php echo esc_url( $term_link );?>">
							
							<?php if(!empty($atts['img'])):?>
								<?php echo medstore_get_image_by_id($atts['img'], 'full');?>
							<?php else:?>
								<?php if(!empty($atts['icon'])):?>
									<span class="category-item__icon">
										<?php echo medstore_esc($atts['icon']);?>
									</span>
								<?php endif;?>
							<?php endif;?>

							<span class="category-item__name"><?php echo esc_html($term->name);?></span>
						</a>	
						<?php
					}
				}
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		$termsStatusArr = [
            esc_html__( "Choose a Category", "medstore-helpers") => ''
        ];

        $termStatus = medstore_link_taxonomy_terms('product_cat', -1, true);
        foreach($termStatus as $term){
            $termsStatusArr[$term['name']] = $term['slug'];
        }

		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Category Item", "medstore-helpers" ),
	      	"base" => "medstore_category_item",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"content_element" => true,
    		"as_child" => array('only' => 'medstore_categories'),
    		"params" => array(
		        
                array(
                    "type" => "dropdown",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Category", "medstore-helpers" ),
                    "value" => $termsStatusArr,
                    "param_name" => "cat",
                ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Background color", "medstore-helpers" ),
		            "param_name" => "bg_color",
                    "value" => '#F6F6F6',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
				array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", "medstore-helpers" ),
		            "param_name" => "img",
					'group' => esc_html__( 'Icon', 'medstore-helpers' ),
		        ),
				array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Icon", "medstore-helpers" ),
		            "param_name" => "icon",
					'group' => esc_html__( 'Icon', 'medstore-helpers' ),
		        ),
	      	)
	    ) );
		endif;
	}
}
?>