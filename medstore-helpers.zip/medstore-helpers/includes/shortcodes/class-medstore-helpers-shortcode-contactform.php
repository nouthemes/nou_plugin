<?php
/**
 * 
* @since 1.0.0
*/
class Medstore_Helpers_Shortcode_Contactform
{
	
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'name_label' => '',
			'email_label' => '',
			'phone_label' => '',
			'message_label' => '',
			'button_label' => '',
		), $atts, 'medstore_contact_form' );
		
		ob_start();
		?>
		<div class="ps-section ps-section--contact-form">
			<?php 
			$name_label = isset($atts['name_label']) && !empty($atts['name_label']) ? $atts['name_label'] : esc_html__('Name', 'medstore-helpers');
			$phone_label = isset($atts['phone_label']) && !empty($atts['phone_label']) ? $atts['phone_label'] : esc_html__('Phone Number', 'medstore-helpers');
			$email_label = isset($atts['email_label']) && !empty($atts['email_label']) ? $atts['email_label'] : esc_html__('Email', 'medstore-helpers');
			$message_label = isset($atts['message_label']) && !empty($atts['message_label']) ? $atts['message_label'] : esc_html__('Your message', 'medstore-helpers');
			$button_label = isset($atts['button_label']) && !empty($atts['button_label']) ? $atts['button_label'] : esc_html__('Send Message', 'medstore-helpers');
			?>
	        <div class="flex flex-col gap-6">
				<div
				class="hidden p-4 text-sm text-red-800 rounded-lg bg-red-300" 
				:class="{ '!flex': formContact.errors.length }"
				role="alert">
					<svg class="flex-shrink-0 inline w-4 h-4 me-3 mt-[2px]" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
						<path d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z"/>
					</svg>
					<div>
						<span class="font-medium"><?php esc_html_e('Please correct the following error(s):', 'medstore-helpers');?></span>
						<ul class="mt-1.5 list-disc list-inside">
							<li class="text-sm" v-for="error in formContact.errors">{{ error.message }}</li>
						</ul>
					</div>
				</div>
				<div class="grid grid-cols-1 md:grid-cols-3 gap-3">
					<div class="flex flex-col">
						<label for="name" class="text-sm text-gray-600"><?php echo esc_html($name_label); ?></label>
						<input v-model="formContact.name" type="text" name="name" id="name" class="border border-gray-300 rounded p-3" placeholder="<?php echo esc_html($name_label); ?>">
					</div>
					<div class="flex flex-col">
						<label for="email" class="text-sm text-gray-600"><?php echo esc_html($email_label); ?></label>
						<input v-model="formContact.email" type="email" name="email" id="email" class="border border-gray-300 rounded p-3" placeholder="<?php echo esc_html($email_label); ?>">
					</div>
					<div class="flex flex-col">
						<label for="phone" class="text-sm text-gray-600"><?php echo esc_html($phone_label); ?></label>
						<input v-model="formContact.phone" type="text" name="phone" id="phone" class="border border-gray-300 rounded p-3" placeholder="<?php echo esc_html($phone_label); ?>">
					</div>
				</div>
				<div class="grid grid-rows-1 grid-flow-col gap-3">
					<div class="flex flex-col">
						<label for="message" class="text-sm text-gray-600"><?php echo esc_html($message_label); ?></label>
						<textarea v-model="formContact.message" rows="6" name="message" id="message" class="border border-gray-300 rounded p-3" placeholder="<?php echo esc_html($message_label); ?>"></textarea>
					</div>
				</div>
				<div class="grid grid-rows-1 grid-flow-col gap-3">
					<div class="flex flex-col">
						<button 
						class="transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-100 duration-300 btn btn-primary" 
						:class="{ 'cursor-not-allowed': formContact.message === '' }"
						@click="submitContactForm">
							<svg v-if="formContact.loading" aria-hidden="true" role="status" class="inline w-4 h-4 me-3 text-white animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
								<path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="#E5E7EB"/>
								<path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentColor"/>
							</svg>
							<?php echo esc_html($button_label); ?>
						</button>
					</div>
				</div>
			</div>
	    </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode contact form.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Contact form", "medstore-helpers" ),
	      	"base" => "medstore_contact_form",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "medstore-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Name", "medstore-helpers" ),
		            "param_name" => "name_label",
		            "value" => esc_html__('Name', 'medstore-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Email", "medstore-helpers" ),
		            "param_name" => "email_label",
		            "value" => esc_html__('Email', 'medstore-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Phone", "medstore-helpers" ),
		            "param_name" => "phone_label",
		            "value" => esc_html__('Phone Number', 'medstore-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Field label: Message", "medstore-helpers" ),
		            "param_name" => "message_label",
		            "value" => esc_html__('Your message', 'medstore-helpers')
		        ),
		        array(
		            "type" => "textfield",
		            "holder" => "",
		            "class" => "",
		            "heading" => esc_html__( "Button label", "medstore-helpers" ),
		            "param_name" => "button_label",
		            "value" => esc_html__('Send Message', 'medstore-helpers')
		        )
	      	)
	    ) );
		endif;
	}
}