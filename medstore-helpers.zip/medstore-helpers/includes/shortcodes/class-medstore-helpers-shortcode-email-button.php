<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Email_Button
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'email' => '',
            'class' => '',
            'text_color' => '',
            'text_size' => '',
			'border_width' => '',
			'border_color' => '',
			'border_style' => '',
			'border_radius' => '',
			'max_width' => '',
		), $atts, 'medstore_email_button' );

		$id = uniqid('email-button-');
        $color = !empty($atts['text_color']) ? sanitize_hex_color($atts['text_color']) : '#436CFF';
        $text_size = !empty($atts['text_size']) ? esc_attr($atts['text_size']) : '16px';
		$border_width = !empty($atts['border_width']) ? esc_attr($atts['border_width']) : '1px';
		$border_color = !empty($atts['border_color']) ? esc_attr($atts['border_color']) : '#436CFF';
		$border_style = !empty($atts['border_style']) ? esc_attr($atts['border_style']) : 'solid';
		$border_radius = !empty($atts['border_radius']) ? esc_attr($atts['border_radius']) : '100px';
		$max_width = !empty($atts['max_width']) ? esc_attr($atts['max_width']) : '288px';

		ob_start();
			if(!empty($atts['email'])):
			?>
			<div 
			id="<?php echo esc_attr($id);?>" 
			data-border-width="<?php echo esc_attr($border_width);?>"
			data-border-color="<?php echo esc_attr($border_color);?>"
			data-border-style="<?php echo esc_attr($border_style);?>"

			<?php if(!empty($border_radius)):?>
			data-border-radius="<?php echo esc_attr($border_radius);?>"
			<?php endif;?>

			<?php if(!empty($max_width)):?>
			data-max-width="<?php echo esc_attr($max_width);?>"
			<?php endif;?>

			class="transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-100 duration-300 btn btn-primary-outlined shortcode-hotline flex items-center gap-3 <?php echo esc_attr(!empty($atts['class']) ? esc_attr($atts['class'] ): '');?>">
				<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
					<path d="M7.5013 9.99935C7.5013 10.4596 7.12821 10.8327 6.66797 10.8327C6.20773 10.8327 5.83464 10.4596 5.83464 9.99935C5.83464 9.53911 6.20773 9.16602 6.66797 9.16602C7.12821 9.16602 7.5013 9.53911 7.5013 9.99935Z" fill="<?php echo esc_attr($color);?>"/>
					<path d="M10.8346 9.99935C10.8346 10.4596 10.4615 10.8327 10.0013 10.8327C9.54107 10.8327 9.16797 10.4596 9.16797 9.99935C9.16797 9.53911 9.54107 9.16602 10.0013 9.16602C10.4615 9.16602 10.8346 9.53911 10.8346 9.99935Z" fill="<?php echo esc_attr($color);?>"/>
					<path d="M14.168 9.99935C14.168 10.4596 13.7949 10.8327 13.3346 10.8327C12.8744 10.8327 12.5013 10.4596 12.5013 9.99935C12.5013 9.53911 12.8744 9.16602 13.3346 9.16602C13.7949 9.16602 14.168 9.53911 14.168 9.99935Z" fill="<?php echo esc_attr($color);?>"/>
					<path fill-rule="evenodd" clip-rule="evenodd" d="M18.9596 9.99935C18.9596 5.0518 14.9489 1.04102 10.0013 1.04102C5.05375 1.04102 1.04297 5.0518 1.04297 9.99935C1.04297 11.4313 1.37939 12.7864 1.97807 13.9884C2.06741 14.1678 2.08636 14.3509 2.04514 14.505L1.5488 16.36C1.20903 17.6299 2.37077 18.7916 3.64064 18.4519L5.49567 17.9555C5.64975 17.9143 5.83289 17.9332 6.01226 18.0226C7.21424 18.6213 8.56938 18.9577 10.0013 18.9577C14.9489 18.9577 18.9596 14.9469 18.9596 9.99935ZM10.0013 2.29102C14.2585 2.29102 17.7096 5.74215 17.7096 9.99935C17.7096 14.2565 14.2585 17.7077 10.0013 17.7077C8.76709 17.7077 7.60231 17.4181 6.56956 16.9037C6.15506 16.6972 5.65941 16.6177 5.17258 16.748L3.31755 17.2443C2.97685 17.3355 2.66516 17.0238 2.75632 16.6831L3.25266 14.8281C3.38292 14.3412 3.30342 13.8456 3.09697 13.4311C2.58257 12.3983 2.29297 11.2336 2.29297 9.99935C2.29297 5.74215 5.74411 2.29102 10.0013 2.29102Z" fill="<?php echo esc_attr($color);?>"/>
				</svg>
                <span data-text-size="<?php echo esc_attr($text_size);?>" data-text-color="<?php echo esc_attr($color);?>" class="no-more-class font-medium">
                    <?php echo esc_html($atts['email']);?>
                </span>
	        </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Email button", "medstore-helpers" ),
	      	"base" => "medstore_email_button",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Email", "medstore-helpers" ),
		            "param_name" => "email",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Font size(px)", "medstore-helpers" ),
		            "param_name" => "text_size",
                    "value" => '16px',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Text color", "medstore-helpers" ),
		            "param_name" => "text_color",
                    "value" => '#436CFF',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Border Width(px)", "medstore-helpers" ),
		            "param_name" => "border_width",
                    "value" => '1px',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Border radius(px)", "medstore-helpers" ),
		            "param_name" => "border_radius",
                    "value" => '100px',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "colorpicker",
		            "class" => "",
		            "heading" => esc_html__( "Border color", "medstore-helpers" ),
		            "param_name" => "border_color",
                    "value" => '#436CFF',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "heading" => esc_html__( "Border style", "medstore-helpers" ),
		            "param_name" => "border_style",
					"value" => [
						esc_html__( 'Solid border', 'medstore-helpers' ) => 'solid',
						esc_html__( 'Dotted border', 'medstore-helpers' ) => 'dotted',
						esc_html__( 'Dashed border', 'medstore-helpers' ) => 'dashed',
						esc_html__( 'Double border', 'medstore-helpers' ) => 'double',
						esc_html__( 'Groove border', 'medstore-helpers' ) => 'groove',
						esc_html__( 'Ridge border', 'medstore-helpers' ) => 'ridge',
						esc_html__( 'Inset border', 'medstore-helpers' ) => 'inset',
						esc_html__( 'Outset border', 'medstore-helpers' ) => 'outset',
						esc_html__( 'None border', 'medstore-helpers' ) => 'none',
					],
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Max Width", "medstore-helpers" ),
		            "param_name" => "max_width",
                    "value" => '288px',
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custom class", "medstore-helpers" ),
		            "param_name" => "class",
                    'group' => esc_html__( 'Design options', 'medstore-helpers' ),
                ),
	      	)
	    ) );
		endif;
	}
}
?>