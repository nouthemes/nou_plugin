<?php
/**
* 
*/
class Medstore_Helpers_Shortcode_Categories
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title' => '',
			'desc' => '',
			'style' => 'small'
		), $atts, 'medstore_categories' );

		$content = str_replace('[medstore_category_item cat', '[medstore_category_item style="'. esc_html($atts['style']) .'" cat', $content);

		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-section flex flex-col gap-12 ps-section__categories ps-section__categories--<?php echo esc_attr($atts['style']);?>">
				<?php if(!empty($atts['title']) || !empty($atts['desc'])):?>
					<div class="ps-section__header flex flex-col gap-3">
						<?php if(!empty($atts['title'])):?>
							<h3 class="ps-section__heading no-more-class">
								<?php echo wp_kses_post($atts['title']);?>
							</h3>
						<?php endif;?>
						<?php if(!empty($atts['desc'])):?>
							<div class="ps-section__description flex justify-center items-center">
								<div class="max-w-xl"><?php echo wp_kses_post($atts['desc']);?></div>
							</div>
						<?php endif;?>
					</div>
				<?php endif;?>
				
				<div class="ps-section__content">
					<?php if($atts['style'] === 'small'):?>
						<div class="grid grid-cols-2 md:grid-cols-6 lg:grid-cols-10 gap-4">
					<?php elseif($atts['style'] === 'medium'):?>
						<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-7">
					<?php elseif($atts['style'] === 'large'):?>
						<div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
					<?php elseif($atts['style'] === 'circle'):?>
						<div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-7">
					<?php endif;?>
						<?php echo do_shortcode($content);?>
					</div>
				</div>

				<?php if($atts['style'] === 'medium'):?>
					<a href="<?php echo esc_url(get_permalink(get_option('woocommerce_shop_page_id')));?>" class="mx-auto max-w-44 btn btn-outline-primary no-more-class"><?php esc_html_e('See all products', 'medstore-helpers');?></a>
				<?php endif;?>
			</div>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Medstore - Product Categories", "medstore-helpers" ),
	      	"base" => "medstore_categories",
	      	"class" => "",
	      	"category" => esc_html__( "Medstore theme", "medstore-helpers"),
	      	"params" => array(
                array(
                    "type" => "textfield",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Title", "medstore-helpers" ),
                    "param_name" => "title",
                ),
                array(
                    "type" => "textarea",
                    "holder" => "div",
                    "class" => "",
                    "heading" => esc_html__( "Description", "medstore-helpers" ),
                    "param_name" => "desc",
                ),
		        array(
		            "type" => "dropdown",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Type of items show", "medstore-helpers" ),
		            "param_name" => "style",
                    "std"   => "small",
		            "value" => array(
                        esc_html__('Small', "medstore-helpers") => 'small', 
                        esc_html__('Medium', "medstore-helpers") => 'medium', 
                        esc_html__('Large', "medstore-helpers") => 'large',
                        esc_html__('Circle', "medstore-helpers") => 'circle'
                    ), 
		        ),
                
              ),
	      	"as_parent" => array('only' => 'medstore_category_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>