<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */
class Medstore_Helpers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
