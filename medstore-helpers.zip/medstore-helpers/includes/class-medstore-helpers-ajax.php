<?php
/**
 * AJAX handler
 * 
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * 
 * @since 1.0.0
 * @author Nouthemes <nguyenvanqui89@gmail.com>
 * 
 */
class Medstore_Helpers_Ajax {
    /**
     * Initialize the class
     */
    public function __construct() {
        $ajax_events = array(
			'contact_form',
			'get_terms',
			'search',
            'get_related_posts',
            'clear_notices',
            'apply_coupon'
		);

		foreach ( $ajax_events as $ajax_event ) {
			add_action( 'wp_ajax_noumedstore_' . $ajax_event, array( $this, $ajax_event ) );
			add_action( 'wp_ajax_nopriv_noumedstore_' . $ajax_event, array( $this, $ajax_event ) );
		}
    }

    public function apply_coupon()
    {
        $status = [
            'status' => false, 
            'message' => esc_html__('Something went wrong please try again!', 'medstore-helpers')
        ];

        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            $coupon_code = !empty($_POST['coupon']) ? esc_html($_POST['coupon']) : '';
            if (!empty($coupon_code)) {
                if (WC()->cart->apply_coupon($coupon_code)) {
                    $status['message'] = esc_html__('Coupon applied successfully!', 'medstore-helpers');
                    $status['status'] = true;
                } else {
                    $status['message'] = esc_html__('Coupon is not valid!', 'medstore-helpers');
                }
            }
        }

        wp_send_json($status);
    }

    public function clear_notices()
    {
        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            if(function_exists('wc_clear_notices')){
                wc_clear_notices();
            }
            wp_send_json(['status' => true]);
        }
    }

    public function get_related_posts(){
        $status = [
            'status' => false, 
            'posts' => [],
            'message' => esc_html__('Something went wrong please try again!', 'medstore-helpers')
        ];
        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            $post_id = !empty($_POST['post_id']) ? intval($_POST['post_id']) : '';
            $terms = get_the_terms( $post_id, 'category' );

            if ( empty( $terms ) ) $terms = array();
            
            $term_list = wp_list_pluck( $terms, 'slug' );
            
            $args = array(
                'post_type' => 'post',
                'posts_per_page' => 3,
                'post_status' => 'publish',
                'post__not_in' => [$post_id],
                'tax_query' => array(
                    [
                        'taxonomy' => 'category',
                        'field' => 'slug',
                        'terms' => $term_list
                    ]
                )
            );

            $wp_query = new WP_Query($args);
            if ($wp_query->have_posts()){
                $data = [];

                while ($wp_query->have_posts()) : $wp_query->the_post();
                    
                    $author = '<span class="byline"><span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span></span>';

                    $time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
                    if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
                        $time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
                    }

                    $time_string = sprintf(
                        $time_string,
                        esc_attr( get_the_date( DATE_W3C ) ),
                        esc_html( get_the_date() ),
                        esc_attr( get_the_modified_date( DATE_W3C ) ),
                        esc_html( get_the_modified_date() )
                    );

                    $date = '<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                    $categories_list = get_the_category_list( esc_html__( ' ', 'medstore-helpers' ), '', get_the_ID() );

                    $data[] = [
                        'id' => esc_html(get_the_ID()),
                        'title' => esc_html(get_the_title()),
                        'url' => esc_url(get_the_permalink()),
                        'thumbnail' => esc_url(get_the_post_thumbnail_url(get_the_ID(), 'medstore_448x330')),
                        'excerpt' => esc_html(get_the_excerpt()),
                        'date' => $date,
                        'author' => $author,
                        'categories' => $categories_list ? $categories_list : '',
                    ];
                endwhile;

                $status['posts'] = $data;
            }
            wp_reset_query();

            $status['message'] = esc_html__('Successfully!', 'medstore-helpers');
            $status['status'] = true;
        }

        wp_send_json($status);
    }

    public function search()
    {
        $status = [
            'status' => false, 
            'posts' => [],
            'found_posts' => 0,
            'message' => esc_html__('Something went wrong please try again!', 'medstore-helpers')
        ];

        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            $s = !empty($_POST['keywords']) ? esc_html($_POST['keywords']) : '';
            $tax = !empty($_POST['taxonomy']) ? esc_html($_POST['taxonomy']) : '';
            $postType = !empty($_POST['post_type']) ? esc_html($_POST['post_type']) : 'post';
            $term_id = !empty($_POST['term_id']) ? esc_html($_POST['term_id']) : '';
            $posts_per_page = !empty($_POST['posts_per_page']) ? esc_html($_POST['posts_per_page']) : '';

            $taxQuery = [];
            if (!empty($term_id) && !empty($tax)) {
                $taxQuery = [
                    [
                        'taxonomy' => $tax,
                        'field' => 'term_id',
                        'terms' => $term_id
                    ]
                ];
            }

            $args = [
                's' => $s,
                'post_type' => $postType,
                'post_status' => 'publish',
                'tax_query' => $taxQuery,
                'posts_per_page' => $posts_per_page
            ];

            $wp_query = new WP_Query($args);
            if ($wp_query->have_posts()){
                $data = [];

                while ($wp_query->have_posts()) : $wp_query->the_post();
                    $price = '';
                    if (class_exists('Woocommerce')) {
                        $product = wc_get_product( get_the_ID() );
                        $price = $product->get_price_html();
                    }

                    $data[] = [
                        'id' => esc_html(get_the_ID()),
                        'title' => esc_html(get_the_title()),
                        'url' => esc_url(get_the_permalink()),
                        'thumbnail' => esc_url(get_the_post_thumbnail_url(get_the_ID(), 'thumbnail')),
                        'excerpt' => esc_html(get_the_excerpt()),
                        'price' => $price,
                    ];
                endwhile;

                $status['posts'] = $data;
                $status['found_posts'] = $wp_query->found_posts;
            }
            wp_reset_query();

            $status['message'] = esc_html__('Successfully!', 'medstore-helpers');
            $status['status'] = true;
        }

        wp_send_json($status);
    }

    public function get_terms()
    {
        $status = [
            'status' => false, 
            'terms' => [],
            'message' => esc_html__('Something went wrong please try again!', 'medstore-helpers')
        ];

        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            $tax = !empty($_POST['taxonomy']) ? esc_html($_POST['taxonomy']) : 'category';
            $terms = get_terms( array(
                'taxonomy' => $tax,
                'hide_empty' => true,
                'parent' => 0
            ) );
            if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                $data = [];
                foreach ($terms as $term) {
                    $data[] = [
                        'id' => esc_html($term->term_id),
                        'name' => esc_html($term->name),
                        'slug' => esc_html($term->slug),
                        'url' => esc_url(get_term_link($term)),
                        'count' => esc_html($term->count)
                    ];
                }
                
                $status['terms'] = $data;
            }

            $status['message'] = esc_html__('Successfully!', 'medstore-helpers');
            $status['status'] = true;
        }

        wp_send_json($status);
    }

    public function contact_form()
    {
        $status = [
            'status' => false, 
            'message' => esc_html__('Something went wrong please try again!', 'medstore-helpers')
        ];

        if( !empty($_POST['nonce'] ) && wp_verify_nonce( $_POST['nonce'], 'medstore-nonce' ) ){
            if (!empty($_POST['name']) && !empty($_POST['email']) && !empty($_POST['message'])) {

                try {
                    $subject = !empty($_POST['subject']) ? esc_html($_POST['subject']) : sprintf(esc_html__('[%s] Email from contact form', 'medstore-helpers'), get_bloginfo('name'));
                    ob_start();
                        $message = sprintf(esc_html__('This email was sent from form contact on website %s', 'medstore-helpers'), get_bloginfo('name'))." \n\n\n";
                        $message .= esc_html__('Name:', 'medstore-helpers')." ".esc_html($_POST['name'])." \n\n";
                        $message .= esc_html__('Email:', 'medstore-helpers')." ".esc_html($_POST['email'])." \n\n";
                        $message .= esc_html__('Phone:', 'medstore-helpers')." ".esc_html($_POST['phone'])." \n\n";
                        $message .= esc_html__('Message:', 'medstore-helpers')."\n ".wp_kses_post($_POST['message'])."";
                    $message = @ob_get_clean();

                    Medstore_Helpers_Email::send(medstore_get_option('contact_email'), $subject, $message);

                } catch (\Throwable $th) {}

                $status['message'] = esc_html__('Email Sent Successfully!', 'medstore-helpers');
                $status['status'] = true;

            }
        }

        wp_send_json($status);
    }

}