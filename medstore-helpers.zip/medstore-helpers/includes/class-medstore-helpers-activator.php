<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */
class Medstore_Helpers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$rev = [
			'getTec' => [
				'engine' => 'SR6'
			],
			"version" => "6.2.0"
		];
		update_option('revslider-global-settings', json_encode($rev));

		$defaultSettings = get_option('woo_variation_gallery');
		if(empty($defaultSettings)){
			$string = '{"thumbnails_columns":"5","thumbnails_gap":"20","width":"100","medium_device_width":"0","small_device_width":"720","small_device_clear_float":"no","extra_small_device_width":"320","extra_small_device_clear_float":"no","margin":"24","preloader_disable":"no","preload_style":"blur","slider_autoplay":"no","slider_autoplay_speed":"5000","slide_speed":"300","slider_fade":"no","slider_arrow":"yes","zoom":"yes","lightbox":"yes","thumbnail_slide":"yes","thumbnail_arrow":"yes","zoom_position":"top-right","thumbnail_position":"bottom","thumbnail_position_small_device":"bottom"}';
			$gallerySettings = json_decode($string, true);
			update_option('woo_variation_gallery', $gallerySettings);
		}
	}

}
