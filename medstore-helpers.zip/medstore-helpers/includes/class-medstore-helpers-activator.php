<?php

/**
 * Fired during plugin activation
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/includes
 * @author     Nouthemes <nguyenvanqui89@gmail.com>
 */
class Medstore_Helpers_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {
		$rev = [
			'getTec' => [
				'engine' => 'SR6'
			],
			"version" => "6.2.0"
		];
		update_option('revslider-global-settings', json_encode($rev));
	}

}
