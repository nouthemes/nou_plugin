<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       https://https://codecanyon.net/user/nouthemes/portfolio
 * @since      1.0.0
 *
 * @package    Medstore_Helpers
 * @subpackage Medstore_Helpers/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
