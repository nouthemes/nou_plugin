<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://https://codecanyon.net/user/nouthemes/portfolio
 * @since             1.0.0
 * @package           Medstore_Helpers
 *
 * @wordpress-plugin
 * Plugin Name:       MedStore Helpers
 * Plugin URI:        https://https://codecanyon.net/user/nouthemes/portfolio
 * Description:       Shortcodes for MedStore theme
 * Version:           1.0.0
 * Author:            Nouthemes
 * Author URI:        https://https://codecanyon.net/user/nouthemes/portfolio/
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       medstore-helpers
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'MEDSTORE_HELPERS_VERSION', '1.0.0' );

if ( ! defined( '_MEDSTORE_OPTION_KEY' ) ) {
	define( '_MEDSTORE_OPTION_KEY', 'nou_ms_options' );
}

if ( ! defined( '_MEDSTORE_META_KEY' ) ) {
	define( '_MEDSTORE_META_KEY', 'nou_ms_meta' );
}

if ( ! defined( '_MEDSTORE_TAXONOMY_KEY' ) ) {
	define( '_MEDSTORE_TAXONOMY_KEY', 'nou_ms_taxonomy' );
}

if ( ! defined( '_MEDSTORE_URL' ) ) {
	define( '_MEDSTORE_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( '_MEDSTORE_IMG' ) ) {
	define( '_MEDSTORE_IMG', _MEDSTORE_URL.'assets/images' );
}

if (!defined('MEDSTORE_HELPERS_PLUGIN_DIR')) {
    define('MEDSTORE_HELPERS_PLUGIN_DIR', plugin_dir_path(__FILE__));
}
if (!defined('MEDSTORE_HELPERS_PLUGIN_URL')) {
    define('MEDSTORE_HELPERS_PLUGIN_URL', plugins_url('/', __FILE__));
}

require plugin_dir_path( __FILE__ ) . 'helpers.php';

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-medstore-helpers-activator.php
 */
function activate_medstore_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-medstore-helpers-activator.php';
	Medstore_Helpers_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-medstore-helpers-deactivator.php
 */
function deactivate_medstore_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-medstore-helpers-deactivator.php';
	Medstore_Helpers_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_medstore_helpers' );
register_deactivation_hook( __FILE__, 'deactivate_medstore_helpers' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-medstore-helpers.php';

add_action('vc_before_init', 'medstore_shortcodes_container');
function medstore_shortcodes_container(){
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	    class WPBakeryShortCode_Medstore_Our_Team extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Our_Stats extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Our_Services extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Testimonial extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Brands extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Categories extends WPBakeryShortCodesContainer {}
	    class WPBakeryShortCode_Medstore_Reviews extends WPBakeryShortCodesContainer {}
	}
	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_Medstore_Our_Team_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Our_Stats_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Our_Services_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Testimonial_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Brand_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Category_Item extends WPBakeryShortCode {}
	    class WPBakeryShortCode_Medstore_Review_Item extends WPBakeryShortCode {}
	}
}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_medstore_helpers() {

	$plugin = new Medstore_Helpers();
	$plugin->run();

}
run_medstore_helpers();
