<?php

/**
 * Get Option
 */
if (!function_exists('medstore_get_option')) {
    function medstore_get_option($key, $default = '')
    {
        $option = get_option(_MEDSTORE_OPTION_KEY);
        return (isset($option[$key])) ? $option[$key] : $default;
    }
}

if(!function_exists('medstore_esc')){
	function medstore_esc($content){
		return apply_filters('medstore_esc', $content);
	}
}

if( ! function_exists( 'medstore_validate_email' ) ) {
	function medstore_validate_email( $value ) {
	  if ( ! sanitize_email( $value ) ) {
		return esc_html__( 'Please write a valid email address!', 'medstore-helpers' );
	  }
	}
}

if(!function_exists('medstore_polylang_shortcode')){
	/**
	 * Polylang shortcode
	 * 
	 * @param array $atts
	 * @param string $content
	 * @return string
	 */
	function medstore_polylang_shortcode($atts, $content = null)
	{
		if (empty($content)){
			return '';
		}

		if(function_exists('pll_current_language')){
			extract( shortcode_atts( array('lang' => ''), $atts ) );
			return ($lang == pll_current_language()) ? $content : '';
		}
		
		return '';
	}
	add_shortcode('medstore_polylang', 'medstore_polylang_shortcode');
}

/**
* Get src loading image
* 
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
* @return url
* @code Nam
*/
if(!function_exists('medstore_theme_image_loading_src')){
	function medstore_theme_image_loading_src()
	{
	    return apply_filters('medstore_default_loading_img', 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==');
	}
}

if(!function_exists('medstore_generator_image')){
	function medstore_generator_image($src, $width = '', $height = '', $class = array(), $srcset = '', $loading_src = ''){
		$enable_lazy = medstore_get_option('enable_lazy', '1');
		if($enable_lazy){
			if($loading_src === ''){
				$loading_src = medstore_theme_image_loading_src();
			}

			$img = '<span data-max-height="'.esc_attr($height).'px" class="lazy-wrap">
				<img 
					src="'.esc_attr($loading_src).'" 
					class="medstore-lazy '.esc_attr(join(' ', $class)).'" 
					width="'.esc_attr( $width ).'" 
					height="'.esc_attr( $height ).'" 
					data-src="'.esc_attr( $src ).'" 
					data-srcset="'. esc_attr( $srcset ) .'" 
					alt="'.esc_attr(get_the_title()).'"
					data-max-height="'.esc_attr($height).'px"
				/>
			</span>';
		}else{
			$img = '<img data-max-height="'.esc_attr($height).'px" src="'.esc_attr($src).'" class="'.esc_attr(join(' ', $class)).'" alt="'.esc_attr(get_the_title()).'"  srcset="'. esc_attr( $srcset ) .'"/>';
		}

		return $img;
	}
}

/**
 * Get image by thumbnail id
 *
 * @package Medstore
 * @since 1.0
 * @author nouthemes [nouthemes@gmail.com]
 */
if(!function_exists('medstore_get_image_by_id')){
	function medstore_get_image_by_id($id, $size = 'thumbnail', $class = array()){
		$image_attributes = wp_get_attachment_image_src( $id, $size );
		if(empty($image_attributes)){
			return '';
		}

		$loading_src = wp_get_attachment_image_src( $id, 'medstore_low_res' );
		$srcset = wp_get_attachment_image_srcset( $id, $size );
		$img = medstore_generator_image($image_attributes[0], $image_attributes[1], $image_attributes[2], $class, $srcset, $loading_src[0]);
		echo wp_kses(
			$img, 
			array(
				'img' => array(
					'src' => array(),
					'class' => array(), 
					'data-src' => array(),
					'width' => array(),
					'height' => array(),
					'alt' => array(), 
					'style' => array(),
					'srcset' => array(),
					'data-srcset' => array(),
					'data-placeholder-background' => array(),
					'data-max-height' => array()
				),
				'span' => array(
					'id' => array(),
					'class' => array(),
					'data-max-height' => array()
				)
			));
	}
}

if (!function_exists('medstore_link_taxonomy_terms')) {
    function medstore_link_taxonomy_terms($taxonomy, $post_id = -1, $hide_empty = true)
    {
        $results = [];

        if($post_id == -1){
            $terms = get_terms( $taxonomy, ['hide_empty' => $hide_empty] );
        }else{
            $terms = get_the_terms($post_id, $taxonomy);
        }

        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            foreach ($terms as $term) {
                $results[] = [
                    'id' => $term->term_id,
                    'name' => sanitize_term_field('name', $term->name, $term->term_id, $taxonomy, 'display'),
                    'slug' => sanitize_term_field('slug', $term->slug, $term->term_id, $taxonomy, 'display'),
                    'url' => get_term_link( $term->slug, $taxonomy ),
                    'count' => $term->count
                ];
            }
        }

        return $results;
    }
}

/**
 * Get excerpt by post ID
 *
*/
if(!function_exists('medstore_get_excerpt')){
    function medstore_get_excerpt($length = 40) {
        $the_excerpt = get_the_excerpt();
        $words = explode(' ', $the_excerpt, $length + 1);
        if(count($words) == 0){
            $the_excerpt = get_the_content();
        }

        $the_excerpt = strip_tags(strip_shortcodes($the_excerpt));
        $words = explode(' ', $the_excerpt, $length + 1);
        if(count($words) > $length) {
            array_pop($words);
            array_push($words, '...');
            $the_excerpt = implode(' ', $words);
        }
        return wp_kses_post($the_excerpt);
    }
}

if ( ! function_exists( 'medstore_posted_on' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time.
	 */
	function medstore_posted_on($show_text = false) {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf(
			$time_string,
			esc_attr( get_the_date( DATE_W3C ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( DATE_W3C ) ),
			esc_html( get_the_modified_date() )
		);

		if($show_text){
			echo '<a class="no-more-class" href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>';
		}else{
			$posted_on = sprintf(
				/* translators: %s: post date. */
				esc_html_x( 'posted on %s', 'post date', "medstore-helpers" ),
				'<a class="no-more-class" href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
			);

			echo '<span class="posted-on">' . $posted_on . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}
endif;

if ( ! function_exists( 'medstore_posted_by' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function medstore_posted_by($only_name = false) {
		global $post;

		if($only_name){
			echo '<span class="author vcard"><a class="no-more-class url fn n" href="' . esc_url( get_author_posts_url( $post->post_author ) ) . '">' . esc_html( get_the_author_meta('display_name', $post->post_author) ) . '</a></span>';
		}else{
			$byline = sprintf(
				/* translators: %s: post author. */
				esc_html_x( 'By %s', 'post author', "medstore-helpers" ),
				'<span class="author vcard"><a class="no-more-class url fn n" href="' . esc_url( get_author_posts_url( $post->post_author ) ) . '">' . esc_html( get_the_author_meta('display_name', $post->post_author) ) . '</a></span>'
			);

			echo '<span class="byline"> ' . $byline . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

	}
endif;

/**
* Retrieve a post given its title.
*
* @uses $wpdb
*
* @param string $post_title Page title
* @param string $post_type post type ('post','page','any custom type')
* @param string $output Optional. Output type. OBJECT, ARRAY_N, or ARRAY_A.
* @return mixed
*/
if(!function_exists('medstore_get_post_by_title')){
	function medstore_get_post_by_title($page_title, $post_type ='post' , $output = OBJECT) {
		global $wpdb;
		$post = $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM $wpdb->posts WHERE post_title = %s AND post_type= %s", $page_title, $post_type));
		if ( $post ){
			return get_post($post, $output);
		}
		return null;
	}
}