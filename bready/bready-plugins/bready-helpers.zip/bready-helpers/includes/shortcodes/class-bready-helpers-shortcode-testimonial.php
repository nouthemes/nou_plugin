<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Testimonial
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'class'=> ''
		), $atts, 'noubready_testimonial' );
		
		$bg = BREADY_HELPERS_URL.'public/images/testimonials.jpg';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$bg = $images[0];
			}
		}
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-testimonials <?php echo esc_attr($atts['class']);?> bg--parallax" data-background="<?php echo esc_attr($bg);?>">
		        <div class="ps-container">
		          	<div class="ps-carousel--testimonial owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="5000" data-owl-gap="0" data-owl-nav="false" data-owl-dots="true" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-duration="1000" data-owl-mousedrag="off" data-owl-animate-in="fadeIn" data-owl-animate-out="fadeOut">
		          		<?php echo do_shortcode($content);?>
		          	</div>
		        </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Testimonial Carousel", "bready-helpers" ),
	      	"base" => "noubready_testimonial",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
	      	"params" => array(

	      		array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Background image", "bready-helpers" ),
					"param_name" => "img",
				),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Class", 'bready-helpers' ),
		            "param_name" => "class",
		        ),

	      	),
	      	"as_parent" => array('only' => 'noubready_testimonial_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>