<?php
/**
* 
*/
class Bready_Helpers_Shortcode_Delivery_Form
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'title' => '',
			'desc' => '',
			'class'=> ''
		), $atts, 'noubready_delivery_form' );
		
		$bg = '';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$bg = $images[0];
			}
		}
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-delivery-form bg--parallax <?php echo esc_attr($atts['class']);?>" data-background="<?php echo esc_attr($bg);?>">
				<div class="ps-block--delivery">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
							<div class="ps-block__content">
								<?php echo do_shortcode($content);?>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
							<form class="ps-form--delivery" action="<?php echo esc_url(home_url('/'));?>" method="post">
								<h3><?php echo esc_html($atts['title']);?></h3>
								<?php echo wp_kses_post(wpautop($atts['desc']));?>
								<div class="form-group">
									<label><?php esc_html_e('Name', 'bready-helpers');?> <sup>*</sup></label>
									<input class="form-control" name="name" type="text" placeholder="">
								</div>
								<div class="form-group">
									<label><?php esc_html_e('Email', 'bready-helpers');?> <sup>*</sup></label>
									<input class="form-control" name="email" type="email" placeholder="">
								</div>
								<div class="form-group">
									<label><?php esc_html_e('Phone Number', 'bready-helpers');?> <sup>*</sup></label>
									<input class="form-control" name="phone" type="text" placeholder="">
								</div>
								<div class="form-group submit">
									<button class="ps-btn"><?php esc_html_e('Order Now', 'bready-helpers');?></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bready - Delivery Form", "bready-helpers" ),
	      	"base" => "noubready_delivery_form",
	      	"class" => "",
	      	"category" => esc_html__( "Bready Theme", "bready-helpers"),
	      	"params" => array(

	      		array(
					"type" => "attach_image",
					"class" => "",
					"heading" => esc_html__( "Background image", "bready-helpers" ),
					"param_name" => "img",
				),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", 'bready-helpers' ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bready-helpers' ),
		            "param_name" => "desc",
		        ),
				array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Custom Class", 'bready-helpers' ),
		            "param_name" => "class",
		        ),

	      	),
	      	"as_parent" => array('only' => 'noubready_delivery_form_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>