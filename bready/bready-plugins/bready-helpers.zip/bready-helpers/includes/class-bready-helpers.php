<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       #
 * @since      1.0.0
 *
 * @package    Bready_Helpers
 * @subpackage Bready_Helpers/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Bready_Helpers
 * @subpackage Bready_Helpers/includes
 * @author     # <#>
 */
class Bready_Helpers {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Bready_Helpers_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		$this->plugin_name = 'bready-helpers';
		$this->version = '1.0.0';
		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Bready_Helpers_Loader. Orchestrates the hooks of the plugin.
	 * - Bready_Helpers_i18n. Defines internationalization functionality.
	 * - Bready_Helpers_Admin. Defines all hooks for the admin area.
	 * - Bready_Helpers_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function autoloader() 
	{
		require_once plugin_dir_path( __FILE__ ) . '/class-bready-helpers-autoloader.php';
		// Core loader
		$core_autoloader = new Bready_Helpers_Autoloader();
		spl_autoload_register( array( $core_autoloader, 'load' ) );
	}
	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Bready_Helpers_Loader. Orchestrates the hooks of the plugin.
	 * - Bready_Helpers_i18n. Defines internationalization functionality.
	 * - Bready_Helpers_Admin. Defines all hooks for the admin area.
	 * - Bready_Helpers_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		$this->autoloader();
		$this->loader = new Bready_Helpers_Loader();

	}
	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Bready_Helpers_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Bready_Helpers_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$plugin_admin = new Bready_Helpers_Admin( $this->get_plugin_name(), $this->get_version() );
		$plugin_admin->options();

	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {
		Bready_Helpers_Ajax::init();
		Bready_Helpers_Shortcodes::init();
		
		$plugin_public = new Bready_Helpers_Public( $this->get_plugin_name(), $this->get_version() );
		$this->loader->add_action( 'widgets_init', $plugin_public, 'widgets_init' );
		$this->loader->add_action( 'noubready_social', $plugin_public, 'social' );
		$this->loader->add_action( 'noubready_liked', $plugin_public, 'liked' );
		$this->loader->add_action( 'woocommerce_share', $plugin_public, 'woocommerce_social' );

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Bready_Helpers_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
