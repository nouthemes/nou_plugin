<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Framework constants
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
defined( 'BREADY_HELPERS_CS_VERSION' )    or  define( 'BREADY_HELPERS_CS_VERSION',    BREADY_HELPERS_VER );
defined( 'BREADY_HELPERS_CS_OPTION' )     or  define( 'BREADY_HELPERS_CS_OPTION',     '_noubready_options' );
defined( 'BREADY_HELPERS_CS_CUSTOMIZE' )  or  define( 'BREADY_HELPERS_CS_CUSTOMIZE',  '_noubready_customize_options' );

/**
 *
 * Framework path finder
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_get_path_locate' ) ) {
  function bready_helpers_cs_get_path_locate() {

    $dirname        = wp_normalize_path( BREADY_HELPERS_DIR.'/admin' );
    $plugin_dir     = wp_normalize_path( WP_PLUGIN_DIR );
    $located_plugin = ( preg_match( '#'. sanitize_file_name( $plugin_dir ) .'#', sanitize_file_name( $dirname ) ) ) ? true : false;
    $directory      = ( $located_plugin ) ? $plugin_dir : get_template_directory();
    $directory_uri  = ( $located_plugin ) ? WP_PLUGIN_URL : get_template_directory_uri();
    $basename       = str_replace( wp_normalize_path( $directory ), '', $dirname );
    $dir            = $directory . $basename;
    $uri            = $directory_uri . $basename;

    return apply_filters( 'bready_helpers_cs_get_path_locate', array(
      'basename' => wp_normalize_path( $basename ),
      'dir'      => wp_normalize_path( $dir ),
      'uri'      => $uri
    ) );

  }
}

/**
 *
 * Framework set paths
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 *
 */
$get_path = bready_helpers_cs_get_path_locate();

defined( 'BREADY_HELPERS_CS_BASENAME' )  or  define( 'BREADY_HELPERS_CS_BASENAME',  $get_path['basename'] );
defined( 'BREADY_HELPERS_CS_DIR' )       or  define( 'BREADY_HELPERS_CS_DIR',       $get_path['dir'] );
defined( 'BREADY_HELPERS_CS_URI' )       or  define( 'BREADY_HELPERS_CS_URI',       $get_path['uri'] );

/**
 *
 * Framework locate template and override files
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_locate_template' ) ) {
  function bready_helpers_cs_locate_template( $template_name ) {

    $located      = '';
    $override     = apply_filters( 'cs_framework_override', 'cs-framework-override' );
    $dir_plugin   = wp_normalize_path( WP_PLUGIN_DIR );
    $dir_theme    = get_template_directory();
    $dir_child    = get_template_directory();
    $dir_override = '/'. $override .'/'. $template_name;
    $dir_template = BREADY_HELPERS_CS_BASENAME .'/'. $template_name;

    // child theme override
    $child_force_overide    = $dir_child . $dir_override;
    $child_normal_override  = $dir_child . $dir_template;

    // theme override paths
    $theme_force_override   = $dir_theme . $dir_override;
    $theme_normal_override  = $dir_theme . $dir_template;

    // plugin override
    $plugin_force_override  = $dir_plugin . $dir_override;
    $plugin_normal_override = $dir_plugin . $dir_template;
    
    if ( file_exists( $child_force_overide ) ) {

      $located = $child_force_overide;

    } else if ( file_exists( $child_normal_override ) ) {

      $located = $child_normal_override;

    } else if ( file_exists( $theme_force_override ) ) {

      $located = $theme_force_override;

    } else if ( file_exists( $theme_normal_override ) ) {

      $located = $theme_normal_override;

    } else if ( file_exists( $plugin_force_override ) ) {

      $located =  $plugin_force_override;

    } else if ( file_exists( $plugin_normal_override ) ) {

      $located =  $plugin_normal_override;
    }

    $located = apply_filters( 'bready_helpers_cs_locate_template', $located, $template_name );

    if ( ! empty( $located ) ) {
      load_template( $located, true );
    }

    return $located;

  }
}

/**
 *
 * Get option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_option' ) ) {
  function bready_helpers_cs_get_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'bready_helpers_cs_get_option', get_option( BREADY_HELPERS_CS_OPTION ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

/**
 *
 * Set option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_set_option' ) ) {
  function bready_helpers_cs_set_option( $option_name = '', $new_value = '' ) {

    $options = apply_filters( 'bready_helpers_cs_set_option', get_option( BREADY_HELPERS_CS_OPTION ), $option_name, $new_value );

    if( ! empty( $option_name ) ) {
      $options[$option_name] = $new_value;
      update_option( BREADY_HELPERS_CS_OPTION, $options );
    }

  }
}

/**
 *
 * Get all option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_all_option' ) ) {
  function bready_helpers_cs_get_all_option() {
    return get_option( BREADY_HELPERS_CS_OPTION );
  }
}

/**
 *
 * Multi language option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_multilang_option' ) ) {
  function bready_helpers_cs_get_multilang_option( $option_name = '', $default = '' ) {

    $value     = bready_helpers_cs_get_option( $option_name, $default );
    $languages = bready_helpers_cs_language_defaults();
    $default   = $languages['default'];
    $current   = $languages['current'];

    if ( is_array( $value ) && is_array( $languages ) && isset( $value[$current] ) ) {
      return  $value[$current];
    } else if ( $default != $current ) {
      return  '';
    }

    return $value;

  }
}

/**
 *
 * Multi language value
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_multilang_value' ) ) {
  function bready_helpers_cs_get_multilang_value( $value = '', $default = '' ) {

    $languages = bready_helpers_cs_language_defaults();
    $default   = $languages['default'];
    $current   = $languages['current'];

    if ( is_array( $value ) && is_array( $languages ) && isset( $value[$current] ) ) {
      return  $value[$current];
    } else if ( $default != $current ) {
      return  '';
    }

    return $value;

  }
}

/**
 *
 * Get customize option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_customize_option' ) ) {
  function bready_helpers_cs_get_customize_option( $option_name = '', $default = '' ) {

    $options = apply_filters( 'bready_helpers_cs_get_customize_option', get_option( BREADY_HELPERS_CS_CUSTOMIZE ), $option_name, $default );

    if( ! empty( $option_name ) && ! empty( $options[$option_name] ) ) {
      return $options[$option_name];
    } else {
      return ( ! empty( $default ) ) ? $default : null;
    }

  }
}

/**
 *
 * Set customize option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_set_customize_option' ) ) {
  function bready_helpers_cs_set_customize_option( $option_name = '', $new_value = '' ) {

    $options = apply_filters( 'bready_helpers_cs_set_customize_option', get_option( BREADY_HELPERS_CS_CUSTOMIZE ), $option_name, $new_value );

    if( ! empty( $option_name ) ) {
      $options[$option_name] = $new_value;
      update_option( BREADY_HELPERS_CS_CUSTOMIZE, $options );
    }

  }
}

/**
 *
 * Get all customize option
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_all_customize_option' ) ) {
  function bready_helpers_cs_get_all_customize_option() {
    return get_option( BREADY_HELPERS_CS_CUSTOMIZE );
  }
}

/**
 *
 * WPML plugin is activated
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_is_wpml_activated' ) ) {
  function bready_helpers_cs_is_wpml_activated() {
    if ( class_exists( 'SitePress' ) ) { return true; } else { return false; }
  }
}

/**
 *
 * qTranslate plugin is activated
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_is_qtranslate_activated' ) ) {
  function bready_helpers_cs_is_qtranslate_activated() {
    if ( function_exists( 'qtrans_getSortedLanguages' ) ) { return true; } else { return false; }
  }
}

/**
 *
 * Polylang plugin is activated
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_is_polylang_activated' ) ) {
  function bready_helpers_cs_is_polylang_activated() {
    if ( class_exists( 'Polylang' ) ) { return true; } else { return false; }
  }
}

/**
 *
 * Get language defaults
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_language_defaults' ) ) {
  function bready_helpers_cs_language_defaults() {

    $multilang = array();

    if( bready_helpers_cs_is_wpml_activated() || bready_helpers_cs_is_qtranslate_activated() || bready_helpers_cs_is_polylang_activated() ) {

      if( bready_helpers_cs_is_wpml_activated() ) {

        global $sitepress;
        $multilang['default']   = $sitepress->get_default_language();
        $multilang['current']   = $sitepress->get_current_language();
        $multilang['languages'] = $sitepress->get_active_languages();

      } else if( bready_helpers_cs_is_polylang_activated() ) {

        global $polylang;
        $current    = pll_current_language();
        $default    = pll_default_language();
        $current    = ( empty( $current ) ) ? $default : $current;
        $poly_langs = $polylang->model->get_languages_list();
        $languages  = array();

        foreach ( $poly_langs as $p_lang ) {
          $languages[$p_lang->slug] = $p_lang->slug;
        }

        $multilang['default']   = $default;
        $multilang['current']   = $current;
        $multilang['languages'] = $languages;

      } else if( bready_helpers_cs_is_qtranslate_activated() ) {

        global $q_config;
        $multilang['default']   = $q_config['default_language'];
        $multilang['current']   = $q_config['language'];
        $multilang['languages'] = array_flip( qtrans_getSortedLanguages() );

      }

    }

    $multilang = apply_filters( 'bready_helpers_cs_language_defaults', $multilang );

    return ( ! empty( $multilang ) ) ? $multilang : false;

  }
}

/**
 *
 * Get locate for load textdomain
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if ( ! function_exists( 'bready_helpers_cs_get_locale' ) ) {
  function bready_helpers_cs_get_locale() {

    global $locale, $wp_local_package;

    if ( isset( $locale ) ) {
      return apply_filters( 'locale', $locale );
    }

    if ( isset( $wp_local_package ) ) {
      $locale = $wp_local_package;
    }

    if ( defined( 'WPLANG' ) ) {
      $locale = WPLANG;
    }

    if ( is_multisite() ) {

      if ( defined( 'WP_INSTALLING' ) || ( false === $ms_locale = get_option( 'WPLANG' ) ) ) {
        $ms_locale = get_site_option( 'WPLANG' );
      }

      if ( $ms_locale !== false ) {
        $locale = $ms_locale;
      }

    } else {

      $db_locale = get_option( 'WPLANG' );

      if ( $db_locale !== false ) {
        $locale = $db_locale;
      }

    }

    if ( empty( $locale ) ) {
      $locale = 'en_US';
    }

    return apply_filters( 'locale', $locale );

  }
}

