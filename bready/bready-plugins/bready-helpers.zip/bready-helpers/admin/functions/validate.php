<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Email validate
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_validate_email' ) ) {
  function bready_helpers_cs_validate_email( $value, $field ) {

    if ( ! sanitize_email( $value ) ) {
      return __( 'Please write a valid email address!', 'bready-helpers' );
    }

  }
  add_filter( 'bready_helpers_cs_validate_email', 'bready_helpers_cs_validate_email', 10, 2 );
}

/**
 *
 * Numeric validate
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_validate_numeric' ) ) {
  function bready_helpers_cs_validate_numeric( $value, $field ) {

    if ( ! is_numeric( $value ) ) {
      return __( 'Please write a numeric data!', 'bready-helpers' );
    }

  }
  add_filter( 'bready_helpers_cs_validate_numeric', 'bready_helpers_cs_validate_numeric', 10, 2 );
}

/**
 *
 * Required validate
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_validate_required' ) ) {
  function bready_helpers_cs_validate_required( $value ) {
    if ( empty( $value ) ) {
      return __( 'Fatal Error! This field is required!', 'bready-helpers' );
    }
  }
  add_filter( 'bready_helpers_cs_validate_required', 'bready_helpers_cs_validate_required' );
}
