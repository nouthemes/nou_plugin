<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Get icons from admin ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_get_icons' ) ) {
  function bready_helpers_cs_get_icons() {

    do_action( 'cs_add_icons_before' );

    $jsons = apply_filters( 'cs_add_icons_json', glob( BREADY_HELPERS_CS_DIR . '/fields/icon/*.json' ) );

    if( ! empty( $jsons ) ) {

      foreach ( $jsons as $path ) {

        $object = bready_helpers_cs_get_icon_fonts( 'fields/icon/'. basename( $path ) );

        if( is_object( $object ) ) {

          echo ( count( $jsons ) >= 2 ) ? '<h4 class="cs-icon-title">'. $object->name .'</h4>' : '';

          foreach ( $object->icons as $icon ) {
            echo '<a class="cs-icon-tooltip" data-cs-icon="'. $icon .'" data-title="'. $icon .'"><span class="cs-icon cs-selector"><i class="'. $icon .'"></i></span></a>';
          }

        } else {
          echo '<h4 class="cs-icon-title">'. __( 'Error! Can not load json file.', 'bready-helpers' ) .'</h4>';
        }

      }

    }

    do_action( 'cs_add_icons' );
    do_action( 'cs_add_icons_after' );

    die();
  }
  add_action( 'wp_ajax_cs-get-icons', 'bready_helpers_cs_get_icons' );
}

/**
 *
 * Export options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_export_options' ) ) {
  function bready_helpers_cs_export_options() {

    die();
  }
  add_action( 'wp_ajax_cs-export-options', 'bready_helpers_cs_export_options' );
}

/**
 *
 * Set icons for wp dialog
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'bready_helpers_cs_set_icons' ) ) {
  function bready_helpers_cs_set_icons() {

    echo '<div id="cs-icon-dialog" class="cs-dialog" title="'. __( 'Add Icon', 'bready-helpers' ) .'">';
    echo '<div class="cs-dialog-header cs-text-center"><input type="text" placeholder="'. __( 'Search a Icon...', 'bready-helpers' ) .'" class="cs-icon-search" /></div>';
    echo '<div class="cs-dialog-load"><div class="cs-icon-loading">'. __( 'Loading...', 'bready-helpers' ) .'</div></div>';
    echo '</div>';

  }
  add_action( 'admin_footer', 'bready_helpers_cs_set_icons' );
  add_action( 'customize_controls_print_footer_scripts', 'bready_helpers_cs_set_icons' );
}
