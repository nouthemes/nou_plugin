<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              #
 * @since             1.0.1
 * @package           Bready_Helpers
 *
 * @wordpress-plugin
 * Plugin Name:       Bready Helpers
 * Plugin URI:        #
 * Description:       This is a short description of what the plugin does. It's displayed in the WordPress admin area.
 * Version:           1.0.3
 * Author:            #
 * Author URI:        #
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       bready-helpers
 * Domain Path:       /languages
 */

if ( ! defined( 'WPINC' ) ) {
	die;
}

if ( ! defined( 'BREADY_HELPERS_VER' ) ) {
	/**
	 *
	 */
	define( 'BREADY_HELPERS_VER', '1.0.3' );
}

if ( ! defined( 'BREADY_HELPERS_DIR' ) ) {
	/**
	 *
	 */
	define( 'BREADY_HELPERS_DIR', plugin_dir_path( __FILE__ ) );
}

if ( ! defined( 'BREADY_HELPERS_URL' ) ) {
	/**
	 *
	 */
	define( 'BREADY_HELPERS_URL', plugin_dir_url( __FILE__ ) );
}

//include_once (WP_PLUGIN_DIR.'/woocommerce/includes/wc-widget-functions.php');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-bready-helpers-activator.php
 */
function activate_bready_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bready-helpers-activator.php';
	Bready_Helpers_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-bready-helpers-deactivator.php
 */
function deactivate_bready_helpers() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-bready-helpers-deactivator.php';
	Bready_Helpers_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_bready_helpers' );
register_deactivation_hook( __FILE__, 'deactivate_bready_helpers' );


/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'bready-helpers-functions.php';
require plugin_dir_path( __FILE__ ) . 'includes/class-bready-helpers.php';


add_action('vc_before_init', 'shortcodes_container_bready_helpers');

function shortcodes_container_bready_helpers(){
	if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
	    class WPBakeryShortCode_Noubready_Testimonial extends WPBakeryShortCodesContainer {
	    }
		class WPBakeryShortCode_Noubready_Countdown extends WPBakeryShortCodesContainer {
	    }
		class WPBakeryShortCode_Noubready_Delivery_Form extends WPBakeryShortCodesContainer {
	    }
		class WPBakeryShortCode_Noubready_Block_Square extends WPBakeryShortCodesContainer {
	    }
	}
	if ( class_exists( 'WPBakeryShortCode' ) ) {
	    class WPBakeryShortCode_Noubready_Testimonial_Item extends WPBakeryShortCode {
	    }
		class WPBakeryShortCode_Noubready_Countdown_Item extends WPBakeryShortCode {
	    }
		class WPBakeryShortCode_Noubready_Delivery_Form_Item extends WPBakeryShortCode {
	    }
		class WPBakeryShortCode_Noubready_Block_Square_Item extends WPBakeryShortCode {
	    }
	}
}

add_action( 'widgets_init', 'override_woocommerce_widgets', 15 );

function override_woocommerce_widgets() {
  // Ensure our parent class exists to avoid fatal error (thanks Wilgert!)

  if ( class_exists( 'WC_Widget_Price_Filter' ) ) {
    unregister_widget( 'WC_Widget_Price_Filter' );

    include_once( plugin_dir_path( __FILE__ ) . 'includes/widgets/class-bready-helpers-widget-filter-price.php' );

    register_widget( 'Noubready_Theme_Widget_Filter_Price' );
  }
  
  if ( class_exists( 'WC_Widget_Layered_Nav' ) ) {
    unregister_widget( 'WC_Widget_Layered_Nav' );

    include_once( plugin_dir_path( __FILE__ ) . 'includes/widgets/class-bready-helpers-widget-product-attribute.php' );

    register_widget( 'Noubready_Theme_Widget_Product_Attribute' );
  }

}

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_bready_helpers() {

	$plugin = new Bready_Helpers();
	$plugin->run();

}
run_bready_helpers();
