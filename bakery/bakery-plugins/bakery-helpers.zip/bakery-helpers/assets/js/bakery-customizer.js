;(function ( $ ) {

  if ( wp && wp.customize ) {

    api = wp.customize;

    api( '_noubakery_customize_options[header_notify]', function( value ) {
      value.bind( function( to ) {
        if( to ) {
			   $( '.header__top .col-lg-8 p' ).text( to );
        }
      });
    });

    api( '_noubakery_customize_options[logo_1]', function( value ) {
      value.bind( function( to ) {
        if( to ) {
          $( '.ps-logo .logo-none-sticky' ).attr( 'src', to );
        }
      });
    });

    api( '_noubakery_customize_options[copyright]', function( value ) {
      value.bind( function( to ) {
        if( to ) {
          $( '.footer-copyright' ).html(to);
        }
      });
    });

  }

})( jQuery );