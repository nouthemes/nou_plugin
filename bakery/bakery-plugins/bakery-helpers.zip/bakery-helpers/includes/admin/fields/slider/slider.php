<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Slider
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_slider extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output(){

    echo noubakery_esc($this->element_before());
    echo '<input type="range" name="'. esc_attr($this->element_name()) .'" value="'. esc_attr($this->element_value()) .'"'. $this->element_class() . $this->element_attributes() .' data-rangeslider/><div class="rangeslider rangeslider--horizontal" id="js-rangeslider-'. esc_attr($this->element_name()) .'"><div class="rangeslider__fill" style="width: 124px;"></div><div class="rangeslider__handle"></div></div><output></output>';
    echo noubakery_esc($this->element_after());

  }

}
