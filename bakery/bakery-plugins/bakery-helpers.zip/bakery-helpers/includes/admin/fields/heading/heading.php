<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Heading
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_heading extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output() {

    echo noubakery_esc($this->element_before());
    echo noubakery_esc($this->field['content']);
    echo noubakery_esc($this->element_after());

  }

}
