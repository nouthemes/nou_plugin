<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Switcher
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_switcher extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output() {

    echo noubakery_esc($this->element_before());
    $label = ( isset( $this->field['label'] ) ) ? '<div class="cs-text-desc">'. esc_html($this->field['label']) . '</div>' : '';
    echo '<label><input type="checkbox" name="'. esc_attr($this->element_name()) .'" value="1"'. $this->element_class() . $this->element_attributes() . checked( $this->element_value(), 1, false ) .'/><em data-on="'. esc_html__( 'on', 'bakery-helpers' ) .'" data-off="'. esc_html__( 'off', 'bakery-helpers' ) .'"></em><span></span></label>' . wp_kses_post($label);
    echo noubakery_esc($this->element_after());

  }

}
