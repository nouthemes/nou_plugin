<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Fieldset
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_fieldset extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output() {

    echo noubakery_esc($this->element_before());

    echo '<div class="cs-inner">';

    foreach ( $this->field['fields'] as $field ) {

      $field_id    = ( isset( $field['id'] ) ) ? $field['id'] : '';
      $field_value = ( isset( $this->value[$field_id] ) ) ? $this->value[$field_id] : '';
      $unique_id   = $this->unique .'['. $this->field['id'] .']';

      if ( ! empty( $this->field['un_array'] ) ) {
        echo noubakery_cs_add_element( $field, noubakery_noubakery_cs_get_option( $field_id ), $this->unique );
      } else {
        echo noubakery_cs_add_element( $field, $field_value, $unique_id );
      }

    }

    echo '</div>';

    echo noubakery_esc($this->element_after());

  }

}
