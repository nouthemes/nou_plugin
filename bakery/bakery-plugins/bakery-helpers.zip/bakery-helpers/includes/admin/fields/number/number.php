<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Number
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_number extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output() {

    echo noubakery_esc($this->element_before());
    $unit = ( isset( $this->field['unit'] ) ) ? '<em>'. wp_kses_post($this->field['unit']) .'</em>' : '';
    echo '<input type="number" name="'. esc_attr($this->element_name()) .'" value="'. esc_attr($this->element_value()).'"'. $this->element_class() . $this->element_attributes() .'/>'. wp_kses_post($unit);
    echo noubakery_esc($this->element_after());

  }

}
