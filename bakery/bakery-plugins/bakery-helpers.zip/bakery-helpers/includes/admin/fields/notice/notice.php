<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Field: Notice
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
class Noubakery_CSFramework_Option_notice extends Noubakery_CSFramework_Options {

  public function __construct( $field, $value = '', $unique = '' ) {
    parent::__construct( $field, $value, $unique );
  }

  public function output() {

    echo noubakery_esc($this->element_before());
    echo '<div class="cs-notice cs-'. esc_attr($this->field['class']) .'">'. wp_kses_post($this->field['content']) .'</div>';
    echo noubakery_esc($this->element_after());

  }

}
