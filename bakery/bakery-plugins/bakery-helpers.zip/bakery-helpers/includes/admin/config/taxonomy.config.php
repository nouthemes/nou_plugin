<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// TAXONOMY OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options     = array();

// -----------------------------------------
// Taxonomy Options                        -
// -----------------------------------------
$options[]   = array(
  'id'       => 'noubakery_layout_settings',
  'taxonomy' => 'category', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    // begin: a field
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Header styles', 'bakery-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Choose a style', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Style 1', 'bakery-helpers'),
        '2' => esc_html__('Style 2', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'      => 'logo_1',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '1' ),
    ),
    array(
      'id'      => 'logo_2',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '2' ),
    ),
    array(
      'id'      => 'logo_sticky',
      'type'    => 'upload',
      'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
    ),

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Section heading', 'bakery-helpers'),
    ),
    array(
      'id'        => 'display_heading',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable heading section', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Panel background', 'bakery-helpers'),
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'id'      => 'panel_background',
      'type'    => 'upload',
      'title'   => esc_html__('Upload banner', 'bakery-helpers'),
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'bakery-helpers'),
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'bakery-helpers'),
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'id'        => 'post_title_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable title', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0',
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'id'        => 'panel_breadcrumb',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0',
      'dependency'   => array( 'display_heading', '!=', '2' ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Sidebar', 'bakery-helpers'),
    ),
    array(
      'id'        => 'sidebar',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Sidebar style', 'bakery-helpers'),
      'options'   => array(
        '0'     => esc_html__('Default', 'bakery-helpers'),
        'right' => esc_html__('Right', 'bakery-helpers'),
        'left' => esc_html__('Left', 'bakery-helpers'),
        'hide' => esc_html__('No sidebar', 'bakery-helpers'),
      ),
    ),
  ),
);

$options[]   = array(
  'id'       => 'noubakery_layout_settings',
  'taxonomy' => 'post_tag', // category, post_tag or your custom taxonomy name
  'fields'   => array(

    // begin: a field
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Header styles', 'bakery-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Choose a style', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Style 1', 'bakery-helpers'),
        '2' => esc_html__('Style 2', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'      => 'logo_1',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '1' ),
    ),
    array(
      'id'      => 'logo_2',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '2' ),
    ),
    array(
      'id'      => 'logo_sticky',
      'type'    => 'upload',
      'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Panel background', 'bakery-helpers'),
    ),
    array(
      'id'      => 'panel_background',
      'type'    => 'upload',
      'title'   => esc_html__('Upload banner', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'bakery-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'bakery-helpers'),
    ),
    array(
      'id'        => 'post_title_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable title', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
    ),
    array(
      'id'        => 'panel_breadcrumb',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Sidebar', 'bakery-helpers'),
    ),
    array(
      'id'        => 'sidebar',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Sidebar style', 'bakery-helpers'),
      'options'   => array(
        '0'     => esc_html__('Default', 'bakery-helpers'),
        'right' => esc_html__('Right', 'bakery-helpers'),
        'left' => esc_html__('Left', 'bakery-helpers'),
        'hide' => esc_html__('No sidebar', 'bakery-helpers'),
      ),
    ),
  ),
);

if(class_exists('Woocommerce')){
  $options[]      = array(
    'id'        => 'noubakery_layout_settings',
    'taxonomy' => 'product_cat', 
    // begin: fields
    'fields'      => array(

      array(
      'type'    => 'subheading',
      'content' => esc_html__('Header styles', 'bakery-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Choose a style', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Style 1', 'bakery-helpers'),
        '2' => esc_html__('Style 2', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'      => 'logo_1',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '1' ),
    ),
    array(
      'id'      => 'logo_2',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '2' ),
    ),
    array(
      'id'      => 'logo_sticky',
      'type'    => 'upload',
      'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Panel background', 'bakery-helpers'),
    ),
    array(
      'id'      => 'panel_background',
      'type'    => 'upload',
      'title'   => esc_html__('Upload banner', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'bakery-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'bakery-helpers'),
    ),
    array(
      'id'        => 'post_title_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable title', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
    ),
    array(
      'id'        => 'panel_breadcrumb',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Shop banner', 'bakery-helpers'),
    ),
    array(
      'id'        => 'noubakery_shop_banner_settings',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Banner', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Custome', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'              => 'noubakery_shop_banner',
      'type'            => 'group',
      'button_title'    => esc_html__('Add banners', 'bakery-helpers'),
      'accordion_title' => esc_html__('Shop banner', 'bakery-helpers'),
      'fields'          => array(
        array(
          'id'    => 'img',
          'type'  => 'upload',
          'title' => esc_html__('Upload banner', 'bakery-helpers'),
        ),
        array(
          'id'    => 'url',
          'type'  => 'text',
          'title' => esc_html__('Banner URL', 'bakery-helpers'),
        ),
        array(
          'id'    => 'col',
          'type'  => 'number',
          'default' => 6,
          'title' => esc_html__('Banner column', 'bakery-helpers'),
        ),
      ),
      'dependency'   => array( 'noubakery_shop_banner_settings', '==', '1' ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Sidebar', 'bakery-helpers'),
    ),
      array(
        'id'        => 'sidebar',
        'type'      => 'select',
        'title'     => esc_html__('Sidebar', 'bakery-helpers'),
        'class'     => 'chosen',
        'options'   => array(
           '0' => esc_html__('Default', 'bakery-helpers'),
          'right' => esc_html__('Right', 'bakery-helpers'),
          'left' => esc_html__('Left', 'bakery-helpers'),
          'hide' => esc_html__('No sidebar', 'bakery-helpers'),
        ),
      ),


    ), // end: fields
  );

  $options[]      = array(
    'id'        => 'noubakery_layout_settings',
    'taxonomy' => 'product_tag', 
    // begin: fields
    'fields'      => array(

      array(
      'type'    => 'subheading',
      'content' => esc_html__('Header styles', 'bakery-helpers'),
    ),
    array(
      'id'        => 'header_style',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Choose a style', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Style 1', 'bakery-helpers'),
        '2' => esc_html__('Style 2', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'      => 'logo_1',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '1' ),
    ),
    array(
      'id'      => 'logo_2',
      'type'    => 'upload',
      
      'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
      'dependency'   => array( 'header_style', '==', '2' ),
    ),
    array(
      'id'      => 'logo_sticky',
      'type'    => 'upload',
      'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Panel background', 'bakery-helpers'),
    ),
    array(
      'id'      => 'panel_background',
      'type'    => 'upload',
      'title'   => esc_html__('Upload banner', 'bakery-helpers'),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Custome title', 'bakery-helpers'),
    ),
    array(
      'id'      => 'post_title',
      'type'    => 'text',
      'title'   => esc_html__('Title', 'bakery-helpers'),
    ),
    array(
      'id'        => 'post_title_enable',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable title', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
    ),
    array(
      'id'        => 'panel_breadcrumb',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Show', 'bakery-helpers'),
        '2' => esc_html__('Hide', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Shop banner', 'bakery-helpers'),
    ),
    array(
      'id'        => 'shop_banner_settings',
      'type'      => 'select',
      'class'     => 'chosen',
      'title'     => esc_html__('Banner', 'bakery-helpers'),
      'options'   => array(
        '0' => esc_html__('Default', 'bakery-helpers'),
        '1' => esc_html__('Custome', 'bakery-helpers'),
      ),
      'default' => '0'
    ),
    array(
      'id'              => 'shop_banner',
      'type'            => 'group',
      'button_title'    => esc_html__('Add banners', 'bakery-helpers'),
      'accordion_title' => esc_html__('Shop banner', 'bakery-helpers'),
      'fields'          => array(
        array(
          'id'    => 'img',
          'type'  => 'upload',
          'title' => esc_html__('Upload banner', 'bakery-helpers'),
        ),
        array(
          'id'    => 'url',
          'type'  => 'text',
          'title' => esc_html__('Banner URL', 'bakery-helpers'),
        ),
        array(
          'id'    => 'col',
          'type'  => 'number',
          'default' => 6,
          'title' => esc_html__('Banner column', 'bakery-helpers'),
        ),
      ),
      'dependency'   => array( 'shop_banner_settings', '==', '1' ),
    ),
    array(
      'type'    => 'subheading',
      'content' => esc_html__('Sidebar', 'bakery-helpers'),
    ),
      array(
        'id'        => 'sidebar',
        'type'      => 'select',
        'title'     => esc_html__('Sidebar', 'bakery-helpers'),
        'class'     => 'chosen',
        'options'   => array(
           '0' => esc_html__('Default', 'bakery-helpers'),
          'right' => esc_html__('Right', 'bakery-helpers'),
          'left' => esc_html__('Left', 'bakery-helpers'),
          'hide' => esc_html__('No sidebar', 'bakery-helpers'),
        ),
      ),


    ), // end: fields
  );
  
}

Noubakery_CSFramework_Taxonomy::instance( $options );
