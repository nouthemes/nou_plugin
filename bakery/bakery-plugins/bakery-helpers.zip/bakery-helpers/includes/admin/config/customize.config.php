<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// CUSTOMIZE SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options              = array();

// -----------------------------------------
// Customize Core Fields                   -
// -----------------------------------------
$options[]            = array(
  'name'              => 'header',
  'title'             => esc_html__('Header', 'bakery-helpers'),
  'settings'          => array(

    // textarea
    array(
      'name'          => 'header_notify',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Notifycation content', 'bakery-helpers'),
        'type'        => 'textarea',
      ),
    ),
    array(
      'name'          => 'logo_1',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Logo for header style #1', 'bakery-helpers'),
        'type'        => 'upload',
      ),
    ),
    array(
      'name'          => 'logo_2',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Logo for header style #2', 'bakery-helpers'),
        'type'        => 'upload',
      ),
    ),
    array(
      'name'          => 'logo_sticky',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Logo sticky menu', 'bakery-helpers'),
        'type'        => 'upload',
      ),
    ),

  )
);
$options[]            = array(
  'name'              => 'footer',
  'title'             => esc_html__('Footer', 'bakery-helpers'),
  'settings'          => array(

    array(
      'name'          => 'copyright_subheading',
      'control'       => array(
        'type'        => 'cs_field',
        'options'     => array(
          'type'      => 'subheading',
          'content'   => esc_html__('Copyright', 'bakery-helpers'),
        ),
      ),
    ),
    // textarea
    array(
      'name'          => 'copyright',
      'transport'     => 'postMessage',
      'control'       => array(
        'label'       => esc_html__('Copyright text', 'bakery-helpers'),
        'type'        => 'textarea',
      ),
    ),

  )
);

Noubakery_CSFramework_Customize::instance( $options );
