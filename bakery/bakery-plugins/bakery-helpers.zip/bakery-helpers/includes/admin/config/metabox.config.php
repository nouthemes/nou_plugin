<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// METABOX OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options      = array();

// -----------------------------------------
// Page Metabox Options                    -
// -----------------------------------------
$options[]    = array(
  'id'        => 'noubakery_layout_settings',
  'title'     => esc_html__('Layout Settings', 'bakery-helpers'),
  'post_type' => array('page', 'post'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'general',
      'title' => esc_html__('General', 'bakery-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Single thumbnail image', 'bakery-helpers'),
        ),
        array(
          'id'        => 'single_thumbnail',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable Thumbnail', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'default' => '0'
        ),
        
      
      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'layout_settings_header',
      'title' => esc_html__('Header', 'bakery-helpers'),
      'icon'  => 'fa fa-bars',

      // begin: fields
      'fields' => array(

        // begin: a field
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header styles', 'bakery-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Choose a style', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Style 1', 'bakery-helpers'),
            '2' => esc_html__('Style 2', 'bakery-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'      => 'logo_1',
          'type'    => 'upload',
          
          'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
          'dependency'   => array( 'header_style', '==', '1' ),
        ),
        array(
          'id'      => 'logo_2',
          'type'    => 'upload',
          
          'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
          'dependency'   => array( 'header_style', '==', '2' ),
        ),
        array(
          'id'      => 'logo_sticky',
          'type'    => 'upload',
          'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Section heading', 'bakery-helpers'),
        ),
        array(
          'id'        => 'display_heading',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable heading section', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Panel background', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'      => 'panel_background',
          'type'    => 'upload',
          'title'   => esc_html__('Upload banner', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),

        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Custome title', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'        => 'post_title_enable',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable title', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'dependency'   => array( 'display_heading', '!=', '2' ),
          'default' => '0'
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'        => 'panel_breadcrumb',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'dependency'   => array( 'display_heading', '!=', '2' ),
          'default' => '0'
        ),

      ), // end: fields
    ), // end: a section

    // begin: a section
    array(
      'name'  => 'sidebar',
      'title' => esc_html__('Sidebar', 'bakery-helpers'),
      'icon'  => 'fa fa-tint',
      'fields' => array(

        array(
          'id'        => 'sidebar',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Sidebar style', 'bakery-helpers'),
          'options'   => array(
            '0'     => esc_html__('Default', 'bakery-helpers'),
            'right' => esc_html__('Right', 'bakery-helpers'),
            'left' => esc_html__('Left', 'bakery-helpers'),
            'hide' => esc_html__('No sidebar', 'bakery-helpers'),
          ),
        ),

        

      ),
    ),
    // end: a section

    // begin: a section
    array(
      'name'  => 'advanced',
      'title' => esc_html__('Advanced', 'bakery-helpers'),
      'icon'  => 'fa fa-share-alt',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Social', 'bakery-helpers'),
        ),
        array(
          'id'      => 'social_share',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable share button', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Author info', 'bakery-helpers'),
        ),
        array(
          'id'      => 'author_info',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable author info', 'bakery-helpers'),
        ),
        

      ),
    ),
    // end: a section

    // begin: a section
    array(
      'name'  => 'contact',
      'title' => esc_html__('Contact info', 'bakery-helpers'),
      'icon'  => 'fa fa-envelope-o',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Contact infomations', 'bakery-helpers'),
        ),
        array(
          'id'              => 'contact',
          'type'            => 'group',
          'button_title'    => esc_html__('Add New', 'bakery-helpers'),
          'accordion_title' => esc_html__('Add New Info', 'bakery-helpers'),
          'fields'          => array(
            array(
              'id'    => 'title',
              'type'  => 'text',
              'title' => esc_html__('Title', 'bakery-helpers'),
            ),
            array(
              'id'    => 'address',
              'type'  => 'text',
              'title' => esc_html__('Address', 'bakery-helpers'),
            ),
            array(
              'id'    => 'email',
              'type'  => 'text',
              'title' => esc_html__('Email', 'bakery-helpers'),
            ),
            array(
              'id'    => 'phone',
              'type'  => 'text',
              'title' => esc_html__('Phone', 'bakery-helpers'),
            ),
            array(
              'id'    => 'fb',
              'type'  => 'text',
              'title' => esc_html__('Facebook', 'bakery-helpers'),
            ),
            array(
              'id'    => 'twitter',
              'type'  => 'text',
              'title' => esc_html__('Twitter', 'bakery-helpers'),
            ),
            array(
              'id'    => 'tiktok',
              'type'  => 'text',
              'title' => esc_html__('Tiktok', 'bakery-helpers'),
            ),
            array(
              'id'    => 'instagram',
              'type'  => 'text',
              'title' => esc_html__('Instagram', 'bakery-helpers'),
            ),
            array(
              'id'    => 'rss',
              'type'  => 'text',
              'title' => esc_html__('RSS', 'bakery-helpers'),
            ),
          ),
        ),
        
      
      ),
    ),
    // end: a section

  ),
);


$options[]    = array(
  'id'        => 'noubakery_layout_settings',
  'title'     => esc_html__('Layout Settings', 'bakery-helpers'),
  'post_type' => array('product'),
  'context'   => 'normal',
  'priority'  => 'default',
  'sections'  => array(

    // begin: a section
    array(
      'name'  => 'general',
      'title' => esc_html__('General', 'bakery-helpers'),
      'icon'  => 'fa fa-cog',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Layout', 'bakery-helpers'),
        ),
        array(
          'id'        => 'layout',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Set layout', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '2' => esc_html__('With offer form', 'bakery-helpers'),
          ),
          'default' => '0',
          'help' => esc_html__('Product layout details for default Woocommerce or quick offer form.', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Description form', 'bakery-helpers'),
          'dependency'   => array( 'layout', '==', '2' ),
        ),
        array(
          'id'      => 'shop_form_desc',
          'type'    => 'text',
          'title'   => esc_html__('Description', 'bakery-helpers'),
          'dependency'   => array( 'layout', '==', '2' ),
        ),
        array(
          'id'      => 'shop_form_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'bakery-helpers'),
          'dependency'   => array( 'layout', '==', '2' ),
        ),
      
      ),
    ),
    // end: a section
    // begin: a section
    array(
      'name'  => 'layout_settings_header',
      'title' => esc_html__('Header', 'bakery-helpers'),
      'icon'  => 'fa fa-bars',

      // begin: fields
      'fields' => array(

        // begin: a field
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header styles', 'bakery-helpers'),
        ),
        array(
          'id'        => 'header_style',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Choose a style', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Style 1', 'bakery-helpers'),
            '2' => esc_html__('Style 2', 'bakery-helpers'),
          ),
          'default' => '0'
        ),
        array(
          'id'      => 'logo_1',
          'type'    => 'upload',
          
          'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
          'dependency'   => array( 'header_style', '==', '1' ),
        ),
        array(
          'id'      => 'logo_2',
          'type'    => 'upload',
          
          'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
          'dependency'   => array( 'header_style', '==', '2' ),
        ),
        array(
          'id'      => 'logo_sticky',
          'type'    => 'upload',
          'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Section heading', 'bakery-helpers'),
        ),
        array(
          'id'        => 'display_heading',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable heading section', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'default' => '0'
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Panel background', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'      => 'panel_background',
          'type'    => 'upload',
          'title'   => esc_html__('Upload banner', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),

        
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Custome title', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'      => 'post_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'        => 'post_title_enable',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable title', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'default' => '0',
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Breadcrumb', 'bakery-helpers'),
          'dependency'   => array( 'display_heading', '!=', '2' ),
        ),
        array(
          'id'        => 'panel_breadcrumb',
          'type'      => 'select',
          'class'     => 'chosen',
          'title'     => esc_html__('Enable breadcrumb', 'bakery-helpers'),
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            '1' => esc_html__('Show', 'bakery-helpers'),
            '2' => esc_html__('Hide', 'bakery-helpers'),
          ),
          'dependency'   => array( 'display_heading', '!=', '2' ),
          'default' => '0'
        ),

      ), // end: fields
    ), // end: a section
    // begin: a section
    array(
      'name'  => 'bottom',
      'title' => esc_html__('Related products', 'bakery-helpers'),
      'icon'  => 'fa fa-link',
      'fields' => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Related products', 'bakery-helpers'),
        ),
        array(
          'id'        => 'product_related_type',
          'type'      => 'select',
          'title'     => esc_html__('Related type', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '0' => esc_html__('Default', 'bakery-helpers'),
            'related' => esc_html__('Related products', 'bakery-helpers'),
            'bestsale' => esc_html__('Best seller', 'bakery-helpers'),
            'featured' => esc_html__('Featured products', 'bakery-helpers'),
            'sale' => esc_html__('On sale', 'bakery-helpers'),
          ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Description', 'bakery-helpers'),
        ),
        array(
          'id'      => 'shop_related_desc',
          'type'    => 'text',
          'title'   => esc_html__('Description', 'bakery-helpers'),
        ),
        array(
          'id'      => 'shop_related_title',
          'type'    => 'text',
          'title'   => esc_html__('Title', 'bakery-helpers'),
        ),
      
      ),
    ),
    // end: a section


  ),
);

$options[]    = array(
  'id'        => '_product_video',
  'title'     => esc_html__('Video Youtube Only', 'bakery-helpers'),
  'post_type' => 'product',
  'context'   => 'side',
  'priority'  => 'default',
  'sections'  => array(

    array(
      'name'   => 'section_1',
      'fields' => array(
        array(
          'id'            => 'url',
          'title'     => esc_html__('URL', 'bakery-helpers'),
          'type'          => 'text',
          'desc'    => esc_html__('EX: https://www.youtube.com/watch?v=4ZighUyrsRU', 'bakery-helpers'),
        ),
      ),
    ),

  ),
);

Noubakery_CSFramework_Metabox::instance( $options );
