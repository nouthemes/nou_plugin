<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK SETTINGS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$settings           = array(
  'menu_title'      => esc_html__('Theme options', 'bakery-helpers'),
  'menu_type'       => 'theme', // menu, submenu, options, theme, etc.
  'menu_slug'       => 'noubakery_options',
  'ajax_save'       => false,
  'show_reset_all'  => false,
  'framework_title' => esc_html__('Bakery Theme', 'bakery-helpers').' '.NOUBAKERY_VER,
  'menu_position' => 10
);

// ===============================================================================================
// -----------------------------------------------------------------------------------------------
// FRAMEWORK OPTIONS
// -----------------------------------------------------------------------------------------------
// ===============================================================================================
$options        = array();

// ----------------------------------------
// a option section for options overview  -
// ----------------------------------------
$options[]      = array(
  'name'        => 'general',
  'title'       => esc_html__('General', 'bakery-helpers'),
  'icon'        => 'fa fa-cog',

  // begin: fields
  'fields'      => array(

    array(
      'id'      => 'noubakery_email',
      'type'    => 'text',
      'default' => 'email@bakery.com',
      'title'   => esc_html__('Email', 'bakery-helpers'),
      'validate' => 'email',
    ),
    array(
      'id'      => 'noubakery_lazy',
      'type'    => 'switcher',
      'default' => false,
      'title'   => esc_html__('Enable lazy loading', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_loader',
      'type'    => 'switcher',
      'default' => true,
      'title'   => esc_html__('Enable loader', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_notify_timeout',
      'type'    => 'number',
      'validate' => 'numeric',
      'default' => 3000,
      'title'   => esc_html__('Notifications timeout', 'bakery-helpers'),
      'help'    => esc_html__('If delay is set higher than 0 then the notification will auto-close after the delay period is up. Please keep in mind that delay uses milliseconds so 3000 is 3 seconds.', 'bakery-helpers'),
    ),

  ), // end: fields
);

$options[]   = array(
  'name'        => 'header',
  'title'       => esc_html__('Header', 'bakery-helpers'),
  'icon'        => 'fa fa-bars',
  'sections' => array(
    // sub section 1
    array(
      'name'     => 'header_sub_section_1',
      'title'    => esc_html__('Header styles', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        
        array(
          'id'        => 'noubakery_header_style',
          'type'      => 'image_select',
          'title'     => esc_html__('Choose a style', 'bakery-helpers'),
          'options'   => array(
            '1' => esc_url(NOUBAKERY_IMG.'/header/1.png'),
            '2' => esc_url(NOUBAKERY_IMG.'/header/2.png'),
            '3' => esc_url(NOUBAKERY_IMG.'/header/3.png'),
          ),
          'default' => '3'
        ),

        array(
          'id'      => 'noubakery_logo_1',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/logo-1.png'),
          'title'   => esc_html__('Upload logo for header #1', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_style_1', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_1_width',
          'type'    => 'number',
          'title'   => esc_html__('Logo #1 Width (px)', 'bakery-helpers'),
          'default' => '150',
          'attributes' => array(
            'min'  => 50,
            'max'  => 500,
            'step' => 1,
          ),
          'dependency'   => array( 'noubakery_header_style_1', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_2',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/logo-2.png'),
          'title'   => esc_html__('Upload logo for header #2', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_style_2', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_2_width',
          'type'    => 'number',
          'title'   => esc_html__('Logo #2 Width (px)', 'bakery-helpers'),
          'default' => '150',
          'attributes' => array(
            'min'  => 50,
            'max'  => 500,
            'step' => 1,
          ),
          'dependency'   => array( 'noubakery_header_style_2', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_3',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/logo-new.png'),
          'title'   => esc_html__('Upload logo for header #3', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_style_3', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_3_width',
          'type'    => 'number',
          'title'   => esc_html__('Logo #3 Width (px)', 'bakery-helpers'),
          'default' => '150',
          'attributes' => array(
            'min'  => 50,
            'max'  => 500,
            'step' => 1,
          ),
          'dependency'   => array( 'noubakery_header_style_3', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_logo_sticky',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/logo-new-2.png'),
          'title'   => esc_html__('Upload logo for sticky menu', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_logo_sticky_width',
          'type'    => 'number',
          'title'   => esc_html__('Sticky Logo Width (px)', 'bakery-helpers'),
          'default' => '50',
          'attributes' => array(
            'min'  => 30,
            'max'  => 300,
            'step' => 1,
          ),
        ),

      )
    ),
    // sub section 2
    array(
      'name'     => 'header_sub_section_2',
      'title'    => esc_html__('Header Top', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'id'      => 'noubakery_header_top_enable',
          'type'    => 'switcher',
          'default' => false,
          'title'   => esc_html__('Enable header top seaction', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_header_notify_enable',
          'type'    => 'switcher',
          'default' => false,
          'title'   => esc_html__('Enable Notifycation', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_top_enable', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_header_notify',
          'type'    => 'textarea',
          'default' => esc_html__('460 West 34th Street, 15th floor, New York - Hotline: 804-377-3580 - 804-399-3580', 'bakery-helpers'),
          'title'   => esc_html__('Notifycation Content', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_notify_enable', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_header_search_enable',
          'type'    => 'switcher',
          'default' => false,
          'title'   => esc_html__('Enable Search', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_header_top_enable', '==', 'true' ),
        ),

      )
    ),
    // sub section 3
    array(
      'name'     => 'header_sub_section_3',
      'title'    => esc_html__('Panel heading', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'id'      => 'noubakery_heading_display',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable section', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Header banner', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_heading_display', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_panel_background',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/hero/01.jpg'),
          'title'   => esc_html__('Upload banner', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_heading_display', '==', 'true' ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Panel heading', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_heading_display', '==', 'true' ),
        ),

        array(
          'id'      => 'noubakery_title_enable',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable title', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_heading_display', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_panel_breadcrumb',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable breadcrumb', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_heading_display', '==', 'true' ),
        ),
      )
    ),

    // sub section 3
    array(
      'name'     => 'header_sub_section_4',
      'title'    => esc_html__('Menu', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Menu fixed', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_menu_fixed_desktop',
          'type'    => 'switcher',
          'title'   => esc_html__('On/Off desktop menu fixed.', 'bakery-helpers'),
          'default' => true
        ),
      )
    ),


  ),
);


$options[]   = array(
  'name'        => 'footer',
  'title'       => esc_html__('Footer', 'bakery-helpers'),
  'icon'        => 'fa fa-copyright',
  'sections' => array(
    
    // sub section 1
    array(
      'name'     => 'footer_sub_section_1',
      'title'    => esc_html__('About Us', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'id'      => 'noubakery_section_footer_top',
          'type'    => 'switcher',
          'default' => false,
          'title'   => esc_html__('Enable this section', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('About Us', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_footer_about',
          'type'    => 'wysiwyg',
          'default' => wp_kses_post(sprintf('<h4>%s</h4><p>%s</p><p class="text-uppercase ps-subscribe__highlight">%s</p>', esc_html__('ABOUT US', 'bakery-helpers'), esc_html__('Te pri oblique ullamcorper, magna persequeris has eu. Mei prompta dolores examad debet suavitate. Pri te vocibus electram. Eu eleifend rationibus vis, at.', 'bakery-helpers'), esc_html__('240 CENTRAL PARK, LONDON, OR 10019', 'bakery-helpers'))),
          'title'   => esc_html__('Content', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Subscribe', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_subscribe_heading',
          'type'    => 'text',
          'default' => esc_html__('SUBSCRIBE EMAIL', 'bakery-helpers'),
          'title'   => esc_html__('Heading', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_subscribe_desc',
          'type'    => 'textarea',
          'default' => esc_html__('Te pri oblique ullamcorper, magna persequeris has eu. Mei prompta dolores examad debet suavitate. Pri te vocibus electram. Eu eleifend rationibus vis, at.', 'bakery-helpers'),
          'title'   => esc_html__('Description', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_subscribe_btn_text',
          'type'    => 'text',
          'default' => esc_html__('Subscribe', 'bakery-helpers'),
          'title'   => esc_html__('Button text', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_subscribe_placeholder',
          'type'    => 'text',
          'default' => esc_html__('Type your email...', 'bakery-helpers'),
          'title'   => esc_html__('Placeholder text', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_subscribe_logo',
          'type'    => 'upload',
          'default' => esc_url(NOUBAKERY_IMG.'/logo-1.png'),
          'title'   => esc_html__('Upload logo', 'bakery-helpers'),
          'dependency'   => array( 'noubakery_section_footer_top', '==', 'true' ),
        ),
      )
    ),
    // sub section 1
    array(
      'name'     => 'footer_sub_section_2',
      'title'    => esc_html__('Widget', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Widget', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_widget_footer_col',
          'type'    => 'number',
          'attributes' => array(
            'min' => '1',
            'max' => '12',
            'step' => '1',
          ),
          'default' => 4,
          'title'   => esc_html__('Number of Footer Columns', 'bakery-helpers'),
          'desc'    => esc_html__('Select the number of columns to display in the footer.', 'bakery-helpers'),
          'validate' => 'numeric',
        ),
      )
    ),
    // sub section 2
    array(
      'name'     => 'footer_sub_section_3',
      'title'    => esc_html__('Copyright', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Copyright', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_copyright',
          'type'    => 'wysiwyg',
          'default' => wp_kses_post(sprintf('<p>%s<a href="#"> %s</a>.</p>', esc_html__('&copy; 2017 Design by', 'bakery-helpers'), esc_html__('Alena Studio', 'bakery-helpers'))),
          'title'   => esc_html__('Copyright text', 'bakery-helpers'),
        ),
      )
    ),
    
  ),
);


$options[]   = array(
  'name'        => 'blog',
  'title'       => esc_html__('Blog', 'bakery-helpers'),
  'icon'        => 'fa fa-leaf',
  'sections' => array(
    
    // sub section 1
    array(
      'name'     => 'blog_sub_section_1',
      'title'    => esc_html__('Blog archive', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Sticky post', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_sticky_icon',
          'type'    => 'icon',
          'title'   => esc_html__('Sticky post icon', 'bakery-helpers'),
          'default' => 'fa fa-paperclip',
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Blog like', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_post_like',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable like button', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_love_icon',
          'type'    => 'icon',
          'title'   => esc_html__('Like icon', 'bakery-helpers'),
          'default' => 'fa fa-heart-o',
          'dependency'   => array( 'noubakery_post_like', '==', 'true' ),
        ),
        array(
          'id'      => 'noubakery_loved_icon',
          'type'    => 'icon',
          'title'   => esc_html__('Liked icon', 'bakery-helpers'),
          'default' => 'fa fa-heart',
          'dependency'   => array( 'noubakery_post_like', '==', 'true' ),
        ),
      )
    ),
    // sub section 1
    array(
      'name'     => 'blog_sub_section_2',
      'title'    => esc_html__('Single post', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Single Post Thumbnail', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_single_thumbnail',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable thumbnail', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Share Post', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_single_share_facebook',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Share post by Facebook', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_single_share_twitter',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Share post by Twitter', 'bakery-helpers'),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Tags', 'bakery-helpers'),
        ),
        array(
          'id'      => 'noubakery_single_tags',
          'type'    => 'switcher',
          'default' => true,
          'title'   => esc_html__('Enable tags', 'bakery-helpers'),
          'desc'    => esc_html__('On/Off this section bottom', 'bakery-helpers'),
        ),
      )
    ),
    // sub section 2
    array(
      'name'     => 'blog_sub_section_3',
      'title'    => esc_html__('Sidebar', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Blog sidebar', 'bakery-helpers'),
        ),
        array(
          'id'        => 'noubakery_blog_sidebar',
          'type'      => 'select',
          'title'     => esc_html__('Blog sidebar', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            'right' => esc_html__('Right', 'bakery-helpers'),
            'left' => esc_html__('Left', 'bakery-helpers'),
            'hide' => esc_html__('No sidebar', 'bakery-helpers'),
          ),
          'default' => NOUBAKERY_BLOG_DEFAULT_SIDEBAR
        ),
      )
    ),
    
  ),
);


$options[]      = array(
  'name'        => 'contact',
  'title'       => esc_html__('Contact', 'bakery-helpers'),
  'icon'        => 'fa fa-envelope-o',

  // begin: fields
  'fields'      => array(

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Contact information', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_address',
      'type'    => 'text',
      'default' => esc_html__('New York, NY', 'bakery-helpers'),
      'title'   => esc_html__('Address', 'bakery-helpers'),
    ),

    array(
      'type'    => 'subheading',
      'content' => esc_html__('Google map', 'bakery-helpers'),
    ),
    array(
      'id'       => 'noubakery_contact_type',
      'type'     => 'select',
      'title'    => esc_html__('Get map from', 'bakery-helpers'),
      'options'  => array(
        'address'  => esc_html__('Address', 'bakery-helpers'),
        'coordinates'  => esc_html__('Coordinates', 'bakery-helpers'),
      ),
      'default'  => 'address',
    ),
    array(
      'id'      => 'noubakery_contact_api',
      'type'    => 'text',
      'title'   => esc_html__('API key', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_iframe',
      'type'    => 'textarea',
      'title'   => esc_html__('Iframe', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_lat',
      'type'    => 'text',
      'dependency'   => array( 'noubakery_contact_type', '==', 'coordinates' ),
      'title'   => esc_html__('Latitude', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_lng',
      'type'    => 'text',
      'dependency'   => array( 'noubakery_contact_type', '==', 'coordinates' ),
      'title'   => esc_html__('Longitude', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_map_zoom',
      'type'    => 'number',
      'default' => esc_html__('17', 'bakery-helpers'),
      'title'   => esc_html__('Map zoom', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_contact_map_marker',
      'type'    => 'upload',
      'title'   => esc_html__('Map marker', 'bakery-helpers'),
      'default' => esc_url(NOUBAKERY_IMG.'/marker.png')
    ),
    

  ), // end: fields
);


$options[]      = array(
  'name'        => 'popup',
  'title'       => esc_html__('Popup', 'bakery-helpers'),
  'icon'        => 'fa fa-bomb',

  // begin: fields
  'fields'      => array(

    array(
      'id'      => 'noubakery_popup_enable',
      'type'    => 'switcher',
      'default' => true,
      'title'   => esc_html__('Enable popup', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_popup_img',
      'type'    => 'upload',
      'title'   => esc_html__('Banner', 'bakery-helpers'),
      'dependency'   => array( 'noubakery_popup_enable', '==', 'true' ),
    ),
    
    array(
      'id'    => 'noubakery_subscribe_delay',
      'type'  => 'text',
      'title' => esc_html__('Time delay', 'bakery-helpers'),
      'default' => esc_html__('10000', 'bakery-helpers'),
      'desc' => esc_html__('Time delay uses milliseconds so 10000 is 10 seconds.', 'bakery-helpers'),
    ),
    array(
      'id'    => 'noubakery_subscribe_btn',
      'type'  => 'text',
      'title' => esc_html__('Button text', 'bakery-helpers'),
      'default' => esc_html__('Subscribe', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_popup_content',
      'type'    => 'wysiwyg',
      'default' => wp_kses_post(sprintf('<h3>%s</h3><p>%s <span> %s </span> %s</p>', esc_html__('STAY UP-TO-DATE  WITH OUR NEWLETTER', 'bakery-helpers'), esc_html__('Follow us & get', 'bakery-helpers'), esc_html__('20% OFF', 'bakery-helpers'), esc_html__('coupon for first purchase !!!!!', 'bakery-helpers'))),
      'title'   => esc_html__('Content', 'bakery-helpers'),
      'dependency'   => array( 'noubakery_popup_enable', '==', 'true' ),
    ),

  ), // end: fields
);

$options[]      = array(
  'name'        => '404',
  'title'       => esc_html__('404 Page', 'bakery-helpers'),
  'icon'        => 'fa fa-exclamation',

  // begin: fields
  'fields'      => array(

    array(
      'id'      => 'noubakery_404_bg',
      'type'    => 'upload',
      'default' => esc_url(NOUBAKERY_IMG.'/background/img-404.jpg'),
      'title'   => esc_html__('404 background', 'bakery-helpers'),
    ),
    array(
      'id'      => 'noubakery_404_content',
      'type'    => 'wysiwyg',
      'default' => wp_kses_post(sprintf('<h1>%s</h1><h3>%s</h3><p>%s</p>', esc_html__('404', 'bakery-helpers'), esc_html__('PAGES NOT FOUND', 'bakery-helpers'), esc_html__('OOPS ! Seems you\'re go out range our Bakery ! :(', 'bakery-helpers'))),
      'title'   => esc_html__('404 Content', 'bakery-helpers'),
    ),

  ), // end: fields
);


if(class_exists('Woocommerce')){

  $options[]   = array(
    'name'        => 'woocommerce',
    'title'       => esc_html__('Woocommerce', 'bakery-helpers'),
    'icon'        => 'fa fa-shopping-cart',
    'sections' => array(
      
      array(
        'name'     => 'woo_sub_section_general',
        'title'    => esc_html__('General', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Shop view style', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_style',
            'type'    => 'select',
            'default' => 'gird',
            'title'   => esc_html__('Shop layout', 'bakery-helpers'),
            'options'    => array(
              'list'    => esc_html__('Shop layout list', 'bakery-helpers'),
              'gird'     => esc_html__('Shop layout grid', 'bakery-helpers'),
            ),
            'class'      => 'chosen',
          ),
          array(
            'id'        => 'noubakery_product_per_page',
            'type'      => 'select',
            'title'     => esc_html__('Products per page', 'bakery-helpers'),
            'class'     => 'chosen',
            'options'   => array(
              '9' => '9',
              '12' => '12',
              '15' => '15',
              '18' => '18',
              '21' => '21',
              'custom' => esc_html__('Custom', 'bakery-helpers'),
            ),
            'default' => '9'
          ),
          array(
            'id'      => 'noubakery_product_per_page_custom',
            'type'    => 'number',
            'default' => '9',
            'title'   => esc_html__('Products per page custom', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_per_page', '==', 'custom' ),
          ),
          array(
            'id'      => 'noubakery_shop_grid_col',
            'type'    => 'select',
            'default' => 3,
            'options'    => array(
              '2'    => '2',
              '3'     => '3',
              '4'     => '4',
            ),
            'class'      => 'chosen',
            'title'   => esc_html__('Grid column', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_shop_style', '==', 'gird' ),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Mini cart', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_mini_cart_enable',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable mini cart header', 'bakery-helpers'),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Add to cart text', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_add_to_cart_external_text',
            'type'    => 'text',
            'default' => esc_html__('Buy product', 'bakery-helpers'),
            'title'   => esc_html__('Add to cart text for external', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_add_to_cart_grouped_text',
            'type'    => 'text',
            'default' => esc_html__('View products', 'bakery-helpers'),
            'title'   => esc_html__('Add to cart text for grouped', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_add_to_cart_variable_text',
            'type'    => 'text',
            'default' => esc_html__('Select options', 'bakery-helpers'),
            'title'   => esc_html__('Add to cart text for variable', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_add_to_cart_text',
            'type'    => 'text',
            'default' => esc_html__('Add to cart', 'bakery-helpers'),
            'title'   => esc_html__('Add to cart text for default', 'bakery-helpers'),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Sale flash text', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_saleflash_new_text',
            'type'    => 'text',
            'default' => esc_html__('New', 'bakery-helpers'),
            'title'   => esc_html__('New button text', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_saleflash_hot_text',
            'type'    => 'text',
            'default' => esc_html__('Hot', 'bakery-helpers'),
            'title'   => esc_html__('Hot button text', 'bakery-helpers'),
          ),
        )
      ),
      // sub section 1
      array(
        'name'     => 'woo_sub_section_1',
        'title'    => esc_html__('Products archive', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Shop banner', 'bakery-helpers'),
          ),
          array(
            'id'              => 'noubakery_shop_banner',
            'type'            => 'group',
            'button_title'    => esc_html__('Add banners', 'bakery-helpers'),
            'accordion_title' => esc_html__('Shop banner', 'bakery-helpers'),
            'fields'          => array(
              array(
                'id'    => 'img',
                'type'  => 'upload',
                'title' => esc_html__('Upload banner', 'bakery-helpers'),
              ),
              array(
                'id'    => 'url',
                'type'  => 'text',
                'title' => esc_html__('Banner URL', 'bakery-helpers'),
              ),
              array(
                'id'    => 'col',
                'type'  => 'number',
                'default' => 6,
                'title' => esc_html__('Banner column', 'bakery-helpers'),
                'desc'  => esc_html__('Used bootstrap column', 'bakery-helpers'),
              ),
            ),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Shop button', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_enable_cart',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable add to cart button', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_enable_view',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable quick view button', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_enable_wishlist',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable wishlist button', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_wishlist_page_id',
            'type'    => 'select',
            'class'     => 'chosen',
            'title'   => esc_html__('Select a page wishlist', 'bakery-helpers'),
            'options' => 'pages',
            'dependency'   => array( 'noubakery_shop_enable_wishlist', '==', 'true' ),
          ),
          array(
            'id'      => 'noubakery_shop_enable_compare',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable compare button', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_compare_page_id',
            'type'    => 'select',
            'class'     => 'chosen',
            'title'   => esc_html__('Select a page compare', 'bakery-helpers'),
            'options' => 'pages',
            'dependency'   => array( 'noubakery_shop_enable_compare', '==', 'true' ),
          ),
          
        )
      ),
      // sub section 1
      array(
        'name'     => 'woo_sub_section_2',
        'title'    => esc_html__('Single product', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Product layout', 'bakery-helpers'),
          ),
          array(
            'id'        => 'noubakery_product_layout',
            'type'      => 'select',
            'title'     => esc_html__('Select a layout', 'bakery-helpers'),
            'class'     => 'chosen',
            'options'   => array(
              '1' => esc_html__('Default', 'bakery-helpers'),
              '2' => esc_html__('With offer form', 'bakery-helpers'),
            ),
          ),

          array(
            'id'      => 'noubakery_shop_enable_single_lightbox',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable lightbox gallery', 'bakery-helpers'),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Related products', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_layout', '==', '1' ),
          ),
          array(
            'id'        => 'noubakery_product_related_type',
            'type'      => 'select',
            'title'     => esc_html__('Related type', 'bakery-helpers'),
            'class'     => 'chosen',
            'options'   => array(
              'related' => esc_html__('Related products', 'bakery-helpers'),
              'bestsale' => esc_html__('Best seller', 'bakery-helpers'),
              'featured' => esc_html__('Featured products', 'bakery-helpers'),
              'sale' => esc_html__('On sale', 'bakery-helpers'),
            ),
            'dependency'   => array( 'noubakery_product_layout', '==', '1' ),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Description', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_shop_related_desc',
            'type'    => 'text',
            'title'   => esc_html__('Description', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_layout', '==', '1' ),
          ),
          array(
            'id'      => 'noubakery_shop_related_title',
            'type'    => 'text',
            'title'   => esc_html__('Title', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_layout', '==', '1' ),
          ),
          array(
            'id'      => 'noubakery_shop_form_desc',
            'type'    => 'text',
            'title'   => esc_html__('Description', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_layout', '==', '2' ),
          ),
          array(
            'id'      => 'noubakery_shop_form_title',
            'type'    => 'text',
            'title'   => esc_html__('Title', 'bakery-helpers'),
            'dependency'   => array( 'noubakery_product_layout', '==', '2' ),
          ),
          array(
            'id'      => 'noubakery_date_format',
            'type'    => 'text',
            'default' => esc_html__('MM/DD/YYYY hh:mm', 'bakery-helpers'),
            'title'   => esc_html__('Date time format', 'bakery-helpers'),
            'after'   => wp_kses_post(sprintf('<p>%s <a href="http://momentjs.com/docs/#/displaying/format/" target="_blank">%s</a></p>', esc_html__('Date time format from', 'bakery-helpers'), esc_html__('here', 'bakery-helpers'))),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Meta', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_meta_enable_sku',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable SKU', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_meta_enable_stock',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable stock', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_meta_enable_tags',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable Tags', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_meta_enable_category',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable Categories', 'bakery-helpers'),
          ),
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Share', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_share_title',
            'type'    => 'text',
            'default' => esc_html__('Share with', 'bakery-helpers'),
            'title'   => esc_html__('Share text', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_share_enable_fb',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable facebook', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_share_enable_google',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable Google', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_product_share_enable_twitter',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable Twitter', 'bakery-helpers'),
          ),
          
        )
      ),
      // sub section 3
      array(
        'name'     => 'woo_sub_section_3',
        'title'    => esc_html__('Sidebar', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Shop sidebar', 'bakery-helpers'),
          ),
          array(
            'id'        => 'noubakery_shop_sidebar',
            'type'      => 'select',
            'title'     => esc_html__('Sidebar', 'bakery-helpers'),
            'class'     => 'chosen',
            'options'   => array(
              'right' => esc_html__('Right', 'bakery-helpers'),
              'left' => esc_html__('Left', 'bakery-helpers'),
              'hide' => esc_html__('No sidebar', 'bakery-helpers'),
            ),
            'default' => NOUBAKERY_BLOG_DEFAULT_SIDEBAR
          ),
        )
      ),
      // sub section 3
      array(
        'name'     => 'woo_sub_section_4',
        'title'    => esc_html__('Price', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Product price', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_price_enable',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable price', 'bakery-helpers'),
          ),
        )
      ),
      // sub section 3
      array(
        'name'     => 'woo_sub_section_5',
        'title'    => esc_html__('Mobile bottom', 'bakery-helpers'),
        'icon'     => 'fa fa-minus',
        'fields'   => array(
          array(
            'type'    => 'subheading',
            'content' => esc_html__('Menu bottom mobile', 'bakery-helpers'),
          ),
          array(
            'id'      => 'noubakery_menu_bottom_mobile_enable',
            'type'    => 'switcher',
            'default' => true,
            'title'   => esc_html__('Enable menu bottom mobile', 'bakery-helpers'),
          ),
        )
      ),
      
    ),
  );

}

$options[]   = array(
  'name'     => 'custom_css',
  'title'    => esc_html__('Styling', 'bakery-helpers'),
  'icon'     => 'fa fa-magic',
  'sections' => array(

    // sub section 2
    array(
      'name'     => 'sub_color',
      'title'    => esc_html__('Change color', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Main color', 'bakery-helpers'),
        ),
        array(
          'id'    => 'noubakery_main_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Main color', 'bakery-helpers'),
          'desc'  => esc_html__('Controls several items, ex: link hovers, highlights, and more.', 'bakery-helpers'),
          'default' => '#ee7560'
        ),
        array(
          'id'    => 'noubakery_main_hover_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Hover color', 'bakery-helpers'),
          'default' => ''
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Sticky menu color', 'bakery-helpers'),
        ),
        array(
          'id'    => 'noubakery_stickymenu_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Menu sticky background color', 'bakery-helpers'),
          'default' => '#000000'
        ),
       
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Footer color', 'bakery-helpers'),
        ),
        array(
          'id'    => 'noubakery_footer_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Footer background color', 'bakery-helpers'),
          'default' => '#f9f9f9'
        ),
        array(
          'id'    => 'noubakery_footer_boder_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Footer border color', 'bakery-helpers'),
          'default' => '#282c2f'
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Price & Rating', 'bakery-helpers'),
        ),
        array(
          'id'    => 'noubakery_price_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Price color', 'bakery-helpers'),
          'default' => '#000000'
        ),
        array(
          'id'    => 'noubakery_rating_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Rating color', 'bakery-helpers'),
          'default' => '#ffb727'
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Button', 'bakery-helpers'),
        ),
        array(
          'id'    => 'noubakery_btn_color',
          'type'  => 'color_picker',
          'title' => esc_html__('Button color', 'bakery-helpers'),
          'default' => '#ee7560'
        ),

      )
    ),

    // sub section 1
    array(
      'name'     => 'sub_fonts',
      'title'    => esc_html__('Custom Fonts', 'bakery-helpers'),
      'icon'     => 'fa fa-minus',
      'fields'   => array(

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Body fonts', 'bakery-helpers'),
        ),
        array(
          'id'        => 'noubakery_font_body_type',
          'type'      => 'select',
          'title'     => esc_html__('Body custom font', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '1' => esc_html__('Google fonts', 'bakery-helpers'),
            '2' => esc_html__('Upload', 'bakery-helpers'),
          ),
          'default' => '1'
        ),
        array(
          'id'            => 'noubakery_font_body_upload',
          'type'          => 'upload',
          'title'         => esc_html__('Body custom font (.ttf)', 'bakery-helpers'),
          'settings'      => array(
           'upload_type'  => 'ttf',
           'button_title' => esc_html__('Upload font', 'bakery-helpers'),
           'frame_title'  => esc_html__('Select an font', 'bakery-helpers'),
           'insert_title' => esc_html__('Use this font', 'bakery-helpers'),
          ),
          'dependency'    => array( 'noubakery_font_body_type', '==', '2' ),
          
        ),
        array(
          'id'        => 'noubakery_font_body',
          'type'      => 'typography',
          'title'     => esc_html__('Body', 'bakery-helpers'),
          'desc'      => esc_html__('Select a font family for body text.', 'bakery-helpers'),
          'dependency'    => array( 'noubakery_font_body_type', '==', '1' ),
        ),

        array(
          'type'    => 'subheading',
          'content' => esc_html__('Heading fonts', 'bakery-helpers'),
        ),
        array(
          'id'        => 'noubakery_font_heading_type',
          'type'      => 'select',
          'title'     => esc_html__('Heading custom font', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '1' => esc_html__('Google fonts', 'bakery-helpers'),
            '2' => esc_html__('Upload', 'bakery-helpers'),
          ),
          'default' => '1'
        ),
        array(
          'id'            => 'noubakery_font_heading_upload',
          'type'          => 'upload',
          'title'         => esc_html__('Heading custom font (.ttf)', 'bakery-helpers'),
          'settings'      => array(
           'upload_type'  => 'ttf',
           'button_title' => esc_html__('Upload font', 'bakery-helpers'),
           'frame_title'  => esc_html__('Select an font', 'bakery-helpers'),
           'insert_title' => esc_html__('Use this font', 'bakery-helpers'),
          ),
          'dependency'    => array( 'noubakery_font_heading_type', '==', '2' ),
          
        ),
        array(
          'id'        => 'noubakery_font_heading',
          'type'      => 'typography',
          'title'     => esc_html__('Heading', 'bakery-helpers'),
          'desc'      => esc_html__('Heading font (h1, h2, h3, h4, h5, h6).', 'bakery-helpers'),
          'dependency'    => array( 'noubakery_font_heading_type', '==', '1' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Menu fonts', 'bakery-helpers'),
        ),
        array(
          'id'        => 'noubakery_font_menu_type',
          'type'      => 'select',
          'title'     => esc_html__('Menu custom font', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '1' => esc_html__('Google fonts', 'bakery-helpers'),
            '2' => esc_html__('Upload', 'bakery-helpers'),
          ),
          'default' => '1'
        ),
        array(
          'id'            => 'noubakery_font_menu_upload',
          'type'          => 'upload',
          'title'         => esc_html__('Menu custom font (.ttf)', 'bakery-helpers'),
          'settings'      => array(
           'upload_type'  => 'ttf',
           'button_title' => esc_html__('Upload font', 'bakery-helpers'),
           'frame_title'  => esc_html__('Select an font', 'bakery-helpers'),
           'insert_title' => esc_html__('Use this font', 'bakery-helpers'),
          ),
          'dependency'    => array( 'noubakery_font_menu_type', '==', '2' ),
          
        ),
        array(
          'id'        => 'noubakery_font_menu',
          'type'      => 'typography',
          'title'     => esc_html__('Menu', 'bakery-helpers'),
          'desc'      => esc_html__('Select a font family for navigation.', 'bakery-helpers'),
          'dependency'    => array( 'noubakery_font_menu_type', '==', '1' ),
        ),
        array(
          'type'    => 'subheading',
          'content' => esc_html__('Button fonts', 'bakery-helpers'),
        ),
        array(
          'id'        => 'noubakery_font_button_type',
          'type'      => 'select',
          'title'     => esc_html__('Button custom font', 'bakery-helpers'),
          'class'     => 'chosen',
          'options'   => array(
            '1' => esc_html__('Google fonts', 'bakery-helpers'),
            '2' => esc_html__('Upload', 'bakery-helpers'),
          ),
          'default' => '1'
        ),
        array(
          'id'            => 'noubakery_font_button_upload',
          'type'          => 'upload',
          'title'         => esc_html__('Button custom font (.ttf)', 'bakery-helpers'),
          'settings'      => array(
           'upload_type'  => 'ttf',
           'button_title' => esc_html__('Upload font', 'bakery-helpers'),
           'frame_title'  => esc_html__('Select an font', 'bakery-helpers'),
           'insert_title' => esc_html__('Use this font', 'bakery-helpers'),
          ),
          'dependency'    => array( 'noubakery_font_button_type', '==', '2' ),
          
        ),
        array(
          'id'        => 'noubakery_font_button',
          'type'      => 'typography',
          'title'     => esc_html__('Button', 'bakery-helpers'),
          'desc'      => esc_html__('Select a font family for button.', 'bakery-helpers'),
          'dependency'    => array( 'noubakery_font_button_type', '==', '1' ),
        ),

      )
    ),

  ),
);

Noubakery_CSFramework::instance( $settings, $options );
