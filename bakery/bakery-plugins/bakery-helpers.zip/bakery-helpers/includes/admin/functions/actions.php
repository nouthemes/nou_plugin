<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * Get icons from admin ajax
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_cs_get_icons' ) ) {
  function noubakery_cs_get_icons() {

    do_action( 'noubakery_noubakery_cs_add_icons_before' );

    $jsons = glob( NOUBAKERY_CS_DIR . '/fields/icon/*.json' );

    if( ! empty( $jsons ) ) {

      foreach ( $jsons as $path ) {

        $object = noubakery_cs_get_icon_fonts( 'fields/icon/'. basename( $path ) );

        if( is_object( $object ) ) {

          echo ( count( $jsons ) >= 2 ) ? '<h4 class="cs-icon-title">'. esc_html($object->name) .'</h4>' : '';

          foreach ( $object->icons as $icon ) {
            echo '<a class="cs-icon-tooltip" data-icon="'. esc_attr($icon) .'" data-title="'. esc_attr($icon) .'"><span class="cs-icon cs-selector"><i class="'. esc_attr($icon) .'"></i></span></a>';
          }

        } else {
          echo '<h4 class="cs-icon-title">'. esc_html__( 'Error! Can not load json file.', 'bakery-helpers' ) .'</h4>';
        }

      }

    }

    do_action( 'noubakery_cs_add_icons' );
    do_action( 'noubakery_cs_add_icons_after' );

    die();
  }
  add_action( 'wp_ajax_cs-get-icons', 'noubakery_cs_get_icons' );
}

/**
 *
 * Export options
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_cs_export_options' ) ) {
  function noubakery_cs_export_options() {

  }
  add_action( 'wp_ajax_cs-export-options', 'noubakery_cs_export_options' );
}

/**
 *
 * Set icons for wp dialog
 *
 * @since 1.0.0
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_cs_set_icons' ) ) {
  function noubakery_cs_set_icons() {

    echo '<div id="cs-icon-dialog" class="cs-dialog" title="'. esc_html__( 'Add Icon', 'bakery-helpers' ) .'">';
    echo '<div class="cs-dialog-header cs-text-center"><input type="text" placeholder="'. esc_html__( 'Search a Icon...', 'bakery-helpers' ) .'" class="cs-icon-search" /></div>';
    echo '<div class="cs-dialog-load"><div class="cs-icon-loading">'. esc_html__( 'Loading...', 'bakery-helpers' ) .'</div></div>';
    echo '</div>';

  }
  add_action( 'admin_footer', 'noubakery_cs_set_icons' );
  add_action( 'customize_controls_print_footer_scripts', 'noubakery_cs_set_icons' );
}
