<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * A fallback for get term meta
 * noubakery_get_term_meta added since WP 4.4
 *
 * @since 1.0.2
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_get_term_meta' ) ) {
  function noubakery_get_term_meta( $term_id, $key = '', $single = false ) {

    $terms = get_option( 'cs_term_'. $key );

    return ( ! empty( $terms[$term_id] ) ) ? $terms[$term_id] : false;

  }
}

/**
 *
 * A fallback for add term meta
 * noubakery_add_term_meta added since WP 4.4
 *
 * @since 1.0.2
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_add_term_meta' ) ) {
  function noubakery_add_term_meta( $term_id, $meta_key = '', $meta_value = '', $unique = false ) {

    return noubakery_update_term_meta( $term_id, $meta_key, $meta_value, $unique );

  }
}

/**
 *
 * A fallback for update term meta
 * noubakery_update_term_meta added since WP 4.4
 *
 * @since 1.0.2
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_update_term_meta' ) ) {
  function noubakery_update_term_meta( $term_id, $meta_key, $meta_value, $prev_value = '' ) {

    if ( ! empty( $term_id ) || ! empty( $meta_key ) || ! empty( $meta_value ) ) {

      $terms = get_option( 'cs_term_'. $meta_key );

      $terms[$term_id] = $meta_value;

      update_option( 'cs_term_'. $meta_key, $terms );

    }

  }
}

/**
 *
 * A fallback for delete term meta
 * noubakery_delete_term_meta added since WP 4.4
 *
 * @since 1.0.2
 * @version 1.0.0
 *
 */
if( ! function_exists( 'noubakery_delete_term_meta' ) ) {
  function noubakery_delete_term_meta( $term_id, $meta_key, $meta_value = '', $delete_all = false ) {

    if ( ! empty( $term_id ) || ! empty( $meta_key ) ) {

      $terms = get_option( 'cs_term_'. $meta_key );

      unset( $terms[$term_id] );

      update_option( 'cs_term_'. $meta_key, $terms );

    }

  }
}
