<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.
/**
 *
 * ------------------------------------------------------------------------------------------------
 *
 * Codestar Framework
 * A Lightweight and easy-to-use WordPress Options Framework
 *
 * Plugin Name: Codestar Framework
 * Plugin URI: http://codestarframework.com/
 * Author: Codestar
 * Author URI: http://codestarlive.com/
 * Version: 1.0.1
 * Description: A Lightweight and easy-to-use WordPress Options Framework
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain: cs-framework
 *
 * ------------------------------------------------------------------------------------------------
 *
 * Copyright 2015 Codestar <info@codestarlive.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * ------------------------------------------------------------------------------------------------
 *
 */

// ------------------------------------------------------------------------------------------------
require_once plugin_dir_path( __FILE__ ) .'/cs-framework-path.php';
// ------------------------------------------------------------------------------------------------

if( ! function_exists( 'noubakery_cs_framework_init' ) && ! class_exists( 'Noubakery_CSFramework' ) ) {
  function noubakery_cs_framework_init() {

    // active modules
    defined( 'NOUBAKERY_CS_ACTIVE_FRAMEWORK' )  or  define( 'NOUBAKERY_CS_ACTIVE_FRAMEWORK',  true );
    defined( 'NOUBAKERY_CS_ACTIVE_METABOX'   )  or  define( 'NOUBAKERY_CS_ACTIVE_METABOX',    true );
    defined( 'NOUBAKERY_CS_ACTIVE_TAXONOMY'   ) or  define( 'NOUBAKERY_CS_ACTIVE_TAXONOMY',   true );
    defined( 'NOUBAKERY_CS_ACTIVE_SHORTCODE' )  or  define( 'NOUBAKERY_CS_ACTIVE_SHORTCODE',  false );
    defined( 'NOUBAKERY_CS_ACTIVE_CUSTOMIZE' )  or  define( 'NOUBAKERY_CS_ACTIVE_CUSTOMIZE',  true );

    // helpers
    noubakery_cs_locate_template( 'functions/deprecated.php'     );
    noubakery_cs_locate_template( 'functions/fallback.php'       );
    noubakery_cs_locate_template( 'functions/helpers.php'        );
    noubakery_cs_locate_template( 'functions/actions.php'        );
    noubakery_cs_locate_template( 'functions/enqueue.php'        );
    noubakery_cs_locate_template( 'functions/sanitize.php'       );
    noubakery_cs_locate_template( 'functions/validate.php'       );

    // classes
    noubakery_cs_locate_template( 'classes/abstract.class.php'   );
    noubakery_cs_locate_template( 'classes/options.class.php'    );
    noubakery_cs_locate_template( 'classes/framework.class.php'  );
    noubakery_cs_locate_template( 'classes/metabox.class.php'    );
    noubakery_cs_locate_template( 'classes/taxonomy.class.php'   );
    noubakery_cs_locate_template( 'classes/shortcode.class.php'  );
    noubakery_cs_locate_template( 'classes/customize.class.php'  );

    // configs
    noubakery_cs_locate_template( 'config/framework.config.php'  );
    noubakery_cs_locate_template( 'config/metabox.config.php'    );
    noubakery_cs_locate_template( 'config/taxonomy.config.php'   );
    noubakery_cs_locate_template( 'config/shortcode.config.php'  );
    noubakery_cs_locate_template( 'config/customize.config.php'  );

  }
  add_action( 'init', 'noubakery_cs_framework_init', 10 );
}
