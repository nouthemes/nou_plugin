<?php 
/**
* 
*/
class Bakery_Helpers_Shortcodes
{
	
	/**
	 * Init shortcodes.
	 */
	public static function init() {
		$shortcodes = array(
			'our_baker'                    => 'Bakery_Helpers_Shortcode_Ourbaker',
			'our_record'                   => 'Bakery_Helpers_Shortcode_Ourrecord',
			'our_record_item'              => 'Bakery_Helpers_Shortcode_Ourrecorditem',
			'our_team'                     => 'Bakery_Helpers_Shortcode_Ourteam',
			'our_team_item'                => 'Bakery_Helpers_Shortcode_Ourteamitem',
			'brand'                    	   => 'Bakery_Helpers_Shortcode_Brand',
			'brand_item'                   => 'Bakery_Helpers_Shortcode_Branditem',
			'contact_form'                 => 'Bakery_Helpers_Shortcode_Contactform',
			'section_title' 			   => 'Bakery_Helpers_Shortcode_Sectiontitle',
			'product' 					   => 'Bakery_Helpers_Shortcode_Product',
			'products' 					   => 'Bakery_Helpers_Shortcode_Products',
			'product_sale' 				   => 'Bakery_Helpers_Shortcode_Product_Sale',
			'product_special' 			   => 'Bakery_Helpers_Shortcode_Product_Special',
			'testimonial' 				   => 'Bakery_Helpers_Shortcode_Testimonial',
			'testimonial_item' 			   => 'Bakery_Helpers_Shortcode_Testimonial_Item',
			'post' 			   			   => 'Bakery_Helpers_Shortcode_Blog',
			'quote' 			   		   => 'Bakery_Helpers_Shortcode_Quote',
			'quote_item' 			   	   => 'Bakery_Helpers_Shortcode_Quote_Item',
		);

		if(!empty($shortcodes)):
			foreach ( $shortcodes as $shortcode => $function ) {
				add_shortcode( apply_filters( "noubakery_{$shortcode}_shortcode_tag", 'noubakery_'.$shortcode ), array($function, 'shortcode') );
				add_action( 'vc_before_init', array($function, 'map') );
			}

			add_action( 'vc_before_init', array(__CLASS__, 'add_params') );
		endif;
	}

	public static function add_params(){
		$attribute_vc_row = array(
		    'type' => 'checkbox',
		    'heading' => esc_html__( "Row with container", "bakery-helpers" ),
		    'param_name' => 'with_container',
		    'value' => '',
		);
		vc_add_param( 'vc_row', $attribute_vc_row );
	}

	/**
	 * get-attributes-of-nested-shortcodes
	 *
	 * @param string $str
	 * @param array $atts
	 *
	 * @return string
	 * @link http://wordpress.stackexchange.com/questions/121562/get-attributes-of-nested-shortcodes
	 */
	public static function get_attributes_nested_shortcodes( $str, $att = null ) {
		$res = array();
		$reg = get_shortcode_regex();
		preg_match_all( '~' . $reg . '~', $str, $matches );
		$i = 0;
		foreach ( $matches[2] as $key => $name ) {
			$parsed = shortcode_parse_atts( $matches[3][ $key ] );
			$parsed = is_array( $parsed ) ? $parsed : array();

			$res[ $i ]              = array_key_exists( $att, $parsed ) ? $parsed[ $att ] : $parsed;
			$res[ $i ]['name']      = $name;
			$res[ $i ]['shortcode'] = $matches[0][ $key ];
			$i                      = $i + 1;
		}

		return $res;
	}

}
?>