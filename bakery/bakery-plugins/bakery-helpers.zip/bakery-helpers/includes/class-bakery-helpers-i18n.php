<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       http://nouthemes.com
 * @since      1.0.0
 *
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/includes
 * @author     nouthemes <nouthemes@gmail.com>
 */
class Bakery_Helpers_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'bakery-helpers',
			false,
			'bakery-helpers/languages/'
		);
	}



}
