<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Branditem
{
	
	/**
	 * Brand slider item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts ) {
		$atts = shortcode_atts( array(
			'img' => '',
			'url' => '',
		), $atts, 'noubakery_brand_item' );
		
		ob_start();
			if(!empty($atts['img'])):
			?>
			<a class="panel-partner-item" href="<?php echo esc_attr($atts['url']);?>" target="_blank">
	           	<?php echo noubakery_get_image_by_id($atts['img'], 'noubakery_157x157');?>
	        </a>
			<?php
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand items.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Brand Item", "bakery-helpers" ),
	      	"base" => "noubakery_brand_item",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noubakery_brand'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Title", "bakery-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", "bakery-helpers" ),
		            "param_name" => "img",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "URL", "bakery-helpers" ),
		            "param_name" => "url",
		        )
	      	)
	    ) );
		endif;
	}
}
?>