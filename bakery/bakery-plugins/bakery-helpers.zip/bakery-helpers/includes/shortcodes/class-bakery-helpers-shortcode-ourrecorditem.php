<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Ourrecorditem
{
	
	public static function shortcode( $atts ){
		$atts = shortcode_atts( array(
			'title' => '',
			'date' => '',
			'desc' => '',
			'url' => '',
			'img' => '',
		), $atts, 'noubakery_our_record_item' );

		ob_start();
		?>
		<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 ">
            <div class="ps-award text-center">
            	
            	<?php if(!empty($atts['img'])):?>
                <div class="ps-award__icon">
                	<?php echo noubakery_get_image_by_id($atts['img'], 'noubakery_100x100');?>
                </div>
                <?php endif;?>

              <div class="ps-award__content">

              	<?php if(!empty($atts['title'])):?>
                <h3><?php echo esc_html($atts['title']);?></h3>
                <?php endif;?>

                <?php if(!empty($atts['date'])):?>
                <span><?php echo esc_html($atts['date']);?></span>
                <?php endif;?>

                <?php if(!empty($atts['desc'])):?>
                	<?php echo wpautop($atts['desc']);?>
                <?php endif;?>
                
                <?php if(!empty($atts['url'])):?>
                <a class="ps-btn ps-btn--xs" href="<?php echo esc_url($atts['url']);?>"><?php esc_html_e('Read more', 'bakery-helpers');?></a>
                <?php endif;?>

              </div>
            </div>
        </div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Map shortcode Our Record Item
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map()
	{
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bakery - Our recode item", "bakery-helpers" ),
		      	"base" => "noubakery_our_record_item",
		      	"class" => "",
		      	"as_child" => array('only' => 'noubakery_our_record'),
		      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "bakery-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Date", "bakery-helpers" ),
			            "param_name" => "date",
			        ),
			        array(
			            "type" => "textarea",
			            "class" => "",
			            "heading" => esc_html__( "Description", "bakery-helpers" ),
			            "param_name" => "desc",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", "bakery-helpers" ),
			            "param_name" => "img",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Read more URL", "bakery-helpers" ),
			            "param_name" => "url",
			        ),
		      	)
		    ) );
		endif;
	}
}
?>