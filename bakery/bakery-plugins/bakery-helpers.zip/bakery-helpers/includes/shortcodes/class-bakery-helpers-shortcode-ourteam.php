<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Ourteam
{
	
	public static function shortcode($atts, $content = ''){
		
		$atts = shortcode_atts( array(
			'title_top' => '',
			'title' => '',
		), $atts, 'noubakery_our_team' );

		ob_start();
		?>
		<section class="ps-section ps-section--team ps-section--team-2 pt-80 pb-80">
	        <div class="container">
	          <div class="ps-section__header text-center">
	            <?php if(!empty($atts['title_top'])):?>
	        		<div class="ps-section__top"><?php echo esc_html($atts['title_top']);?></div>
	        	<?php endif;?>

	        	<?php if(!empty($atts['title'])):?>
	        		<h3 class="ps-section__title ps-section__title--full"><?php echo esc_html($atts['title']);?></h3>
	        	<?php endif;?>
	          </div>
	          <div class="ps-section__content">
	            <div class="row"><?php echo do_shortcode($content);?></div>
	          </div>
	        </div>
	    </section> 
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bakery - Our Team", "bakery-helpers" ),
		      	"base" => "noubakery_our_team",
		      	"class" => "",
		      	"as_parent" => array('only' => 'noubakery_our_team_item'),
		      	"content_element" => true,
			    "show_settings_on_create" => false,
			    "is_container" => true,
		      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
		      	"params" => array(
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title top", "bakery-helpers" ),
			            "param_name" => "title_top",
			        ),
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Title", "bakery-helpers" ),
			            "param_name" => "title",
			        ),
			        
		      	),
		      	"js_view" => 'VcColumnView'
		    ) );
		endif;
	}
}
?>