<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Ourteamitem
{
	public static function shortcode($atts){
		$atts = shortcode_atts( array(
			'title' => '',
			'position' => '',
			'desc' => '',
			'url' => '',
			'img' => '',
			'fb' => '',
			'twitter' => '',
			'tiktok' => '',
			'col' => '',
		), $atts, 'noubakery_our_team_item' );

		$col = !empty($atts['col']) ? $atts['col'] : '3';
		$class = 'col-lg-'.intval(12/$col).' col-md-'.intval(12/$col).'';
		ob_start();
		?>
		<div class="<?php echo esc_attr($class);?> col-sm-12 col-xs-12 ">
            <article class="ps-people ps-people--2">
              	<?php if(!empty($atts['img'])):?>
              	<div class="ps-people__thumbnail">
              		<a class="ps-people__overlay" href="<?php echo esc_url($atts['url']);?>"></a>
              		<?php echo noubakery_get_image_by_id($atts['img'], 'noubakery_360x280');?>
              	</div>
              	<?php endif;?>

              	<div class="ps-people__content">
	                <?php if(!empty($atts['title'])):?>
	                <h4><?php echo esc_html($atts['title']);?></h4>
	                <?php endif;?>

	                <?php if(!empty($atts['position'])):?>
	                <span class="ps-people__position"><?php echo esc_html($atts['position']);?></span>
	                <?php endif;?>

	                <?php if(!empty($atts['desc'])):?>
	                <?php echo wpautop(esc_html($atts['desc']));?>
	                <?php endif;?>

                    <ul class="ps-people__social">
                      	<?php if(!empty($atts['fb'])):?>
                      	<li><a href="<?php echo esc_url($atts['fb']);?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
                      	<?php endif;?>

                      	<?php if(!empty($atts['tiktok'])):?>
                      	<li><a href="<?php echo esc_url($atts['tiktok']);?>" target="_blank"><i><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="#000000" viewBox="0 0 448 512"><path d="M448 209.9a210.1 210.1 0 0 1 -122.8-39.3V349.4A162.6 162.6 0 1 1 185 188.3V278.2a74.6 74.6 0 1 0 52.2 71.2V0l88 0a121.2 121.2 0 0 0 1.9 22.2h0A122.2 122.2 0 0 0 381 102.4a121.4 121.4 0 0 0 67 20.1z"/></svg></i></a></li>
                      	<?php endif;?>

                      	<?php if(!empty($atts['twitter'])):?>
                      	<li><a href="<?php echo esc_url($atts['twitter']);?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
                      	<?php endif;?>

                    </ul>
              	</div>
            </article>
        </div>
		<?php
		return ob_get_clean();
	}

	public static function map(){
		if(function_exists('vc_map')):
			vc_map( array(
		      	"name" => esc_html__( "Bakery - Our team item", "bakery-helpers" ),
		      	"base" => "noubakery_our_team_item",
		      	"class" => "",
		      	"as_child" => array('only' => 'noubakery_our_team'),
		      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
		      	"params" => array(
			        
			        array(
			            "type" => "textfield",
			            "holder" => "div",
			            "class" => "",
			            "heading" => esc_html__( "Name", "bakery-helpers" ),
			            "param_name" => "title",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Position", "bakery-helpers" ),
			            "param_name" => "position",
			        ),
			        array(
			            "type" => "textarea",
			            "class" => "",
			            "heading" => esc_html__( "Description", "bakery-helpers" ),
			            "param_name" => "desc",
			        ),
			        array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Image", "bakery-helpers" ),
			            "param_name" => "img",
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "URL", "bakery-helpers" ),
			            "param_name" => "url",
			            'group' => esc_html__('Social', 'bakery-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Facebook URL", "bakery-helpers" ),
			            "param_name" => "fb",
			            'group' => esc_html__('Social', 'bakery-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Tiktok URL", "bakery-helpers" ),
			            "param_name" => "tiktok",
			            'group' => esc_html__('Social', 'bakery-helpers'),
			        ),
			        array(
			            "type" => "textfield",
			            "class" => "",
			            "heading" => esc_html__( "Twitter URL", "bakery-helpers" ),
			            "param_name" => "twitter",
			            'group' => esc_html__('Social', 'bakery-helpers'),
			        ),
			        array(
						'type' => 'dropdown',
						'heading' => esc_html__( 'Width', 'bakery-helpers' ),
						'param_name' => 'col',
						'value' => array(
							esc_html__( '1 column - 1/12', 'bakery-helpers' ) => '1',
							esc_html__( '2 columns - 1/6', 'bakery-helpers' ) => '2',
							esc_html__( '3 columns - 1/4', 'bakery-helpers' ) => '4',
							esc_html__( '4 columns - 1/3', 'bakery-helpers' ) => '3',
							esc_html__( '6 columns - 1/2', 'bakery-helpers' ) => '2',
						),
						'group' => esc_html__( 'Responsive Options', 'bakery-helpers' ),
						'description' => esc_html__( 'Select column width.', 'bakery-helpers' ),
						'std' => '4',
					),
		      	)
		    ) );
		endif;
	}
}
?>