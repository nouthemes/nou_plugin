<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Quote_Item
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'name' => '',
			'desc' => '',
		), $atts, 'noubakery_quote_item' );
		
		ob_start();
			if(!empty($atts['desc'])):
			?>
			<div class="ps-testimonial--2">
                <?php echo wpautop($atts['desc']);?>
                <?php if(!empty($atts['name'])):?><p class="author">- <?php echo esc_html($atts['name']);?> -</p><?php endif;?>
            </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Quote Item", 'bakery-helpers' ),
	      	"base" => "noubakery_quote_item",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", 'bakery-helpers'),
	      	"content_element" => true,
    		"as_child" => array('only' => 'noubakery_quote'),
    		"params" => array(
		        array(
		            "type" => "textfield",
		            "holder" => "div",
		            "class" => "",
		            "heading" => esc_html__( "Name", 'bakery-helpers' ),
		            "param_name" => "name",
		        ),
		        array(
		            "type" => "textarea",
		            "class" => "",
		            "heading" => esc_html__( "Description", 'bakery-helpers' ),
		            "param_name" => "desc",
		        )
	      	)
	    ) );
	}
}
?>