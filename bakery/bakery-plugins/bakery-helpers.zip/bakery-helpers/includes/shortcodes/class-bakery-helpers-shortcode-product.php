<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Product
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'id' => '',
			'class' => '',
		), $atts, 'noubakery_product' );
		$add_to_cart_enable = noubakery_cs_get_option('noubakery_shop_enable_cart');
		$meta_query = WC()->query->get_meta_query();

		$args = array(
			'post_type'      => 'product',
			'posts_per_page' => 1,
			'no_found_rows'  => 1,
			'post_status'    => 'publish',
			'meta_query'     => $meta_query,
			'tax_query'      => WC()->query->get_tax_query(),
		);

		if ( isset( $atts['id'] ) ) {
			$args['p'] = $atts['id'];
		}

		ob_start();

		$products = new WP_Query( apply_filters( 'woocommerce_shortcode_products_query', $args, $atts, null ) );

		if ( $products->have_posts() ) : ?>

			<?php woocommerce_product_loop_start(); ?>

				<?php
				while ( $products->have_posts() ) : $products->the_post(); 
				$product = wc_get_product(get_the_ID());
				global $post;
				if($product):
					$class = implode( ' ', array_filter( array(
							            'button',
							            'product_type_' . $product->get_type(),
							            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
							            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
							        ) ) );
				?>
					
					<div class="product-shortcode product ps-product--list <?php echo esc_attr(isset($atts['class']) ? $atts['class'] : '');?>">
	                    <div class="ps-product__thumbnail">
	                    	<a class="ps-product__overlay" href="<?php echo esc_url( $product->get_permalink() ); ?>"></a>
	                    	<?php echo wp_kses_post($product->get_image('shop_catalog')); ?>
	                    </div>
	                    <div class="ps-product__content">
	                        <h4 class="ps-product__title"><a href="<?php echo esc_url( $product->get_permalink() ); ?>"><?php the_title();?></a></h4>
	                        <?php echo wp_kses_post(wpautop(wp_trim_words($post->post_excerpt, '10')));?>
	                        <p class="ps-product__price">
	                          <span class="woocs_price_code" data-currency="" data-redraw-id="<?php echo uniqid(); ?>" data-product-id="<?php echo esc_attr($product->get_id()); ?>"><?php echo wp_kses_post($product->get_price_html()); ?></span>
	                        </p>
	                        <?php
	                        if(!empty($add_to_cart_enable)):
						      	echo apply_filters( 'woocommerce_single_product_add_to_cart_link',
									sprintf( '<a data-type="compare" rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn ps-btn--xs product-item-cart %s">%s<i class="fa fa-angle-right"></i></a>',
										esc_url( $product->add_to_cart_url() ),
										esc_attr( isset( $quantity ) ? $quantity : 1 ),
										esc_attr( $product->get_id() ),
										esc_attr( $product->get_sku() ),
										esc_attr( isset( $class ) ? $class : 'button' ),
										esc_html( $product->add_to_cart_text() )
									),
								$product );
						    endif;
					      	?>

	                    </div>
                    </div>

				<?php endif;endwhile; // end of the loop. ?>

			<?php woocommerce_product_loop_end(); ?>

		<?php endif;

		wp_reset_postdata();

		$css_class = 'woocommerce';

		if ( isset( $atts['class'] ) ) {
			$css_class .= ' ' . $atts['class'];
		}

		return '<div class="' . esc_attr( $css_class ) . '">' . ob_get_clean() . '</div>';
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Product", "bakery-helpers" ),
	      	"base" => "noubakery_product",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
	      	"params" => array(
		     
				array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product ID", "bakery-helpers" ),
		            "param_name" => "id",
		            "holder" => "div",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Extra class name", "bakery-helpers" ),
		            "param_name" => "class",
		        )
	      	)
	    ) );
		endif;
	}
}
?>