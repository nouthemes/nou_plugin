<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Testimonial
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		$atts = shortcode_atts( array(
			'img' => '',
		), $atts, 'noubakery_testimonial' );
		
		$bg = BAKERYTHEMEHELPERS_URL.'assets/images/parallax/img-bg-1.jpg';
		if(!empty($atts['img'])){
			$images = wp_get_attachment_image_src($atts['img'], 'full');
			if($images){
				$bg = $images[0];
			}
		}
		ob_start();
			if(!empty($content)):
			?>
			<div class="ps-section ps-section--home-testimonial pb-30 bg--parallax" data-background="<?php echo esc_attr($bg);?>">
		        <div class="container">
		          	<div class="owl-slider" data-owl-auto="true" data-owl-loop="true" data-owl-speed="10000" data-owl-gap="0" data-owl-nav="false" data-owl-dots="true" data-owl-animate-in="" data-owl-animate-out="" data-owl-item="1" data-owl-item-xs="1" data-owl-item-sm="1" data-owl-item-md="1" data-owl-item-lg="1" data-owl-nav-left="&lt;i class=&quot;fa fa-angle-left&quot;&gt;&lt;/i&gt;" data-owl-nav-right="&lt;i class=&quot;fa fa-angle-right&quot;&gt;&lt;/i&gt;">
		          		<?php echo do_shortcode($content);?>
		          	</div>
		        </div>
		    </div>
			<?php	
			endif;
		return ob_get_clean();
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Testimonial Carousel", "bakery-helpers" ),
	      	"base" => "noubakery_testimonial",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
	      	"params" => array(

	      		array(
			            "type" => "attach_image",
			            "class" => "",
			            "heading" => esc_html__( "Background image", "bakery-helpers" ),
			            "param_name" => "img",
			        ),

	      	),
	      	"as_parent" => array('only' => 'noubakery_testimonial_item'),
	      	"content_element" => true,
		    "show_settings_on_create" => false,
		    "is_container" => true,
		    "js_view" => 'VcColumnView'
	    ) );
		endif;
	}
}
?>