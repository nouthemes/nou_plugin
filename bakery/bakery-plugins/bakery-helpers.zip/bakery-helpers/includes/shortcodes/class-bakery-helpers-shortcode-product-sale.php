<?php
/**
* 
*/
class Bakery_Helpers_Shortcode_Product_Sale
{
	
	/**
	 * Brand slider
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function shortcode(  $atts, $content ) {
		if ( empty( $atts ) ) {
			return '';
		}

		$atts = shortcode_atts( array(
			'id' => '',
			'img' => '',
			'title' => '',
			'title_product' => '',
			'class' => '',
		), $atts, 'noubakery_product_sale' );

		$html = '';
		$add_to_cart_enable = noubakery_cs_get_option('noubakery_shop_enable_cart');

		if(!empty($atts['id'])):
		ob_start();
			$args = array(
				'post_type' => 'product', 
				'post_status' => 'publish',
				'p' => $atts['id']
			);
			$products = new WP_Query($args);
			if($products->have_posts()):
				while($products->have_posts()): $products->the_post();
					$product = wc_get_product(get_the_ID());
					if($product){
						$title = $product->get_name();
						if(!empty($atts['title_product'])){
							$title = $atts['title_product'];
						}
						$sales_price_to = get_post_meta($atts['id'], '_sale_price_dates_to', true);
						$image_id = $product->get_image_id();
						if(!empty($atts['img'])){
							$image_id = $atts['img'];
						}

						$images = wp_get_attachment_image_src($image_id, 'noubakery_555x431');

						$class = implode( ' ', array_filter( array(
									            'button',
									            'product_type_' . $product->get_type(),
									            $product->is_purchasable() && $product->is_in_stock() ? 'add_to_cart_button' : '',
									            $product->supports( 'ajax_add_to_cart' ) ? 'ajax_add_to_cart' : '',
									        ) ) );
						?>
						<div class="ps-section <?php echo esc_attr(!empty($atts['class']) ? $atts['class'] : '');?>">
		        			<div class="container">
						        <div class="ps-countdown products">
						            <div class="row product">
						                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
						                  	<?php if($images):?><img src="<?php echo esc_attr($images['0']);?>" alt=""><?php endif;?>
						                </div>
						                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
						                    <header class="text-center">
						                      	<?php if(!empty($atts['title'])):?>
						                      		<div class="ps-section__top"><?php echo esc_html($atts['title']);?></div>
						                      	<?php endif;?>

						                      	<h4><a href="<?php echo esc_url( $product->get_permalink() ); ?>" class="ps-product__title"><?php echo esc_html($title);?></a></h4>
						                      	<p class="p-ps-product__price"><?php esc_html_e('Only', 'bakery-helpers');?>: <span class="woocs_price_code" data-currency="" data-redraw-id="<?php echo uniqid(); ?>" data-product-id="<?php echo esc_attr($product->get_id()); ?>"><?php echo wp_kses_post($product->get_price_html());?></span></p>

						                      	<?php if($product->is_on_sale() && !empty($sales_price_to)):?>

						                      	<?php if($product->get_manage_stock() && $product->get_stock_quantity() > 0):?>
						                      	<?php 
						                      	$total_sales = get_post_meta($product->get_id(), 'total_sales', true);
						                      	$total_sales = !empty($total_sales) ? $total_sales : '0';
						                      	$total_stock = $product->get_stock_quantity();
						                      	?>
						                      	<div class="ps-product__status row">
							                        <div class="col-md-6 sold"><?php esc_html_e('Already sold', 'bakery-helpers');?>: <span><?php echo esc_html($total_sales);?></span></div>
							                        <div class="col-md-6 avaiable"><?php esc_html_e('avaiable', 'bakery-helpers');?>: <span><?php echo intval($total_stock)?></span></div>
							                    </div>
							                    <div class="ps-product__process">
							                      	<div class="progress">
								                      <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo intval($total_sales*100/$total_stock)?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo intval($total_sales*100/$total_stock)?>%;"></div>
								                    </div>
								                </div>
								                <?php endif;?>

							                    <ul class="ps-countdown__time" data-time="<?php echo esc_attr(date("F d, Y", $sales_price_to));?> 23:59:59">
							                        <li><span class="hours"></span><p><?php esc_html_e('Hours', 'bakery-helpers');?></p></li>
							                        <li class="divider">:</li>
							                        <li><span class="minutes"></span><p><?php esc_html_e('minutes', 'bakery-helpers');?></p></li>
							                        <li class="divider">:</li>
							                        <li><span class="seconds"></span><p><?php esc_html_e('Seconds', 'bakery-helpers');?></p></li>
							                    </ul>
							                    <?php endif;?>
						                      	
						                      	<?php
						                      	if(!empty($add_to_cart_enable)):
											      	echo apply_filters( 'woocommerce_sale_product_add_to_cart_link',
														sprintf( '<a data-type="compare" rel="nofollow" href="%s" data-quantity="%s" data-product_id="%s" data-product_sku="%s" class="ps-btn product-item-cart %s">%s<i class="fa fa-angle-right"></i></a>',
															esc_url( $product->add_to_cart_url() ),
															esc_attr( isset( $quantity ) ? $quantity : 1 ),
															esc_attr( $product->get_id() ),
															esc_attr( $product->get_sku() ),
															esc_attr( isset( $class ) ? $class : 'button' ),
															esc_html( $product->add_to_cart_text() )
														),
													$product );
											    endif;
										      	?>
						                      	
						                    </header>
						                </div>
						            </div>
						        </div>
						    </div>
						</div>
						<?php
					}
				endwhile;
			endif; wp_reset_postdata();
		$html = ob_get_clean();
		endif;

		return $html;
	}

	/**
	 * Map shortcode Brand.
	 *
	 * @param array $atts
	 * @return string
	 */
	public static function map() 
	{
		if(function_exists('vc_map')):
		vc_map( array(
	      	"name" => esc_html__( "Bakery - Product sale", "bakery-helpers" ),
	      	"base" => "noubakery_product_sale",
	      	"class" => "",
	      	"category" => esc_html__( "Bakery theme", "bakery-helpers"),
	      	"params" => array(
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Product ID", "bakery-helpers" ),
		            "param_name" => "id",
		            "holder" => "div",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Title of section", "bakery-helpers" ),
		            "param_name" => "title",
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "holder" => "div",
		            "heading" => esc_html__( "Title of product", "bakery-helpers" ),
		            "param_name" => "title_product",
		            'description' => esc_html__('Custome title for product.', 'bakery-helpers'),
		        ),
		        array(
		            "type" => "attach_image",
		            "class" => "",
		            "heading" => esc_html__( "Image", "bakery-helpers" ),
		            "param_name" => "img",
		            'description' => esc_html__('If used this image, it will replace the default.', 'bakery-helpers'),
		        ),
		        array(
		            "type" => "textfield",
		            "class" => "",
		            "heading" => esc_html__( "Custome class", "bakery-helpers" ),
		            "param_name" => "class",
		        ),
	      	)
	    ) );
		endif;
	}
}
?>