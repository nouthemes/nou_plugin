<?php
/**
* 
*/
class Bakery_Helpers_Blocks_Blog
{


	public static function render($attributes, $content)
	{	
		if(isset($attributes['id'])){
			return '';
		}

		$id = isset($attributes['id']) ? $attributes['id'] : ''; 
		$img = isset($attributes['img']) ? $attributes['img'] : ''; 
		$style = isset($attributes['style']) ? $attributes['style'] : '';

		$output = '<div class="bakery-helpers-block-blog">';
		$output .= do_shortcode('[noubakery_post style="'.$style.'" id="'.$id.'" img="'.$img.'"]');
		$output .= '</div>';
		return $output;
	}
}
?>