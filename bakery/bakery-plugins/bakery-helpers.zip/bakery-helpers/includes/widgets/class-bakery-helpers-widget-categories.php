<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget about
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Bakery_Helpers_Widget_Categories extends WP_Widget {

	/**
	 * Sets up a new Upload a banner.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--category',
			'description' => esc_html__( 'Custom list Categories.', 'bakery-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Noubakery_Theme_Widget_Categories', esc_html__('* Bakery - Categories', 'bakery-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		
		$first_item_text = ( isset($instance['first_item_text']) && !empty($instance['first_item_text']) ) ? $instance['first_item_text'] : '';
		$first_item_url = ( isset($instance['first_item_url']) && !empty($instance['first_item_url']) ) ? $instance['first_item_url'] : '';
		$taxonomy = ( isset($instance['taxonomy']) && !empty($instance['taxonomy']) ) ? $instance['taxonomy'] : '';
		$type = ( isset($instance['type']) && !empty($instance['type']) ) ? $instance['type'] : '';

		echo noubakery_esc($args['before_widget']);
		
			if(!empty($title)){ echo noubakery_esc($args['before_title'].$title.$args['after_title']); }
			
			?>
			<ul class="<?php if($type != '2'){echo 'ps-list--arrow';}else{echo 'ps-list--circle';}?>">
				<?php if(!empty($first_item_text) && !empty($first_item_url)):?>
					<?php if(is_home() || is_post_type_archive('product')):?>
					<li class="current">
					<?php else:?>
					<li>
					<?php endif;?>
						<a href="<?php echo esc_url($first_item_url);?>">
						<span class="circle"></span><?php echo esc_html($first_item_text);?></a>
					</li>
				<?php endif;?>

				<?php 
				if(!empty($taxonomy)){
					$terms = get_terms(apply_filters( 'widget_categories_args', array(
					    'taxonomy' => $taxonomy
					)));
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
						foreach ( $terms as $term ) {
							$current = '';
							if(is_tax()){
								$current_id = get_queried_object()->term_id;
								if($current_id == $term->term_id){
									$current = 'current';
								}
							}
					        echo '<li class="'.esc_attr($current).'"><a href="' . esc_url( get_term_link( $term ) ) . '"><span class="circle"></span>' . esc_html($term->name) . '</a></li>';
					    }
					}
				}
				?>
			</ul>
			<?php
		
		echo noubakery_esc($args['after_widget']);

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'title' => '',
									 'first_item_text' => '', 
									 'first_item_url' => '', 
									 'taxonomy' => '',
									 'type' => '',
									 ) 
		);
		$title 				= strip_tags($instance['title']);
		$first_item_text 	= strip_tags($instance['first_item_text']);
		$first_item_url 	= strip_tags($instance['first_item_url']);
		$taxonomy 			= strip_tags($instance['taxonomy']);
		$type 			= strip_tags($instance['type']);
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('first_item_text') ); ?>"><?php esc_html_e('First item text:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('first_item_text') ); ?>" name="<?php echo esc_attr( $this->get_field_name('first_item_text') ); ?>" type="text" value="<?php echo esc_attr($first_item_text); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('first_item_url') ); ?>"><?php esc_html_e('First item URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('first_item_url') ); ?>" name="<?php echo esc_attr( $this->get_field_name('first_item_url') ); ?>" type="text" value="<?php echo esc_attr($first_item_url); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('taxonomy') ); ?>"><?php esc_html_e('Taxonomy:', 'bakery-helpers'); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id('taxonomy') ); ?>" name="<?php echo esc_attr( $this->get_field_name('taxonomy') ); ?>">
			<option value="0"><?php esc_html_e('Select a taxonomy', 'bakery-helpers');?></option>
			<?php
			$taxonomies = get_taxonomies(); 
			foreach ( $taxonomies as $tax ) {
			    echo '<option value="'.esc_attr($tax).'" '.selected($taxonomy, $tax, false).'>'.esc_attr($tax).'</option>';
			}
			?>
		</select>
		</p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('type') ); ?>"><?php esc_html_e('Type of display: ', 'bakery-helpers'); ?></label>
		<select class="widefat" id="<?php echo esc_attr( $this->get_field_id('type') ); ?>" name="<?php echo esc_attr( $this->get_field_name('type') ); ?>">
			<option value="1" <?php selected($type, '1');?>><?php esc_html_e('Menu', 'bakery-helpers');?></option>
			<option value="2" <?php selected($type, '2');?>><?php esc_html_e('Checked', 'bakery-helpers');?></option>
		</select>
		</p>
		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 	= strip_tags($new_instance['title']);
		$instance['first_item_text'] 	= strip_tags($new_instance['first_item_text']);
		$instance['first_item_url'] 	= strip_tags($new_instance['first_item_url']);
		$instance['taxonomy'] 	= strip_tags($new_instance['taxonomy']);
		$instance['type'] 	= strip_tags($new_instance['type']);

		return $instance;
	}

}

?>