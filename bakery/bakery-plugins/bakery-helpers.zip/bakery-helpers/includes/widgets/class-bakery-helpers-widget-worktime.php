<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Banner
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Bakery_Helpers_Widget_Worktime extends WP_Widget {

	/**
	 * Sets up a new Worktime widget.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--worktime',
			'description' => esc_html__( 'Work time.', 'bakery-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Noubakery_Theme_Widget_Worktime', esc_html__('* Bakery - Work time', 'bakery-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$widget_text = ! empty( $instance['text'] ) ? $instance['text'] : '';
		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		if(!empty($widget_text)){
			echo noubakery_esc($args['before_widget']);
		
			if(!empty($title)){ echo noubakery_esc($args['before_title'].$title.$args['after_title']); }
				echo wp_kses_post(wpautop( $widget_text ));
			echo noubakery_esc($args['after_widget']);
		}	

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'text' => '',
									 'title' => '',
									 ) 
		);
		$title = strip_tags($instance['title']);
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo noubakery_esc($this->get_field_id( 'text' )); ?>"><?php esc_html_e( 'Content:', 'bakery-helpers' ); ?></label>
		<textarea class="widefat" rows="16" cols="20" id="<?php echo noubakery_esc($this->get_field_id('text')); ?>" name="<?php echo noubakery_esc($this->get_field_name('text')); ?>"><?php echo esc_textarea( $instance['text'] ); ?></textarea></p>

		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['text'] = $new_instance['text'];

		return $instance;
	}

}

?>