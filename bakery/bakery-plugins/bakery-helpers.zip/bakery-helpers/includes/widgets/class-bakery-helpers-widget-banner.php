<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Banner
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Bakery_Helpers_Widget_Banner extends WP_Widget {

	/**
	 * Sets up a new Upload a banner.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--ads',
			'description' => esc_html__( 'Upload a banner.', 'bakery-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Noubakery_Theme_Widget_Banner', esc_html__('* Bakery - Banner', 'bakery-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$url = ( isset($instance['url']) && !empty($instance['url']) ) ? $instance['url'] : '';
		$img = ( isset($instance['img']) && !empty($instance['img']) ) ? $instance['img'] : '';
		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		if(!empty($img)){
			echo noubakery_esc($args['before_widget']);
		
			if(!empty($title)){ echo noubakery_esc($args['before_title'].$title.$args['after_title']); }
			?>
			<div class="ps-widget__content">
				<a class="panel-box-banner" href="<?php echo esc_attr($url);?>">
					<?php
					$enable_lazy = noubakery_noubakery_cs_get_option('noubakery_lazy');
					if($enable_lazy){
						$loading_src = noubakery_theme_image_loading_src();
						?>
						<img class="lazy" src="<?php echo esc_attr($loading_src);?>" data-original="<?php echo esc_attr($img);?>" alt="<?php echo esc_attr($title);?>">
					<?php }else{?>
						<img src="<?php echo esc_attr($img);?>" alt="<?php echo esc_attr($title);?>">
					<?php }?>	
				</a>
			</div>
			<?php
			echo noubakery_esc($args['after_widget']);
		}	

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'url' => '', 
									 'img' => '',
									 'title' => '',
									 ) 
		);
		$url = strip_tags($instance['url']);
		$title = strip_tags($instance['title']);
		$img = sanitize_text_field( $instance['img'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('url') ); ?>"><?php esc_html_e('Link:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('url') ); ?>" name="<?php echo esc_attr( $this->get_field_name('url') ); ?>" type="text" value="<?php echo esc_attr($url); ?>" /></p>

		
		<p><label for="<?php echo esc_attr( $this->get_field_id('img') ); ?>"><?php esc_html_e('Upload banner', 'bakery-helpers'); ?></label></p>
		<div class="cs-element cs-field-upload">
			<div class="cs-fieldset">
				<input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('img') ); ?>" name="<?php echo esc_attr( $this->get_field_name('img') ); ?>" value="<?php echo esc_attr($img); ?>">
				<a href="#" class="button cs-add" data-frame-title="<?php esc_html_e('Upload', 'bakery-helpers');?>" data-upload-type="image" data-insert-title="<?php esc_html_e('Use Image', 'bakery-helpers');?>"><?php esc_html_e('Upload', 'bakery-helpers');?></a>
			</div>
			<div class="clear"></div>
		</div>

		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['url'] = strip_tags($new_instance['url']);
		$instance['img'] = sanitize_text_field( $new_instance['img'] );

		return $instance;
	}

}

?>