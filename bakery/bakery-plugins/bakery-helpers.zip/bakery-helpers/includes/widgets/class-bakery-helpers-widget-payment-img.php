<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget Banner
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Bakery_Helpers_Widget_Payment_Img extends WP_Widget {

	/**
	 * Sets up a new Archives widget instance.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--payment',
			'description' => esc_html__( 'Upload a payments gateway image.', 'bakery-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Noubakery_Theme_Widget_Payment_Img', esc_html__('* Bakery - Payments Accepted', 'bakery-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$photos = $instance['photos'];
		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		
		if(!empty($photos)){
			echo noubakery_esc($args['before_widget']);
		
			if(!empty($title)){ echo noubakery_esc($args['before_title'].$title.$args['after_title']); }
			
			if( !empty($photos) ){

				echo '<ul>';
					
					$arr_photos = explode( ',', $photos );
					if( is_array($arr_photos) ){

						foreach ( $arr_photos as $id ) {

							$images = wp_get_attachment_image_src( $id );

							if( $images ):
								echo '<li><a href="'.esc_url( wp_get_attachment_url( $id ) ).'"><img src="'.esc_attr( $images[0] ).'" alt="'.esc_attr($title).'" /></a></li>';
							endif;

						}

					}

				echo '</ul>';
			}

			echo noubakery_esc($args['after_widget']);
		}	

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'url' => '', 
									 'photos' => '',
									 'title' => '',
									 ) 
		);
		$photos = strip_tags($instance['photos']);
		$title = strip_tags($instance['title']);
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		
		<div class="show_if_upload">

			<div class="cs-element cs-field-gallery">
				<div class="cs-title">
					<h4><?php esc_html_e('Upload images', 'bakery-helpers');?></h4>
				</div>
				<div class="cs-fieldset">
					<ul>
						<?php
						if( !empty($photos) ){
								
							$arr_photos = explode( ',', $photos );
							
							if( is_array($arr_photos) ){

								foreach ( $arr_photos as $id ) {

									$images = wp_get_attachment_image_src( $id, 'thumbnail' );

									if( $images ):
										
										echo '<li><img src="'.esc_attr( $images[0] ).'" alt="thumbnail"></li>';
									
									endif;

								}

							}

						}
						?>
					</ul>
					<a href="#" class="button button-primary cs-add"><?php esc_html_e('Add Images', 'bakery-helpers');?></a>
					<a href="#" class="button cs-edit <?php if( empty($photos) ){echo 'hidden';}?>"><?php esc_html_e('Edit Images', 'bakery-helpers');?></a>
					<a href="#" class="button cs-warning-primary cs-remove <?php if( empty($photos) ){echo 'hidden';}?>"><?php esc_html_e('Remove Images', 'bakery-helpers');?></a>
					<input type="hidden" class="cs-input-gallery" name="<?php echo esc_attr( $this->get_field_name('photos') ); ?>" value="<?php echo esc_attr($photos); ?>" id="<?php echo esc_attr( $this->get_field_id('photos') ); ?>" />
				</div>
				<div class="clear"></div>
			</div>
		</div>

		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] = strip_tags($new_instance['title']);
		$instance['photos'] = strip_tags($new_instance['photos']);

		return $instance;
	}

}

?>