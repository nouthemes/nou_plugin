<?php 
defined( 'ABSPATH' ) OR exit;

/**
* Class widget about
*
* @author nouthemes [nouthemes@gmail.com] 
* @since 1.0
* @Code Nam
*/

class Bakery_Helpers_Widget_Social extends WP_Widget {

	/**
	 * Sets up a new Worktime widget.
	 *
	 * @since 2.8.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'ps-widget--connect',
			'description' => esc_html__( 'Social account for store.', 'bakery-helpers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct('Noubakery_Theme_Widget_Social', esc_html__('* Bakery - Social', 'bakery-helpers'), $widget_ops);
	}

	/**
	 * @param array $args
	 * @param array $instance
	 */
	// Creating widget front-end
	// This is where the action happens
	public function widget( $args, $instance ) {

		$title = ( isset($instance['title']) && !empty($instance['title']) ) ? $instance['title'] : '';
		
		$address = ( isset($instance['address']) && !empty($instance['address']) ) ? $instance['address'] : '';
		$facebook = ( isset($instance['facebook']) && !empty($instance['facebook']) ) ? $instance['facebook'] : '';
		$twitter = ( isset($instance['twitter']) && !empty($instance['twitter']) ) ? $instance['twitter'] : '';
		$tiktok = ( isset($instance['tiktok']) && !empty($instance['tiktok']) ) ? $instance['tiktok'] : '';
		$instagram = ( isset($instance['instagram']) && !empty($instance['instagram']) ) ? $instance['instagram'] : '';

		echo noubakery_esc($args['before_widget']);
		
			if(!empty($title)){ echo noubakery_esc($args['before_title'].$title.$args['after_title']); }
			
			?>
			<ul class="ps-widget__social">
                <?php if(!empty($facebook)){?><li><a href="<?php echo esc_url($facebook);?>" target="_blank"><i class="fa fa-facebook"></i></a></li><?php }?>
                <?php if(!empty($tiktok)){?><li><a href="<?php echo esc_url($tiktok);?>" target="_blank"><i><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="#337ab7" viewBox="0 0 448 512"><path d="M448 209.9a210.1 210.1 0 0 1 -122.8-39.3V349.4A162.6 162.6 0 1 1 185 188.3V278.2a74.6 74.6 0 1 0 52.2 71.2V0l88 0a121.2 121.2 0 0 0 1.9 22.2h0A122.2 122.2 0 0 0 381 102.4a121.4 121.4 0 0 0 67 20.1z"></path></svg></i>
                    </a></li><?php }?>
                <?php if(!empty($twitter)){?><li><a href="<?php echo esc_url($twitter);?>" target="_blank"><i class="fa fa-twitter"></i></a></li><?php }?>
                <?php if(!empty($instagram)){?><li><a href="<?php echo esc_url($instagram);?>" target="_blank"><i class="fa fa-instagram"></i></a></li><?php }?>
            </ul>
            <?php if(!empty($address)){?><a href="<?php echo esc_attr($address);?>"><img src="<?php echo esc_attr(NOUBAKERY_IMG.'/app.jpg');?>" alt="<?php echo esc_attr($title);?>"></a><?php }?>
          	<div class="footer-copyright"><?php echo wpautop(noubakery_cs_get_option('noubakery_copyright'));?></div>
			<?php

		echo noubakery_esc($args['after_widget']);

	}
		
	// Widget Backend 
	public function form( $instance ) {

		$instance = wp_parse_args( 
			(array) $instance, array(
									 'title' => '', 
									 'phone_1' => '',
									 'phone_2' => '',
									 'email' => '',
									 'address' => '',
									 'facebook' => '', 
									 'pinterest' => '',
									 'twitter' => '',
									 'tiktok' => '',
									 'instagram' => '',
									 'youtube' => '',
									 ) 
		);
		$title 				= strip_tags($instance['title']);
		$address     		= sanitize_text_field( $instance['address'] );

		$facebook           = sanitize_text_field( $instance['facebook'] );
		$twitter            = sanitize_text_field( $instance['twitter'] );
		$tiktok     	    = sanitize_text_field( $instance['tiktok'] );
		$instagram          = sanitize_text_field( $instance['instagram'] );
		?>

		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e('Title:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('address') ); ?>"><?php esc_html_e('App store URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('address') ); ?>" name="<?php echo esc_attr( $this->get_field_name('address') ); ?>" type="text" value="<?php echo esc_attr($address); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>"><?php esc_html_e('Facebook URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('facebook') ); ?>" name="<?php echo esc_attr( $this->get_field_name('facebook') ); ?>" type="text" value="<?php echo esc_attr($facebook); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>"><?php esc_html_e('Twitter URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('twitter') ); ?>" name="<?php echo esc_attr( $this->get_field_name('twitter') ); ?>" type="text" value="<?php echo esc_attr($twitter); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('tiktok') ); ?>"><?php esc_html_e('Tiktok URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('tiktok') ); ?>" name="<?php echo esc_attr( $this->get_field_name('tiktok') ); ?>" type="text" value="<?php echo esc_attr($tiktok); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>"><?php esc_html_e('Instagram URL:', 'bakery-helpers'); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('instagram') ); ?>" name="<?php echo esc_attr( $this->get_field_name('instagram') ); ?>" type="text" value="<?php echo esc_attr($instagram); ?>" /></p>
		<?php
	}

	
	
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		
		$instance = $old_instance;

		$instance['title'] 				= strip_tags($new_instance['title']);
		
		$instance['phone_1']            = sanitize_text_field( $new_instance['phone_1'] );
		$instance['phone_2']     		= sanitize_text_field( $new_instance['phone_2'] );
		$instance['email']            	= sanitize_text_field( $new_instance['email'] );
		$instance['address']     		= sanitize_text_field( $new_instance['address'] );

		$instance['facebook']           = sanitize_text_field( $new_instance['facebook'] );
		$instance['pinterest']     		= sanitize_text_field( $new_instance['pinterest'] );
		$instance['twitter']            = sanitize_text_field( $new_instance['twitter'] );
		$instance['tiktok']     	    = sanitize_text_field( $new_instance['tiktok'] );
		$instance['instagram']          = sanitize_text_field( $new_instance['instagram'] );
		$instance['youtube']     		= sanitize_text_field( $new_instance['youtube'] );

		return $instance;
	}

}

?>