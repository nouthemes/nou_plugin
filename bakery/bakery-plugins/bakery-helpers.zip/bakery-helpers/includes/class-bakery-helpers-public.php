<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       http://nouthemes.com
 * @since      1.0.0
 *
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Bakery_Helpers
 * @subpackage Bakery_Helpers/public
 * @author     nouthemes <nouthemes@gmail.com>
 */
class Bakery_Helpers_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

	}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

	}

	/**
	 * Output logo width CSS variables
	 *
	 * @since    1.0.0
	 */
	public function output_logo_css() {
		// Include framework files if not already included
		if (!function_exists('noubakery_cs_get_customize_option')) {
			require_once plugin_dir_path(dirname(__FILE__)) . 'admin/cs-framework-path.php';
		}
		
		// Get all options at once to avoid multiple database queries
		$customize_options = noubakery_cs_get_all_customize_option();
		$theme_options = noubakery_cs_get_all_option();
		
		// Get logo width values from theme options
		$theme_logo_1_width = isset($theme_options['noubakery_logo_1_width']) ? absint($theme_options['noubakery_logo_1_width']) : 150;
		$theme_logo_2_width = isset($theme_options['noubakery_logo_2_width']) ? absint($theme_options['noubakery_logo_2_width']) : 150;
		$theme_logo_3_width = isset($theme_options['noubakery_logo_3_width']) ? absint($theme_options['noubakery_logo_3_width']) : 150;
		$theme_logo_sticky_width = isset($theme_options['noubakery_logo_sticky_width']) ? absint($theme_options['noubakery_logo_sticky_width']) : 50;
		
		// Get logo width values from customizer options
		$customize_logo_1_width = isset($customize_options['logo_1_width']) ? absint($customize_options['logo_1_width']) : 0;
		$customize_logo_2_width = isset($customize_options['logo_2_width']) ? absint($customize_options['logo_2_width']) : 0;
		$customize_logo_3_width = isset($customize_options['logo_3_width']) ? absint($customize_options['logo_3_width']) : 0;
		$customize_logo_sticky_width = isset($customize_options['logo_sticky_width']) ? absint($customize_options['logo_sticky_width']) : 0;
		
		// Sync theme options to customizer options if needed
		if ($customize_logo_1_width === 0 || $customize_logo_1_width !== $theme_logo_1_width) {
			$customize_options['logo_1_width'] = $theme_logo_1_width;
			update_option(NOUBAKERY_CS_CUSTOMIZE, $customize_options);
			$customize_logo_1_width = $theme_logo_1_width;
		}
		
		if ($customize_logo_2_width === 0 || $customize_logo_2_width !== $theme_logo_2_width) {
			$customize_options['logo_2_width'] = $theme_logo_2_width;
			update_option(NOUBAKERY_CS_CUSTOMIZE, $customize_options);
			$customize_logo_2_width = $theme_logo_2_width;
		}
		
		if ($customize_logo_3_width === 0 || $customize_logo_3_width !== $theme_logo_3_width) {
			$customize_options['logo_3_width'] = $theme_logo_3_width;
			update_option(NOUBAKERY_CS_CUSTOMIZE, $customize_options);
			$customize_logo_3_width = $theme_logo_3_width;
		}
		
		if ($customize_logo_sticky_width === 0 || $customize_logo_sticky_width !== $theme_logo_sticky_width) {
			$customize_options['logo_sticky_width'] = $theme_logo_sticky_width;
			update_option(NOUBAKERY_CS_CUSTOMIZE, $customize_options);
			$customize_logo_sticky_width = $theme_logo_sticky_width;
		}
		
		// Use the values from theme options
		$logo_1_width = $theme_logo_1_width;
		$logo_2_width = $theme_logo_2_width;
		$logo_3_width = $theme_logo_3_width;
		$logo_sticky_width = $theme_logo_sticky_width;
		
		// Add debugging comment
		$debug = '/* Debug - Logo widths: 1=' . $logo_1_width . 'px (customize=' . $customize_logo_1_width . ', theme=' . $theme_logo_1_width . '), 2=' . $logo_2_width . 'px, 3=' . $logo_3_width . 'px, sticky=' . $logo_sticky_width . 'px */';
		
		$css = ':root {';
		$css .= '--logo-width: ' . esc_attr($logo_1_width) . 'px;';
		$css .= '--logo-width-2: ' . esc_attr($logo_2_width) . 'px;';
		$css .= '--logo-width-3: ' . esc_attr($logo_3_width) . 'px;';
		$css .= '--logo-width-sticky: ' . esc_attr($logo_sticky_width) . 'px;';
		$css .= '--logo-width-mobile: ' . esc_attr($logo_1_width) . 'px;'; // Use the same width for mobile
		$css .= '}';
		
		// Add more specific CSS rules to ensure logo width is applied correctly
		$css .= '.header .ps-logo, .header-1 .ps-logo, .header-2 .ps-logo, .header-3 .ps-logo {';
		$css .= 'width: ' . esc_attr($logo_1_width) . 'px !important;'; // Use !important to override other styles
		$css .= '}';
		
		// Add specific CSS rules for sticky logo width
		$css .= '.navigation--sticky .ps-logo, .header--new.navigation--sticky .navigation .ps-logo, .navigation--sticky.header--2 .ps-logo {';
		$css .= 'width: ' . esc_attr($logo_sticky_width) . 'px !important;'; // Use !important to override other styles
		$css .= '}';
		
		// Override media query styles
		$css .= '@media (max-width: 1199px) {';
		$css .= '.header .ps-logo, .header-1 .ps-logo, .header-2 .ps-logo, .header-3 .ps-logo {';
		$css .= 'width: ' . esc_attr($logo_1_width) . 'px !important;'; // Use !important to override other styles
		$css .= '}';
		
		// Override media query styles for sticky logo
		$css .= '.navigation--sticky .ps-logo, .header--new.navigation--sticky .navigation .ps-logo, .navigation--sticky.header--2 .ps-logo {';
		$css .= 'width: ' . esc_attr($logo_sticky_width) . 'px !important;'; // Use !important to override other styles
		$css .= '}';
		$css .= '}';

		echo '<style type="text/css">' . $debug . $css . '</style>';
	}

	/**
	 * Initialize hooks
	 *
	 * @since    1.0.0
	 */
	public function init() {
		add_action('wp_head', array($this, 'output_logo_css'), 100);
	}

	public function share_post(){
		?>
		<div class="noubakery-share-post ps-post__action" data-url="<?php the_permalink();?>" data-title="<?php the_title();?>">
			<?php noubakery_button_like(get_the_ID());?>
			<?php noubakery_share_post();?>
		</div>
		<?php
	}

}
