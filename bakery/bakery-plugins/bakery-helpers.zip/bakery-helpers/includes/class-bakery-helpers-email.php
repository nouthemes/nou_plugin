<?php
/**
* Email class
*
* @package classes
* @author nouthemes [nouthemes@gmail.com]
* @since 1.0
*/
defined( 'ABSPATH' ) OR exit;

class Bakery_Helpers_Email{

	/**
	 * Get WordPress blog name.
	 *
	 * @return string
	 */
	public static function get_blogname() {
		return wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
	}

	public static function get_from_address() {
		return noubakery_get_email();
    }

    public static function get_from_name() {
		return self::get_blogname();
    }

    /**
	* Get email content type.
	*
	* @return string
	*/
	public static function get_content_type() {
		return 'text/html';
	}

	/**
	 * Send an email.
	 * @param string $to
	 * @param string $subject
	 * @param string $message
	 * @param string $headers
	 * @param string $attachments
	 * @return bool success
	 */
	public static function send( $to, $subject, $message, $headers = '', $attachments = array() ) {
		
		add_filter( 'wp_mail_from', array( __CLASS__, 'get_from_address' ) );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'get_from_name' ) );
		add_filter( 'wp_mail_content_type', array( __CLASS__, 'get_content_type' ) );

		$message = apply_filters( 'noubakery_mail_content', $message );
		$return  = wp_mail( $to, $subject, $message, $headers, $attachments );

		remove_filter( 'wp_mail_from', array( __CLASS__, 'get_from_address' ) );
		remove_filter( 'wp_mail_from_name', array( __CLASS__, 'get_from_name' ) );
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'get_content_type' ) );

		return $return;
	}

	
}
